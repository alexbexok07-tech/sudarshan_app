package com.sudarshancloud.app.data.repository

import android.content.Context
import android.util.Log
import com.sudarshancloud.app.data.api.ApiClient
import com.sudarshancloud.app.data.api.ConsoleLogEntry
import com.sudarshancloud.app.data.api.ConsoleWebSocketManager
import com.sudarshancloud.app.data.api.LogLevel
import com.sudarshancloud.app.data.db.AppDatabase
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.db.CommandHistoryEntity
import com.sudarshancloud.app.data.db.PanelConfigEntity
import com.sudarshancloud.app.data.db.ServerFolderEntity
import com.sudarshancloud.app.data.model.ConsoleCommandRequest
import com.sudarshancloud.app.data.model.CreateBackupRequest
import com.sudarshancloud.app.data.model.CreateFolderRequest
import com.sudarshancloud.app.data.model.DeleteFilesRequest
import com.sudarshancloud.app.data.model.PowerSignalRequest
import com.sudarshancloud.app.data.model.PteroApplicationServerAttributes
import com.sudarshancloud.app.data.model.PteroBackupAttributes
import com.sudarshancloud.app.data.model.PteroDatabaseAttributes
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroServerItem
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Response
import java.io.IOException
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ServerRepository(context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val configDao = database.panelConfigDao()
    private val folderDao = database.serverFolderDao()
    private val serverDao = database.cachedServerDao()
    private val historyDao = database.commandHistoryDao()

    val webSocketManager = ConsoleWebSocketManager()

    val configFlow: Flow<PanelConfigEntity?> = configDao.getConfigFlow()
    val foldersFlow: Flow<List<ServerFolderEntity>> = folderDao.getAllFoldersFlow()
    val cachedServersFlow: Flow<List<CachedServerEntity>> = serverDao.getAllCachedServersFlow()

    private val _realtimeStatsMap = MutableStateFlow<Map<String, PteroStatsAttributes>>(emptyMap())
    val realtimeStatsMap: StateFlow<Map<String, PteroStatsAttributes>> = _realtimeStatsMap.asStateFlow()

    private val _isLiveConnected = MutableStateFlow(false)
    val isLiveConnected: StateFlow<Boolean> = _isLiveConnected.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    suspend fun initialize() {
        withContext(Dispatchers.IO) {
            val currentConfig = configDao.getConfig()
            if (currentConfig == null) {
                val defaultConfig = PanelConfigEntity(
                    panelUrl = "https://portal.sudarshancloud.com",
                    apiKey = "",
                    applicationApiKey = "",
                    showOtherServers = false,
                    userEmail = "",
                    username = "SudarshanUser"
                )
                configDao.saveConfig(defaultConfig)
                ApiClient.updateConfig(defaultConfig.panelUrl, defaultConfig.apiKey)
            } else {
                ApiClient.updateConfig(currentConfig.panelUrl, currentConfig.apiKey)
            }

            // Folders were an old local/demo feature. The panel is the source of truth
            // for the server list, so remove any legacy folder chips from existing installs.
            folderDao.clearFolders()
        }
    }

    suspend fun savePanelConfig(
        panelUrl: String,
        apiKey: String,
        applicationApiKey: String = "",
        showOtherServers: Boolean = false,
        userEmail: String? = null
    ) {
        withContext(Dispatchers.IO) {
            val existing = configDao.getConfig() ?: PanelConfigEntity()
            val updated = existing.copy(
                panelUrl = panelUrl.trim(),
                apiKey = apiKey.trim(),
                applicationApiKey = applicationApiKey.trim(),
                showOtherServers = showOtherServers,
                userEmail = userEmail?.trim()?.takeIf { it.isNotBlank() } ?: existing.userEmail
            )
            configDao.saveConfig(updated)
            ApiClient.updateConfig(updated.panelUrl, updated.apiKey)
        }
    }

    suspend fun fetchServersFromPanel(): Result<List<CachedServerEntity>> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val clientApiKey = config?.apiKey.orEmpty().trim()
        val applicationApiKey = config?.applicationApiKey.orEmpty().trim()
        val showOtherServers = config?.showOtherServers ?: false

        if (clientApiKey.isBlank() && applicationApiKey.isBlank()) {
            _lastError.value = "Add your Client API key in Settings to connect to the panel."
            return@withContext Result.failure(Exception("Client API key not configured"))
        }
        if (showOtherServers && applicationApiKey.isBlank()) {
            _lastError.value = "See other panel servers is enabled, but no Application API key (ptla_) is configured."
            return@withContext Result.failure(Exception("Application API key required for other servers"))
        }

        try {
            val service = ApiClient.getService()
            // If an Application key is available, use the real node FQDN and resolve it
            // to an address for the UI. The Client API only exposes the node name.
            val nodeAddresses = if (applicationApiKey.isNotBlank()) {
                loadNodeAddresses(service, applicationApiKey)
            } else {
                emptyMap()
            }
            val entities: List<CachedServerEntity>

            if (showOtherServers && applicationApiKey.isNotBlank()) {
                // Application API is the authoritative panel-wide list. Pterodactyl documents
                // this endpoint as paginated, with up to 100 servers per page.
                val allItems = mutableListOf<PteroApplicationServerAttributes>()
                var page = 1
                var totalPages = 1
                do {
                    val response = service.getApplicationServers(
                        page = page,
                        perPage = 100,
                        include = "allocations,node,user",
                        authHeader = toBearerHeader(applicationApiKey)
                    )
                    allItems += response.data.map { it.attributes }
                    totalPages = response.meta?.pagination?.totalPages ?: page
                    page++
                } while (page <= totalPages)

                // Determine actual client access from the Client API server list instead of
                // guessing from Application API owner relationships. Owner/user relationships
                // are not guaranteed to be present in every panel response.
                val clientAccessible = if (clientApiKey.isNotBlank()) {
                    runCatching {
                        service.getServers(include = "allocations", authHeader = toBearerHeader(clientApiKey))
                            .data
                            .associateBy { it.attributes.identifier }
                    }.getOrDefault(emptyMap())
                } else emptyMap()

                entities = allItems.map { attr ->
                    val allocation = attr.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: attr.relationships?.allocations?.data?.firstOrNull()
                    val node = attr.relationships?.node?.data?.attributes
                    val allocationIp = allocation?.attributes?.ipAlias?.takeIf { isUsableHost(it) }
                        ?: allocation?.attributes?.ip?.takeIf { isUsableHost(it) }
                    val host = allocationIp
                        ?: node?.fqdn?.takeIf { isUsableHost(it) }
                        ?: node?.name?.takeIf { it.isNotBlank() }
                        ?: "Unknown host"
                    val clientServer = clientAccessible[attr.identifier]?.attributes
                    val isOther = clientServer == null
                    val clientAllocation = clientServer?.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: clientServer?.relationships?.allocations?.data?.firstOrNull()
                    val finalAllocationIp = clientAllocation?.attributes?.ipAlias?.takeIf { isUsableHost(it) }
                        ?: clientAllocation?.attributes?.ip?.takeIf { isUsableHost(it) }
                        ?: allocationIp
                    val finalPort = clientAllocation?.attributes?.port ?: allocation?.attributes?.port ?: 25565

                    CachedServerEntity(
                        identifier = attr.identifier,
                        name = attr.name,
                        node = node?.name?.takeIf { it.isNotBlank() } ?: "Unknown node",
                        nodeAddress = resolveNodeAddress(node?.fqdn, node?.name?.let { nodeAddresses[it] }),
                        ip = finalAllocationIp ?: host,
                        port = finalPort,
                        cpuLimit = attr.limits.cpu,
                        memoryLimit = attr.limits.memory,
                        diskLimit = attr.limits.disk,
                        currentState = if (attr.suspended) "suspended" else (attr.status?.takeIf { it.isNotBlank() } ?: "unknown"),
                        cpuUsage = 0.0,
                        memoryUsageBytes = 0,
                        diskUsageBytes = 0,
                        folderName = null,
                        isOtherServer = isOther
                    )
                }
            } else {
                // Client API is the correct source when the toggle is off: it returns only
                // servers the authenticated client account can access.
                val response = service.getServers(include = "allocations", authHeader = toBearerHeader(clientApiKey))
                entities = response.data.map { item ->
                    val attr = item.attributes
                    val defaultAllocation = attr.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: attr.relationships?.allocations?.data?.firstOrNull()
                    val allocationIp = defaultAllocation?.attributes?.ipAlias?.takeIf { isUsableHost(it) }
                        ?: defaultAllocation?.attributes?.ip?.takeIf { isUsableHost(it) }
                    CachedServerEntity(
                        identifier = attr.identifier,
                        name = attr.name,
                        node = attr.node ?: "Unknown node",
                        nodeAddress = resolveNodeAddress(nodeAddresses[attr.node.orEmpty()], attr.node),
                        ip = allocationIp ?: attr.node?.let { nodeAddresses[it] }.orEmpty().takeIf { isUsableHost(it) } ?: "Unknown host",
                        port = defaultAllocation?.attributes?.port ?: 25565,
                        cpuLimit = attr.limits.cpu,
                        memoryLimit = attr.limits.memory,
                        diskLimit = attr.limits.disk,
                        currentState = if (attr.isSuspended) "suspended" else "offline",
                        cpuUsage = 0.0,
                        memoryUsageBytes = 0,
                        diskUsageBytes = 0,
                        folderName = null,
                        isOtherServer = false
                    )
                }
            }

            // The API is authoritative: never retain stale/demo cards after a sync.
            serverDao.clearServers()
            if (entities.isNotEmpty()) serverDao.insertOrUpdateServers(entities)
            _isLiveConnected.value = true
            _lastError.value = null
            Result.success(entities)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Error fetching live servers from Pterodactyl", e)
            _lastError.value = "Pterodactyl sync failed: ${friendlyApiError(e)}"
            Result.failure(e)
        }
    }

    private suspend fun loadNodeAddresses(
        service: com.sudarshancloud.app.data.api.PterodactylApi,
        applicationApiKey: String
    ): Map<String, String> {
        return runCatching {
            val result = mutableMapOf<String, String>()
            var page = 1
            var totalPages = 1
            do {
                val response = service.getApplicationNodes(
                    page = page,
                    perPage = 100,
                    authHeader = toBearerHeader(applicationApiKey)
                )
                response.data.forEach { item ->
                    val fqdn = item.attributes.fqdn.trim()
                    if (item.attributes.name.isNotBlank() && fqdn.isNotBlank()) {
                        val resolved = runCatching {
                            InetAddress.getByName(fqdn).hostAddress
                        }.getOrNull()
                        result[item.attributes.name] = resolved?.takeIf { isUsableHost(it) } ?: fqdn
                    }
                }
                totalPages = response.meta?.pagination?.totalPages ?: page
                page++
            } while (page <= totalPages)
            result
        }.getOrDefault(emptyMap())
    }

    private fun resolveNodeAddress(primary: String?, fallback: String?): String {
        val candidate = primary?.trim().takeIf { !it.isNullOrBlank() } ?: fallback?.trim().orEmpty()
        if (!isUsableHost(candidate)) return ""
        return runCatching { InetAddress.getByName(candidate).hostAddress }
            .getOrNull()
            ?.takeIf { isUsableHost(it) }
            ?: candidate
    }

    private fun isUsableHost(value: String?): Boolean {
        val host = value?.trim().orEmpty()
        return host.isNotBlank() && host != "0.0.0.0" && host != "::" && host != "::0"
    }

    private fun friendlyApiError(error: Throwable): String {
        val message = error.message.orEmpty()
        return when {
            message.contains("401") || message.contains("403") -> "API key was rejected (HTTP ${if (message.contains("403")) "403" else "401"}). Check the key and its permissions."
            message.contains("404") -> "Panel API endpoint was not found. Check the panel URL."
            message.contains("timeout", ignoreCase = true) -> "Panel request timed out."
            message.isBlank() -> error::class.simpleName ?: "Unknown error"
            else -> message.take(180)
        }
    }

    /**
     * Returns credentials in the order that is most likely to work for a server.
     *
     * A panel-wide Application API key can discover servers owned by other panel
     * users, while a Client API key powers the client endpoints (console, files,
     * resources, backups and databases). Trying both is important because an admin
     * may also have client access to a server that was discovered through the
     * Application API.
     */
    private suspend fun authHeadersForServer(serverIdentifier: String): List<String> {
        val config = configDao.getConfig() ?: return emptyList()
        val clientKey = config.apiKey.trim()
        val applicationKey = config.applicationApiKey.trim()
        val isOtherServer = serverDao.getServer(serverIdentifier)?.isOtherServer == true
        val keys = if (isOtherServer) {
            listOf(applicationKey, clientKey)
        } else {
            listOf(clientKey, applicationKey)
        }
        return keys
            .filter { it.isNotBlank() }
            .distinct()
            .map(::toBearerHeader)
    }

    private fun toBearerHeader(key: String): String {
        val cleanKey = key.trim()
        return if (cleanKey.startsWith("Bearer ", ignoreCase = true)) {
            cleanKey
        } else {
            "Bearer $cleanKey"
        }
    }

    private suspend fun <T> withServerAuth(
        serverIdentifier: String,
        request: suspend (authHeader: String) -> T
    ): Result<T> {
        val headers = authHeadersForServer(serverIdentifier)
        if (headers.isEmpty()) {
            return Result.failure(Exception("No API key is configured for this server."))
        }

        var lastError: Throwable? = null
        for (header in headers) {
            try {
                return Result.success(request(header))
            } catch (error: Exception) {
                lastError = error
            }
        }
        return Result.failure(lastError ?: Exception("Panel request failed."))
    }

    private fun requireSuccessful(response: Response<*>, operation: String) {
        if (!response.isSuccessful) {
            throw IOException("$operation failed (HTTP ${response.code()}).")
        }
    }

    suspend fun fetchServerResources(serverIdentifier: String): Result<PteroStatsAttributes> = withContext(Dispatchers.IO) {
        val statsResult = withServerAuth(serverIdentifier) { authHeader ->
            ApiClient.getService()
                .getServerResources(serverIdentifier, authHeader)
                .attributes
        }

        if (statsResult.isSuccess) {
            try {
                val stats = statsResult.getOrThrow()
                val current = _realtimeStatsMap.value.toMutableMap()
                current[serverIdentifier] = stats
                _realtimeStatsMap.value = current

                // Update cached DB entity with latest stats
                val cached = serverDao.getServer(serverIdentifier)
                if (cached != null) {
                    serverDao.insertOrUpdateServers(
                        listOf(
                            cached.copy(
                                currentState = stats.currentState,
                                cpuUsage = stats.resources.cpuAbsolute,
                                memoryUsageBytes = stats.resources.memoryBytes,
                                diskUsageBytes = stats.resources.diskBytes
                            )
                        )
                    )
                }
                return@withContext Result.success(stats)
            } catch (e: Exception) {
                _lastError.value = "Live stats failed for $serverIdentifier: ${friendlyApiError(e)}"
                Log.w("ServerRepository", "Live stats fetch error: ${e.message}", e)
            }
        } else {
            val error = statsResult.exceptionOrNull()
            _lastError.value = "Live stats failed for $serverIdentifier: ${friendlyApiError(error ?: Exception())}"
            Log.w("ServerRepository", "Live stats fetch error", error)
        }

        val cached = serverDao.getServer(serverIdentifier)
        val message = if (cached?.isOtherServer == true) {
            "Live telemetry is unavailable for this server with the configured API keys."
        } else {
            "Live server telemetry is unavailable right now."
        }
        Log.w("ServerRepository", message)
        Result.failure(Exception(message))
    }

    suspend fun sendPowerAction(serverIdentifier: String, signal: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().sendPowerSignal(
                    serverIdentifier,
                    PowerSignalRequest(signal),
                    authHeader
                )
                requireSuccessful(response, "Power action '$signal'")
                response
            }
            if (responseResult.isFailure) throw responseResult.exceptionOrNull()!!
            fetchServerResources(serverIdentifier)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Error sending power signal $signal", e)
            _lastError.value = "Power action failed: ${friendlyApiError(e)}"
            Result.failure(e)
        }
    }

    suspend fun sendConsoleCommand(serverIdentifier: String, command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanCmd = command.trim()
        if (cleanCmd.isEmpty()) return@withContext Result.success(Unit)

        historyDao.insertCommand(
            CommandHistoryEntity(
                serverIdentifier = serverIdentifier,
                command = cleanCmd
            )
        )

        // Prefer the live WebSocket. If it is not connected, use the documented HTTP
        // command endpoint; neither path fabricates server output.
        val wsSent = webSocketManager.sendConsoleCommand(cleanCmd)
        if (!wsSent) {
            try {
                val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                    val response = ApiClient.getService().sendConsoleCommand(
                        serverIdentifier,
                        ConsoleCommandRequest(cleanCmd),
                        authHeader
                    )
                    requireSuccessful(response, "Command")
                    response
                }
                if (responseResult.isFailure) throw responseResult.exceptionOrNull()!!
            } catch (e: Exception) {
                Log.e("ServerRepository", "Console command failed", e)
                return@withContext Result.failure(e)
            }
        }

        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        webSocketManager.appendLocalLog(
            ConsoleLogEntry(
                rawText = "> $cleanCmd",
                timestamp = timeStr,
                level = LogLevel.COMMAND,
                source = "Console"
            )
        )
        Result.success(Unit)
    }

    suspend fun connectServerConsole(serverIdentifier: String) = withContext(Dispatchers.IO) {
        try {
            val wsResult = withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().getWebsocketCredentials(serverIdentifier, authHeader)
            }
            if (wsResult.isFailure) throw wsResult.exceptionOrNull()!!
            val wsData = wsResult.getOrThrow()
            webSocketManager.connect(wsData.data.socket, wsData.data.token)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Failed to retrieve websocket credentials", e)
            webSocketManager.appendLocalLog(
                ConsoleLogEntry(
                    rawText = "[System] Could not obtain live console credentials: ${friendlyApiError(e)}",
                    level = LogLevel.ERROR,
                    source = "Client"
                )
            )
        }
    }

    suspend fun listFiles(serverIdentifier: String, directory: String = "/"): Result<List<PteroFileAttributes>> = withContext(Dispatchers.IO) {
        val root = normalizeDirectory(directory)
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().listFiles(serverIdentifier, root, authHeader)
            }.map { response -> response.data.map { it.attributes } }
        } catch (e: Exception) {
            Log.e("ServerRepository", "List files failed", e)
            Result.failure(Exception("File list failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun getFileContent(serverIdentifier: String, filePath: String): Result<String> = withContext(Dispatchers.IO) {
        val path = normalizeFilePath(filePath)
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().getFileContents(serverIdentifier, path, authHeader).string()
            }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Get file contents failed", e)
            Result.failure(Exception("Could not open file: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun saveFileContent(serverIdentifier: String, filePath: String, content: String): Result<Unit> = withContext(Dispatchers.IO) {
        val path = normalizeFilePath(filePath)
        try {
            val body = content.toRequestBody("text/plain; charset=utf-8".toMediaTypeOrNull())
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().writeFileContents(serverIdentifier, path, body, authHeader)
                requireSuccessful(response, "Save")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Save file failed", e)
            Result.failure(Exception("Save failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun createFolder(serverIdentifier: String, root: String, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanName = name.trim().trim('/')
        if (cleanName.isBlank() || cleanName.contains("/")) return@withContext Result.failure(Exception("Enter a valid folder name."))
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().createFolder(
                    serverIdentifier,
                    CreateFolderRequest(normalizeDirectory(root), cleanName),
                    authHeader
                )
                requireSuccessful(response, "Create folder")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Create folder failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun createFile(serverIdentifier: String, root: String, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanName = name.trim().trim('/')
        if (cleanName.isBlank() || cleanName.contains("/")) return@withContext Result.failure(Exception("Enter a valid file name."))
        val path = normalizeDirectory(root).trimEnd('/') + "/" + cleanName
        try {
            val body = "".toRequestBody("text/plain; charset=utf-8".toMediaTypeOrNull())
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().writeFileContents(serverIdentifier, path, body, authHeader)
                requireSuccessful(response, "Create file")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Create file failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun deleteFiles(serverIdentifier: String, root: String, files: List<String>): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().deleteFiles(
                    serverIdentifier,
                    DeleteFilesRequest(normalizeDirectory(root), files),
                    authHeader
                )
                requireSuccessful(response, "Delete")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Delete failed: ${friendlyApiError(e)}", e))
        }
    }

    private fun normalizeDirectory(directory: String): String {
        val value = directory.trim()
        if (value.isBlank() || value == "/") return "/"
        return "/" + value.trim('/')
    }

    private fun normalizeFilePath(path: String): String {
        val value = path.trim()
        return if (value.startsWith("/")) value else "/$value"
    }


    suspend fun listBackups(serverIdentifier: String): Result<List<PteroBackupAttributes>> = withContext(Dispatchers.IO) {
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().listBackups(serverIdentifier, authHeader)
            }.map { response -> response.data.map { it.attributes } }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Backups failed", e)
            Result.failure(e)
        }
    }

    suspend fun createBackup(serverIdentifier: String, name: String?): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().createBackup(
                    serverIdentifier,
                    CreateBackupRequest(name = name),
                    authHeader
                )
            }
            if (responseResult.isFailure) throw responseResult.exceptionOrNull()!!
            val response = responseResult.getOrThrow()
            Log.d("ServerRepository", "Backup request accepted: ${response.attributes.uuid}")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Create backup failed", e)
            Result.failure(Exception("Create backup failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun deleteBackup(serverIdentifier: String, backupUuid: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().deleteBackup(serverIdentifier, backupUuid, authHeader)
                requireSuccessful(response, "Delete backup")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Delete backup failed", e)
            Result.failure(Exception("Delete backup failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun listDatabases(serverIdentifier: String): Result<List<PteroDatabaseAttributes>> = withContext(Dispatchers.IO) {
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().listDatabases(serverIdentifier, authHeader)
            }.map { response -> response.data.map { it.attributes } }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Databases call failed", e)
            Result.failure(e)
        }
    }


}
