# SudarshanCloud Android update

This build keeps the existing customer-facing server management logic and adds the customer-side navigation shown in the requested panel screenshot, excluding Account and Admin View.

## Added customer navigation
- Activity
- Network
- Schedules
- Users
- Startup
- Version Changer
- Plugins
- Players
- Mods
- Server Properties
- Server Importer
- Server Splitter
- Subdomains
- Votifier Tester
- MC Logs
- World Manager
- Server Icon

## Functional integrations
- Network reads the already-authorized server allocation/cache data.
- Activity records actions performed during the current app session.
- Players sends `/list` through the existing console command path.
- Plugins and Mods inspect their real Pterodactyl directories and can delete files through the existing Client API file-delete path.
- Server Properties reads and writes `/server.properties` through the existing Client API file path.
- MC Logs reads `/logs/latest.log` through the existing Client API file path.
- World Manager continues to use the existing server filesystem flow.
- Server Icon checks the real `server-icon.png` file and opens the existing Files flow for binary transfer.
- Users uses Pterodactyl Client API server-subuser endpoints for listing, adding, and removing server-level users.
- Version Changer uses editable startup/version variables exposed by the server egg; it does not fake a jar replacement when the customer API does not expose that operation.

## Deliberately not faked
Server creation/splitting, DNS/subdomain changes, and arbitrary server-software replacement require control-plane/Application API privileges or a separate SudarshanCloud control-plane API. The customer app therefore shows these tools without pretending an operation succeeded.

## Validation
The project was structurally checked after modification. A local Gradle compile could not be executed in the build environment because the Gradle 9.3.1 distribution was not already cached and outbound network access was unavailable. The original project also contained pre-existing duplicate declarations/missing-screen references; the duplicate model/UI declarations were corrected and the missing World Manager screen reference is now backed by the existing management screen implementation.
