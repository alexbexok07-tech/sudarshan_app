package com.sudarshancloud.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroStartupVariable
import com.sudarshancloud.app.data.model.PteroSubuserAttributes
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary

private val Accent = Color(0xFFEAB308)
private val Green = Color(0xFF10B981)
private val Blue = Color(0xFF38BDF8)

@Composable
private fun ToolHeader(
    title: String,
    description: String,
    onRefresh: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = TextSecondary, fontSize = 12.sp)
        }
        if (onRefresh != null) {
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextPrimary)
            }
        }
    }
}

@Composable
fun NetworkScreen(server: CachedServerEntity?, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader("Network", "View the allocations and connection information exposed to this customer account.")
        Spacer(Modifier.height(14.dp))
        if (server == null) Text("No server selected", color = TextSecondary)
        else {
            InfoCard("Primary allocation", listOf(
                "Host" to server.ip,
                "Port" to server.port.toString(),
                "Node" to server.node,
                "Node address" to server.nodeAddress.ifBlank { "Not exposed" },
                "Identifier" to server.identifier
            ))
            Spacer(Modifier.height(12.dp))
            Text("Only allocations returned by the customer Client API are shown. Admin/application API data is intentionally not exposed here.", color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
fun ActivityScreen(events: List<String>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader("Activity", "Recent actions performed from this app session.")
        Spacer(Modifier.height(12.dp))
        if (events.isEmpty()) Text("No activity yet.", color = TextMuted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(events) { event ->
                Box(Modifier.fillMaxWidth().background(DarkSurfaceElevated, RoundedCornerShape(10.dp)).border(1.dp, DarkBorder, RoundedCornerShape(10.dp)).padding(12.dp)) {
                    Text(event, color = TextPrimary, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun PlayersScreen(
    server: CachedServerEntity?,
    consoleLines: List<String>,
    onListPlayers: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader("Players", "Ask the server for its current online-player list.")
        Spacer(Modifier.height(12.dp))
        Button(onClick = onListPlayers, enabled = server != null, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF111827))) {
            Icon(Icons.Default.Terminal, null)
            Spacer(Modifier.size(8.dp))
            Text("Run /list")
        }
        Spacer(Modifier.height(12.dp))
        Text("Latest console response", color = TextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF0B0F14), RoundedCornerShape(10.dp)).padding(12.dp)) {
            val relevant = consoleLines.takeLast(80)
            Text(relevant.joinToString("\n"), color = TextPrimary, fontSize = 11.sp)
        }
    }
}

@Composable
fun FileBackedToolScreen(
    title: String,
    description: String,
    path: String,
    content: String,
    isLoading: Boolean,
    onLoad: () -> Unit,
    onSave: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var edited by remember(path, content) { mutableStateOf(content) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader(title, description, onRefresh = onLoad)
        Spacer(Modifier.height(10.dp))
        Text(path, color = Blue, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        if (isLoading) CircularProgressIndicator(color = Accent)
        else {
            OutlinedTextField(
                value = edited,
                onValueChange = { edited = it },
                modifier = Modifier.fillMaxWidth().weight(1f),
                label = { Text("File content") }
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = { onSave(edited) }, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White)) {
                Text("Save $path")
            }
        }
    }
}

@Composable
fun DirectoryToolScreen(
    title: String,
    description: String,
    directory: String,
    files: List<PteroFileAttributes>,
    onRefresh: () -> Unit,
    onOpenFiles: () -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader(title, description, onRefresh)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(directory, color = Blue, fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenFiles) { Text("Open in Files") }
        }
        if (files.isEmpty()) Text("Nothing found here yet.", color = TextMuted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it.name }) { file ->
                Row(Modifier.fillMaxWidth().background(DarkSurfaceElevated, RoundedCornerShape(10.dp)).border(1.dp, DarkBorder, RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (file.isFile) Icons.Default.Info else Icons.Default.Folder, null, tint = if (file.isFile) Blue else Accent)
                    Spacer(Modifier.size(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(file.name, color = TextPrimary, fontSize = 13.sp)
                        Text(if (file.isFile) "${file.size} bytes" else "Directory", color = TextSecondary, fontSize = 11.sp)
                    }
                    if (file.isFile) IconButton(onClick = { onDelete(file.name) }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFEF4444)) }
                }
            }
        }
    }
}


@Composable
fun ServerUsersScreen(
    server: CachedServerEntity?,
    users: List<PteroSubuserAttributes>,
    onRefresh: () -> Unit,
    onCreate: (String) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAdd by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader("Users", "Manage server-level subusers without exposing account-wide admin credentials.", onRefresh)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Button(onClick = { showAdd = true }, enabled = server != null, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF111827))) { Text("Add user") }
        }
        Spacer(Modifier.height(10.dp))
        if (users.isEmpty()) Text("No server subusers found.", color = TextMuted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.uuid }) { user ->
                Row(Modifier.fillMaxWidth().background(DarkSurfaceElevated, RoundedCornerShape(10.dp)).border(1.dp, DarkBorder, RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(user.username.ifBlank { user.email }, color = TextPrimary)
                        Text(user.email, color = TextSecondary, fontSize = 11.sp)
                        Text(user.permissions.joinToString(", ").ifBlank { "No permissions returned" }, color = Blue, fontSize = 10.sp)
                    }
                    IconButton(onClick = { onDelete(user.uuid) }) { Icon(Icons.Default.Delete, "Remove", tint = Color(0xFFEF4444)) }
                }
            }
        }
    }
    if (showAdd) AlertDialog(
        onDismissRequest = { showAdd = false },
        title = { Text("Add server user") },
        text = { OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true) },
        confirmButton = { TextButton(enabled = email.contains("@"), onClick = { onCreate(email.trim()); email = ""; showAdd = false }) { Text("Add") } },
        dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
    )
}


@Composable
fun ServerIconScreen(files: List<PteroFileAttributes>, onRefresh: () -> Unit, onOpenFiles: () -> Unit, modifier: Modifier = Modifier) {
    val icon = files.firstOrNull { it.name.equals("server-icon.png", ignoreCase = true) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader("Server Icon", "Check the server-icon.png file and manage it through the existing Files flow.", onRefresh)
        Spacer(Modifier.height(14.dp))
        if (icon == null) {
            Text("server-icon.png was not found in the server root.", color = TextMuted)
        } else {
            InfoCard("Current icon file", listOf("Name" to icon.name, "Size" to "${icon.size} bytes", "Modified" to (icon.modifiedAt ?: "Unknown")))
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onOpenFiles, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF111827))) {
            Text("Open Files")
        }
        Spacer(Modifier.height(8.dp))
        Text("The existing Files screen remains the source of truth for binary file transfers, so this feature does not replace or corrupt that logic.", color = TextMuted, fontSize = 11.sp)
    }
}

@Composable
fun VersionChangerScreen(
    server: CachedServerEntity?,
    variables: List<PteroStartupVariable>,
    onRefresh: () -> Unit,
    onUpdateVariable: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSoftware by remember { mutableStateOf("Detect from startup variables") }
    val softwareOptions = listOf("Paper", "Purpur", "Spigot", "Bukkit", "Vanilla", "Fabric", "Forge", "NeoForge", "Quilt", "Folia", "Velocity")
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader("Version Changer", "Use the server egg's editable version variable when one is exposed by Pterodactyl.", onRefresh)
        Spacer(Modifier.height(12.dp))
        if (server == null) Text("No server selected", color = TextSecondary)
        else {
            Text("Software", color = TextSecondary, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                softwareOptions.take(4).forEach { option ->
                    TextButton(onClick = { selectedSoftware = option }) { Text(option, color = if (selectedSoftware == option) Accent else TextSecondary, fontSize = 11.sp) }
                }
            }
            Text("Selected: $selectedSoftware", color = Blue, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            val versionVars = variables.filter {
                val key = it.envVariable.lowercase()
                key.contains("version") || key.contains("jar") || key.contains("software") || key.contains("server")
            }
            if (versionVars.isEmpty()) {
                Text("This server does not expose an editable version/software variable. The app will not pretend to change the server jar; use the panel's server software controls for an egg without such a variable.", color = TextMuted, fontSize = 12.sp)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(versionVars, key = { it.envVariable }) { variable ->
                        var value by remember(variable.envVariable, variable.serverValue) { mutableStateOf(variable.serverValue ?: variable.defaultValue.orEmpty()) }
                        Row(Modifier.fillMaxWidth().background(DarkSurfaceElevated, RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(variable.name.ifBlank { variable.envVariable }, color = TextPrimary)
                                Text(variable.envVariable, color = Blue, fontSize = 10.sp)
                            }
                            OutlinedTextField(value, { value = it }, modifier = Modifier.weight(1f), singleLine = true)
                            TextButton(enabled = variable.isEditable, onClick = { onUpdateVariable(variable.envVariable, value) }) { Text("Apply") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolInfoScreen(title: String, description: String, details: List<String>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ToolHeader(title, description)
        Spacer(Modifier.height(14.dp))
        details.forEach { detail ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(7.dp).background(Accent, RoundedCornerShape(50)))
                Spacer(Modifier.size(10.dp))
                Text(detail, color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, values: List<Pair<String, String>>) {
    Column(Modifier.fillMaxWidth().background(DarkSurfaceElevated, RoundedCornerShape(12.dp)).border(1.dp, DarkBorder, RoundedCornerShape(12.dp)).padding(14.dp)) {
        Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        values.forEach { (key, value) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(key, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text(value, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
            }
        }
    }
}
