package com.sudarshancloud.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sudarshancloud.app.R
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary

enum class NavDestination {
    SERVERS, DASHBOARD, CONSOLE, SETTINGS, AUTHENTICATION,
    FILES, DATABASES, BACKUPS, NETWORK, SCHEDULES, USERS, STARTUP,
    VERSION_CHANGER, PLUGINS, PLAYERS, MODS, SERVER_PROPERTIES,
    SERVER_IMPORTER, SERVER_SPLITTER, SUBDOMAINS, VOTIFIER_TESTER,
    MC_LOGS, WORLDS, SERVER_ICON, ACTIVITY
}

@Composable
fun AppDrawer(
    currentDestination: NavDestination,
    selectedServerName: String?,
    userEmail: String,
    onNavigate: (NavDestination) -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uriHandler = LocalUriHandler.current
    Column(
        modifier = modifier.fillMaxHeight().width(300.dp).background(Color(0xFF161E2D)).padding(vertical = 16.dp)
    ) {
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Image(painterResource(R.drawable.sudarshan_logo_mark), "Sudarshan Logo", Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("SudarshanCloud", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        if (userEmail.isNotBlank()) Text(userEmail, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
                    }
                }
                IconButton(onClick = onCloseDrawer, modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF283852))) {
                    Icon(Icons.Default.Close, "Close Drawer", tint = TextPrimary)
                }
            }
            if (!selectedServerName.isNullOrBlank()) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF1E2D44)).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF10B981)))
                        Spacer(Modifier.width(8.dp))
                        Text("Active: $selectedServerName", color = Color(0xFFFACC15), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            item(Icons.Default.Dns, "Servers", NavDestination.SERVERS, currentDestination, onNavigate, onCloseDrawer)
            Spacer(Modifier.height(14.dp))
            section("GENERAL")
            item(Icons.Default.Dashboard, "Dashboard", NavDestination.DASHBOARD, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Terminal, "Console", NavDestination.CONSOLE, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Settings, "Settings", NavDestination.SETTINGS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.LockReset, "Authentication", NavDestination.AUTHENTICATION, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.History, "Activity", NavDestination.ACTIVITY, currentDestination, onNavigate, onCloseDrawer)
            Spacer(Modifier.height(14.dp))
            section("MANAGEMENT")
            item(Icons.Default.Folder, "Files", NavDestination.FILES, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Storage, "Databases", NavDestination.DATABASES, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.FolderZip, "Backups", NavDestination.BACKUPS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Public, "Network", NavDestination.NETWORK, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Schedule, "Schedules", NavDestination.SCHEDULES, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.People, "Users", NavDestination.USERS, currentDestination, onNavigate, onCloseDrawer)
            Spacer(Modifier.height(14.dp))
            section("CONFIGURATION")
            item(Icons.Default.Tune, "Startup", NavDestination.STARTUP, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.SystemUpdate, "Version Changer", NavDestination.VERSION_CHANGER, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.SettingsApplications, "Server Properties", NavDestination.SERVER_PROPERTIES, currentDestination, onNavigate, onCloseDrawer)
            Spacer(Modifier.height(14.dp))
            section("EXTENSIONS")
            item(Icons.Default.Extension, "Plugins", NavDestination.PLUGINS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.People, "Players", NavDestination.PLAYERS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Extension, "Mods", NavDestination.MODS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.FolderOpen, "Server Importer", NavDestination.SERVER_IMPORTER, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.CallSplit, "Server Splitter", NavDestination.SERVER_SPLITTER, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Link, "Subdomains", NavDestination.SUBDOMAINS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.BugReport, "Votifier Tester", NavDestination.VOTIFIER_TESTER, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Description, "MC Logs", NavDestination.MC_LOGS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Public, "World Manager", NavDestination.WORLDS, currentDestination, onNavigate, onCloseDrawer)
            item(Icons.Default.Image, "Server Icon", NavDestination.SERVER_ICON, currentDestination, onNavigate, onCloseDrawer)
        }
        HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = DarkBorder)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Website Portal: https://portal.sudarshancloud.com", color = Color(0xFF60A5FA), fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).clickable { uriHandler.openUri("https://portal.sudarshancloud.com") }.padding(vertical = 3.dp))
            Text("App developer: @alexbexok.com", color = TextSecondary, fontSize = 11.sp)
            Text("App tester: @yourlocal_pragbaler_73733", color = TextSecondary, fontSize = 11.sp)
            Text("Helper: aayushmc0", color = TextSecondary, fontSize = 11.sp)
            Text("Built using: Gradle 9.3.1", color = TextSecondary, fontSize = 11.sp)
            Text("©️2026 SudarshanCloud. All rights reserved.", color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun item(icon: ImageVector, label: String, dest: NavDestination, current: NavDestination, onNavigate: (NavDestination) -> Unit, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val selected = current == dest
    Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 1.dp).clip(RoundedCornerShape(6.dp)).background(if (selected) Color(0xFF0F4938) else Color.Transparent).clickable { onNavigate(dest); onClose() }.padding(horizontal = 12.dp, vertical = 9.dp).then(modifier)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (selected) Color(0xFF34D399) else TextSecondary, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(10.dp))
            Text(label, color = if (selected) TextPrimary else TextSecondary, fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        }
    }
}

@Composable
private fun section(title: String) {
    Text(title, color = Color(0xFF8C9DB5), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
}
