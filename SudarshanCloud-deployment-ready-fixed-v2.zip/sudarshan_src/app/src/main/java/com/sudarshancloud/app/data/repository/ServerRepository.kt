package com.sudarshancloud.app.data.repository

import android.content.Context
import android.util.Log
import com.sudarshancloud.app.data.api.ApiClient
import com.sudarshancloud.app.data.api.ConsoleLogEntry
import com.sudarshancloud.app.data.api.ConsoleWebSocketManager
import com.sudarshancloud.app.data.api.LogLevel
import com.sudarshancloud.app.data.db.AppDatabase
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.db.CommandHistoryEntity
import com.sudarshancloud.app.data.db.PanelConfigEntity
import com.sudarshancloud.app.data.db.ServerFolderEntity
import com.sudarshancloud.app.data.model.ConsoleCommandRequest
import com.sudarshancloud.app.data.model.CreateBackupRequest
import com.sudarshancloud.app.data.model.CreateFolderRequest
import com.sudarshancloud.app.data.model.DeleteFilesRequest
import com.sudarshancloud.app.data.model.PowerSignalRequest
import com.sudarshancloud.app.data.model.PteroApplicationServerAttributes
import com.sudarshancloud.app.data.model.PteroBackupAttributes
import com.sudarshancloud.app.data.model.PteroDatabaseAttributes
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroServerItem
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import retrofit2.Response
import java.io.IOException
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ServerRepository(context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val configDao = database.panelConfigDao()
    private val folderDao = database.serverFolderDao()
    private val serverDao = database.cachedServerDao()
    private val historyDao = database.commandHistoryDao()

    val webSocketManager = ConsoleWebSocketManager()

    val configFlow: Flow<PanelConfigEntity?> = configDao.getConfigFlow()
    val foldersFlow: Flow<List<ServerFolderEntity>> = folderDao.getAllFoldersFlow()
    val cachedServersFlow: Flow<List<CachedServerEntity>> = serverDao.getAllCachedServersFlow()

    private val _realtimeStatsMap = MutableStateFlow<Map<String, PteroStatsAttributes>>(emptyMap())
    val realtimeStatsMap: StateFlow<Map<String, PteroStatsAttributes>> = _realtimeStatsMap.asStateFlow()

    private val _isLiveConnected = MutableStateFlow(false)
    val isLiveConnected: StateFlow<Boolean> = _isLiveConnected.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    suspend fun initialize() {
        withContext(Dispatchers.IO) {
            val currentConfig = configDao.getConfig()
            if (currentConfig == null) {
                val defaultConfig = PanelConfigEntity(
                    panelUrl = "https://portal.sudarshancloud.com",
                    apiKey = "",
                    applicationApiKey = "",
                    showOtherServers = false,
                    userEmail = "",
                    username = "SudarshanUser"
                )
                configDao.saveConfig(defaultConfig)
                ApiClient.updateConfig(defaultConfig.panelUrl, defaultConfig.apiKey)
            } else {
                ApiClient.updateConfig(currentConfig.panelUrl, currentConfig.apiKey)
            }

            // Folders were an old local/demo feature. The panel is the source of truth
            // for the server list, so remove any legacy folder chips from existing installs.
            folderDao.clearFolders()
        }
    }

    suspend fun savePanelConfig(
        panelUrl: String,
        apiKey: String,
        applicationApiKey: String = "",
        showOtherServers: Boolean = false,
        userEmail: String? = null
    ) {
        withContext(Dispatchers.IO) {
            val existing = configDao.getConfig() ?: PanelConfigEntity()
            val updated = existing.copy(
                panelUrl = panelUrl.trim(),
                apiKey = apiKey.trim(),
                applicationApiKey = applicationApiKey.trim(),
                showOtherServers = showOtherServers,
                userEmail = userEmail?.trim()?.takeIf { it.isNotBlank() } ?: existing.userEmail
            )
            configDao.saveConfig(updated)
            ApiClient.updateConfig(updated.panelUrl, updated.apiKey)
        }
    }

    suspend fun fetchServersFromPanel(): Result<List<CachedServerEntity>> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val clientApiKey = config?.apiKey.orEmpty().trim()
        val applicationApiKey = config?.applicationApiKey.orEmpty().trim()
        val showOtherServers = config?.showOtherServers ?: false

        if (clientApiKey.isBlank()) {
            _lastError.value = "Add your Client API key (ptlc_) in Settings. Power, resources, files, console, and backups use this key."
            return@withContext Result.failure(Exception("Client API key not configured"))
        }
        if (showOtherServers && applicationApiKey.isBlank()) {
            _lastError.value = "See other panel servers is enabled, but no Application API key (ptla_) is configured."
            return@withContext Result.failure(Exception("Application API key required for other servers"))
        }

        try {
            val service = ApiClient.getService()
            // If an Application key is available, use the real node FQDN and resolve it
            // to an address for the UI. The Client API only exposes the node name.
            val nodeAddresses = if (applicationApiKey.isNotBlank()) {
                loadNodeAddresses(service, applicationApiKey)
            } else {
                emptyMap()
            }
            val entities: List<CachedServerEntity>
            val cachedById = serverDao.getAllCachedServers().associateBy { it.identifier }

            if (showOtherServers && applicationApiKey.isNotBlank()) {
                // Application API is the authoritative panel-wide list. Pterodactyl documents
                // this endpoint as paginated, with up to 100 servers per page.
                val allItems = mutableListOf<PteroApplicationServerAttributes>()
                var page = 1
                var totalPages = 1
                do {
                    val response = service.getApplicationServers(
                        page = page,
                        perPage = 100,
                        include = "allocations,node,user",
                        authHeader = toBearerHeader(applicationApiKey)
                    )
                    allItems += response.data.map { it.attributes }
                    totalPages = response.meta?.pagination?.totalPages ?: page
                    page++
                } while (page <= totalPages)

                // Determine actual client access from the Client API server list instead of
                // guessing from Application API owner relationships. Owner/user relationships
                // are not guaranteed to be present in every panel response.
                val clientAccessible = if (clientApiKey.isNotBlank()) {
                    runCatching {
                        service.getServers(include = "allocations", authHeader = toBearerHeader(clientApiKey))
                            .data
                            .associateBy { it.attributes.identifier }
                    }.getOrDefault(emptyMap())
                } else emptyMap()

                entities = allItems.map { attr ->
                    val cached = cachedById[attr.identifier]
                    val allocation = attr.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: attr.relationships?.allocations?.data?.firstOrNull()
                    val node = attr.relationships?.node?.data?.attributes
                    val allocationAlias = allocation?.attributes?.ipAlias?.takeIf(::isUsableHost)
                    val allocationIp = allocation?.attributes?.ip?.takeIf(::isUsableHost)
                    // Prefer a public allocation alias/IP. If the panel exposes a
                    // private bind address (common on multi-node setups), fall back
                    // to the node FQDN instead of showing an unusable address.
                    val reachableAllocation = allocationAlias?.takeIf(::isClientReachableHost)
                        ?: allocationIp?.takeIf(::isClientReachableHost)
                    val host = reachableAllocation
                        ?: node?.fqdn?.takeIf(::isUsableHost)
                        ?: allocationAlias
                        ?: allocationIp
                        ?: node?.name?.takeIf { it.isNotBlank() }
                        ?: cached?.ip?.takeIf(::isUsableHost)
                        ?: "Host unavailable"
                    val clientServer = clientAccessible[attr.identifier]?.attributes
                    val isOther = clientServer == null
                    val clientAllocation = clientServer?.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: clientServer?.relationships?.allocations?.data?.firstOrNull()
                    val finalAllocationAlias = clientAllocation?.attributes?.ipAlias?.takeIf(::isUsableHost)
                        ?: allocationAlias
                    val finalAllocationAddress = finalAllocationAlias?.takeIf(::isClientReachableHost)
                        ?: clientAllocation?.attributes?.ip?.takeIf(::isClientReachableHost)
                        ?: allocationIp?.takeIf(::isClientReachableHost)
                        ?: node?.fqdn?.takeIf(::isUsableHost)
                        ?: finalAllocationAlias
                        ?: clientAllocation?.attributes?.ip?.takeIf(::isUsableHost)
                        ?: allocationIp
                    val finalPort = clientAllocation?.attributes?.port ?: allocation?.attributes?.port ?: 25565

                    CachedServerEntity(
                        identifier = attr.identifier,
                        name = attr.name,
                        node = node?.name?.takeIf { it.isNotBlank() }
                            ?: cached?.node?.takeIf { it.isNotBlank() && it != "Unknown node" }
                            ?: "Node unavailable",
                        nodeAddress = resolveNodeAddress(node?.fqdn, node?.name?.let { nodeAddresses[it] })
                            .ifBlank { cached?.nodeAddress.orEmpty() },
                        ip = finalAllocationAddress
                            ?: host.takeIf(::isUsableHost)
                            ?: "Host unavailable",
                        port = if (finalPort > 0) finalPort else (cached?.port ?: 25565),
                        cpuLimit = attr.limits.cpu,
                        memoryLimit = attr.limits.memory,
                        diskLimit = attr.limits.disk,
                        currentState = if (attr.suspended) "suspended" else (attr.status?.takeIf { it.isNotBlank() } ?: "unknown"),
                        cpuUsage = 0.0,
                        memoryUsageBytes = 0,
                        diskUsageBytes = 0,
                        folderName = null,
                        isOtherServer = isOther
                    )
                }
            } else {
                // Client API is the correct source when the toggle is off: it returns only
                // servers the authenticated client account can access.
                val response = service.getServers(include = "allocations", authHeader = toBearerHeader(clientApiKey))
                entities = response.data.map { item ->
                    val attr = item.attributes
                    val cached = cachedById[attr.identifier]
                    val defaultAllocation = attr.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: attr.relationships?.allocations?.data?.firstOrNull()
                    val allocationAlias = defaultAllocation?.attributes?.ipAlias?.takeIf(::isUsableHost)
                    val allocationIp = defaultAllocation?.attributes?.ip?.takeIf(::isUsableHost)
                    val clientReachableAddress = allocationAlias?.takeIf(::isClientReachableHost)
                        ?: allocationIp?.takeIf(::isClientReachableHost)
                        ?: attr.node?.let { nodeAddresses[it] }?.takeIf(::isUsableHost)
                    CachedServerEntity(
                        identifier = attr.identifier,
                        name = attr.name,
                        node = attr.node?.takeIf { it.isNotBlank() }
                            ?: cached?.node?.takeIf { it.isNotBlank() && it != "Unknown node" }
                            ?: "Node unavailable",
                        nodeAddress = resolveNodeAddress(nodeAddresses[attr.node.orEmpty()], attr.node),
                        ip = clientReachableAddress
                            ?: allocationAlias
                            ?: allocationIp
                            ?: attr.node?.let { nodeAddresses[it] }.orEmpty().takeIf(::isUsableHost)
                            ?: cached?.ip?.takeIf(::isUsableHost)
                            ?: "Host unavailable",
                        port = defaultAllocation?.attributes?.port?.takeIf { it > 0 }
                            ?: cached?.port
                            ?: 25565,
                        cpuLimit = attr.limits.cpu,
                        memoryLimit = attr.limits.memory,
                        diskLimit = attr.limits.disk,
                        currentState = if (attr.isSuspended) "suspended" else "offline",
                        cpuUsage = 0.0,
                        memoryUsageBytes = 0,
                        diskUsageBytes = 0,
                        folderName = null,
                        isOtherServer = false
                    )
                }
            }

            // The API is authoritative: never retain stale/demo cards after a sync.
            serverDao.clearServers()
            if (entities.isNotEmpty()) serverDao.insertOrUpdateServers(entities)
            _isLiveConnected.value = true
            _lastError.value = null
            Result.success(entities)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Error fetching live servers from Pterodactyl", e)
            _lastError.value = "Pterodactyl sync failed: ${friendlyApiError(e)}"
            Result.failure(e)
        }
    }

    private suspend fun loadNodeAddresses(
        service: com.sudarshancloud.app.data.api.PterodactylApi,
        applicationApiKey: String
    ): Map<String, String> {
        return runCatching {
            val result = mutableMapOf<String, String>()
            var page = 1
            var totalPages = 1
            do {
                val response = service.getApplicationNodes(
                    page = page,
                    perPage = 100,
                    authHeader = toBearerHeader(applicationApiKey)
                )
                response.data.forEach { item ->
                    val fqdn = item.attributes.fqdn.trim()
                    if (item.attributes.name.isNotBlank() && fqdn.isNotBlank()) {
                        val resolved = runCatching {
                            InetAddress.getByName(fqdn).hostAddress
                        }.getOrNull()
                        result[item.attributes.name] = resolved?.takeIf { isUsableHost(it) } ?: fqdn
                    }
                }
                totalPages = response.meta?.pagination?.totalPages ?: page
                page++
            } while (page <= totalPages)
            result
        }.getOrDefault(emptyMap())
    }

    private fun resolveNodeAddress(primary: String?, fallback: String?): String {
        val candidate = primary?.trim().takeIf { !it.isNullOrBlank() } ?: fallback?.trim().orEmpty()
        if (!isUsableHost(candidate)) return ""
        return runCatching { InetAddress.getByName(candidate).hostAddress }
            .getOrNull()
            ?.takeIf { isUsableHost(it) }
            ?: candidate
    }

    private fun isUsableHost(value: String?): Boolean {
        val host = value?.trim().orEmpty()
        val normalized = host.lowercase(Locale.US)
        return host.isNotBlank() &&
            host != "0.0.0.0" &&
            host != "::" &&
            host != "::0" &&
            normalized != "unknown host" &&
            normalized != "unknown node" &&
            !normalized.contains("unavailable")
    }

    /**
     * Allocation addresses may be 0.0.0.0, loopback, or a private/container IP.
     * Those are valid bind addresses for Wings but are not the address a user
     * should copy into a game client. Prefer the allocation alias or node FQDN
     * when the allocation itself is not externally usable.
     */
    private fun isClientReachableHost(value: String?): Boolean {
        val host = value?.trim().orEmpty()
        if (!isUsableHost(host)) return false
        if (host.contains(":") && host.count { it == ':' } >= 2) {
            val ipv6 = host.lowercase(Locale.US)
            return ipv6 != "::1" && !ipv6.startsWith("fe80:") && !ipv6.startsWith("fc") && !ipv6.startsWith("fd")
        }
        val parts = host.split('.')
        if (parts.size != 4 || parts.any { it.toIntOrNull() == null }) return true
        val octets = parts.map { it.toInt() }
        if (octets.any { it !in 0..255 }) return false
        return when {
            octets[0] == 10 -> false
            octets[0] == 127 -> false
            octets[0] == 169 && octets[1] == 254 -> false
            octets[0] == 192 && octets[1] == 168 -> false
            octets[0] == 172 && octets[1] in 16..31 -> false
            else -> true
        }
    }

    private fun friendlyApiError(error: Throwable): String {
        if (error is ApiResponseException) {
            val detail = error.detail?.takeIf { it.isNotBlank() }
            return when (error.code) {
                400 -> "${error.operation} was rejected (HTTP 400).${detail?.let { " $it" } ?: " Check the server state and Pterodactyl limits."}"
                401 -> "The Client API key was rejected (HTTP 401). Check the key in Settings."
                403 -> "The Client API key is not permitted to perform this operation (HTTP 403). For other/admin servers, use an admin Client API key (ptlc_...)."
                404 -> "Server or panel API endpoint was not found (HTTP 404). Refresh the server list."
                409 -> "${error.operation} is temporarily blocked by the server state (HTTP 409).${detail?.let { " $it" } ?: ""}"
                429 -> "The panel rate limit was reached (HTTP 429). Telemetry polling will back off automatically."
                500 -> "The panel/Wings rejected the action (HTTP 500).${detail?.let { " $it" } ?: " Check the Panel and Wings logs."}"
                else -> "${error.operation} failed (HTTP ${error.code}).${detail?.let { " $it" } ?: ""}"
            }
        }
        if (error is HttpException) {
            return when (error.code()) {
                400 -> "${error::class.simpleName ?: "Panel request"} was rejected (HTTP 400). Check the server state, permissions, or Pterodactyl resource limits."
                401 -> "The Client API key was rejected (HTTP 401). Check the key in Settings."
                403 -> "The Client API key is not permitted to perform this operation (HTTP 403). For other/admin servers, use an admin Client API key (ptlc_...)."
                404 -> "Server or panel API endpoint was not found (HTTP 404). Refresh the server list."
                409 -> "The panel rejected the request because the server is busy or in a conflicting state (HTTP 409)."
                429 -> "The panel rate limit was reached (HTTP 429). Please wait for telemetry to back off."
                500 -> "The panel/Wings returned HTTP 500. Check Panel and Wings logs for the server-side exception."
                else -> "Panel request failed (HTTP ${error.code()})."
            }
        }
        val message = error.message.orEmpty()
        return when {
            message.contains("401") || message.contains("403") -> "API key was rejected (HTTP ${if (message.contains("403")) "403" else "401"}). Check the key and its permissions."
            message.contains("404") -> "Panel API endpoint was not found. Check the panel URL."
            message.contains("timeout", ignoreCase = true) -> "Panel request timed out."
            message.isBlank() -> error::class.simpleName ?: "Unknown error"
            else -> message.take(180)
        }
    }

    private class ApiResponseException(
        val operation: String,
        val code: Int,
        val detail: String?
    ) : IOException(
        buildString {
            append(operation)
            append(" failed (HTTP ")
            append(code)
            append(")")
            if (!detail.isNullOrBlank()) {
                append(": ")
                append(detail)
            }
            append(".")
        }
    )

    private fun requireSuccessful(response: Response<*>, operation: String) {
        if (!response.isSuccessful) {
            val detail = response.errorBody()
                ?.string()
                ?.let(::extractApiErrorDetail)
                ?.takeIf { it.isNotBlank() }
            throw ApiResponseException(operation, response.code(), detail)
        }
    }

    private fun extractApiErrorDetail(body: String): String {
        val jsonDetail = Regex("\"detail\"\\s*:\\s*\"([^\"]+)\"")
            .find(body)
            ?.groupValues
            ?.getOrNull(1)
            ?.replace("\\\"", "\"")
            ?.replace("\\n", " ")
            ?.trim()
        return (jsonDetail ?: body.trim()).take(240)
    }

    /**
     * Returns credentials valid for the Pterodactyl Client API.
     *
     * IMPORTANT: an Application API key (ptla_) is only for /api/application/*
     * endpoints. It must never be sent to /api/client/* endpoints such as power,
     * resources, files, console, or backups. Administrators who need to operate
     * servers discovered through the Application API must use a Client API key
     * belonging to an account with access to those servers (normally a root-admin
     * client key when using the "all servers" view).
     */
    private suspend fun authHeadersForServer(serverIdentifier: String): List<String> {
        val config = configDao.getConfig() ?: return emptyList()
        val clientKey = config.apiKey.trim()
        return clientKey
            .takeIf { it.isNotBlank() }
            ?.let { listOf(toBearerHeader(it)) }
            ?: emptyList()
    }

    private fun toBearerHeader(key: String): String {
        val cleanKey = key.trim()
        return if (cleanKey.startsWith("Bearer ", ignoreCase = true)) {
            cleanKey
        } else {
            "Bearer $cleanKey"
        }
    }

    private suspend fun <T> withServerAuth(
        serverIdentifier: String,
        request: suspend (authHeader: String) -> T
    ): Result<T> {
        val headers = authHeadersForServer(serverIdentifier)
        if (headers.isEmpty()) {
            return Result.failure(Exception("No API key is configured for this server."))
        }

        var lastError: Throwable? = null
        var serverError: Throwable? = null
        for (header in headers) {
            try {
                return Result.success(request(header))
            } catch (error: Exception) {
                lastError = error
                if (error is ApiResponseException && error.code >= 500) {
                    serverError = error
                }
            }
        }
        return Result.failure(serverError ?: lastError ?: Exception("Panel request failed."))
    }

    suspend fun fetchServerResources(serverIdentifier: String): Result<PteroStatsAttributes> = withContext(Dispatchers.IO) {
        val statsResult = withServerAuth(serverIdentifier) { authHeader ->
            ApiClient.getService()
                .getServerResources(serverIdentifier, authHeader)
                .attributes
        }

        if (statsResult.isSuccess) {
            try {
                val stats = statsResult.getOrThrow()
                val current = _realtimeStatsMap.value.toMutableMap()
                current[serverIdentifier] = stats
                _realtimeStatsMap.value = current

                // Update cached DB entity with latest stats
                val cached = serverDao.getServer(serverIdentifier)
                if (cached != null) {
                    serverDao.insertOrUpdateServers(
                        listOf(
                            cached.copy(
                                currentState = stats.currentState,
                                cpuUsage = stats.resources.cpuAbsolute,
                                memoryUsageBytes = stats.resources.memoryBytes,
                                diskUsageBytes = stats.resources.diskBytes
                            )
                        )
                    )
                }
                return@withContext Result.success(stats)
            } catch (e: Exception) {
                _lastError.value = "Live stats failed for $serverIdentifier: ${friendlyApiError(e)}"
                Log.w("ServerRepository", "Live stats fetch error: ${e.message}", e)
            }
        } else {
            val error = statsResult.exceptionOrNull()
            _lastError.value = "Live stats failed for $serverIdentifier: ${friendlyApiError(error ?: Exception())}"
            Log.w("ServerRepository", "Live stats fetch error", error)
        }

        val cached = serverDao.getServer(serverIdentifier)
        val message = if (cached?.isOtherServer == true) {
            "Live telemetry is unavailable for this server with the configured API keys."
        } else {
            "Live server telemetry is unavailable right now."
        }
        Log.w("ServerRepository", message)
        Result.failure(Exception(message))
    }

    suspend fun sendPowerAction(serverIdentifier: String, signal: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val cleanSignal = signal.trim().lowercase(Locale.US)
            if (cleanSignal !in setOf("start", "stop", "restart", "kill")) {
                return@withContext Result.failure(
                    IllegalArgumentException("Unsupported power action '$signal'.")
                )
            }

            // Pterodactyl exposes start/stop/restart/kill through the same Client
            // API power endpoint. Do not synthesize restart as stop+start: that can
            // race with Wings and can turn a recoverable 500 into a second action.
            issuePowerSignal(serverIdentifier, cleanSignal).getOrThrow()

            // The power endpoint returns 204. Give Wings a short moment to publish
            // the new state, then refresh telemetry without making the action depend
            // on the resource request succeeding.
            delay(500)
            fetchServerResources(serverIdentifier)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Error sending power signal $signal", e)
            _lastError.value = "Power action '$signal' failed: ${friendlyApiError(e)}"
            Result.failure(e)
        }
    }

    private suspend fun issuePowerSignal(
        serverIdentifier: String,
        signal: String
    ): Result<Unit> {
        val result: Result<Unit> = withServerAuth(serverIdentifier) { authHeader ->
            val response = ApiClient.getService().sendPowerSignal(
                serverIdentifier,
                PowerSignalRequest(signal),
                authHeader
            )
            requireSuccessful(response, "Power action '$signal'")
        }
        return result
    }

    suspend fun sendConsoleCommand(serverIdentifier: String, command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanCmd = command.trim()
        if (cleanCmd.isEmpty()) return@withContext Result.success(Unit)

        historyDao.insertCommand(
            CommandHistoryEntity(
                serverIdentifier = serverIdentifier,
                command = cleanCmd
            )
        )

        // Prefer the live WebSocket. If it is not connected, use the documented HTTP
        // command endpoint; neither path fabricates server output.
        val wsSent = webSocketManager.sendConsoleCommand(cleanCmd)
        if (!wsSent) {
            try {
                val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                    val response = ApiClient.getService().sendConsoleCommand(
                        serverIdentifier,
                        ConsoleCommandRequest(cleanCmd),
                        authHeader
                    )
                    requireSuccessful(response, "Command")
                    response
                }
                if (responseResult.isFailure) throw responseResult.exceptionOrNull()!!
            } catch (e: Exception) {
                Log.e("ServerRepository", "Console command failed", e)
                return@withContext Result.failure(e)
            }
        }

        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        webSocketManager.appendLocalLog(
            ConsoleLogEntry(
                rawText = "> $cleanCmd",
                timestamp = timeStr,
                level = LogLevel.COMMAND,
                source = "Console"
            )
        )
        Result.success(Unit)
    }

    suspend fun connectServerConsole(serverIdentifier: String) = withContext(Dispatchers.IO) {
        try {
            val wsResult = withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().getWebsocketCredentials(serverIdentifier, authHeader)
            }
            if (wsResult.isFailure) throw wsResult.exceptionOrNull()!!
            val wsData = wsResult.getOrThrow()
            webSocketManager.connect(wsData.data.socket, wsData.data.token)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Failed to retrieve websocket credentials", e)
            webSocketManager.appendLocalLog(
                ConsoleLogEntry(
                    rawText = "[System] Could not obtain live console credentials: ${friendlyApiError(e)}",
                    level = LogLevel.ERROR,
                    source = "Client"
                )
            )
        }
    }

    suspend fun listFiles(serverIdentifier: String, directory: String = "/"): Result<List<PteroFileAttributes>> = withContext(Dispatchers.IO) {
        val root = normalizeDirectory(directory)
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().listFiles(serverIdentifier, root, authHeader)
            }.map { response -> response.data.map { it.attributes } }
        } catch (e: Exception) {
            Log.e("ServerRepository", "List files failed", e)
            Result.failure(Exception("File list failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun getFileContent(serverIdentifier: String, filePath: String): Result<String> = withContext(Dispatchers.IO) {
        val path = normalizeFilePath(filePath)
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().getFileContents(serverIdentifier, path, authHeader).string()
            }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Get file contents failed", e)
            Result.failure(Exception("Could not open file: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun saveFileContent(serverIdentifier: String, filePath: String, content: String): Result<Unit> = withContext(Dispatchers.IO) {
        val path = normalizeFilePath(filePath)
        try {
            val body = content.toRequestBody("text/plain; charset=utf-8".toMediaTypeOrNull())
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().writeFileContents(serverIdentifier, path, body, authHeader)
                requireSuccessful(response, "Save")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Save file failed", e)
            Result.failure(Exception("Save failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun createFolder(serverIdentifier: String, root: String, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanName = name.trim().trim('/')
        if (cleanName.isBlank() || cleanName.contains("/")) return@withContext Result.failure(Exception("Enter a valid folder name."))
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().createFolder(
                    serverIdentifier,
                    CreateFolderRequest(normalizeDirectory(root), cleanName),
                    authHeader
                )
                requireSuccessful(response, "Create folder")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Create folder failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun createFile(serverIdentifier: String, root: String, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanName = name.trim().trim('/')
        if (cleanName.isBlank() || cleanName.contains("/")) return@withContext Result.failure(Exception("Enter a valid file name."))
        val path = normalizeDirectory(root).trimEnd('/') + "/" + cleanName
        try {
            val body = "".toRequestBody("text/plain; charset=utf-8".toMediaTypeOrNull())
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().writeFileContents(serverIdentifier, path, body, authHeader)
                requireSuccessful(response, "Create file")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Create file failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun deleteFiles(serverIdentifier: String, root: String, files: List<String>): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().deleteFiles(
                    serverIdentifier,
                    DeleteFilesRequest(normalizeDirectory(root), files),
                    authHeader
                )
                requireSuccessful(response, "Delete")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(Exception("Delete failed: ${friendlyApiError(e)}", e))
        }
    }

    private fun normalizeDirectory(directory: String): String {
        val value = directory.trim()
        if (value.isBlank() || value == "/") return "/"
        return "/" + value.trim('/')
    }

    private fun normalizeFilePath(path: String): String {
        val value = path.trim()
        return if (value.startsWith("/")) value else "/$value"
    }


    suspend fun listBackups(serverIdentifier: String): Result<List<PteroBackupAttributes>> = withContext(Dispatchers.IO) {
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().listBackups(serverIdentifier, authHeader)
            }.map { response -> response.data.map { it.attributes } }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Backups failed", e)
            Result.failure(e)
        }
    }

    suspend fun createBackup(serverIdentifier: String, name: String?): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().createBackup(
                    serverIdentifier,
                    CreateBackupRequest(name = name?.trim()?.takeIf { it.isNotBlank() }),
                    authHeader
                )
                requireSuccessful(response, "Create backup")
                response
            }
            if (responseResult.isFailure) throw responseResult.exceptionOrNull()!!
            val response = responseResult.getOrThrow()
            Log.d("ServerRepository", "Backup request accepted: ${response.body()?.attributes?.uuid ?: "unknown"}")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Create backup failed", e)
            Result.failure(Exception("Create backup failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun deleteBackup(serverIdentifier: String, backupUuid: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val responseResult = withServerAuth(serverIdentifier) { authHeader ->
                val response = ApiClient.getService().deleteBackup(serverIdentifier, backupUuid, authHeader)
                requireSuccessful(response, "Delete backup")
                response
            }
            if (responseResult.isFailure) Result.failure(responseResult.exceptionOrNull()!!)
            else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Delete backup failed", e)
            Result.failure(Exception("Delete backup failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun listDatabases(serverIdentifier: String): Result<List<PteroDatabaseAttributes>> = withContext(Dispatchers.IO) {
        try {
            withServerAuth(serverIdentifier) { authHeader ->
                ApiClient.getService().listDatabases(serverIdentifier, authHeader)
            }.map { response -> response.data.map { it.attributes } }
        } catch (e: Exception) {
            Log.e("ServerRepository", "Databases call failed", e)
            Result.failure(e)
        }
    }


}
