# SudarshanCloud Android - Deployment Readiness Notes

## Fixed in this build

- Server addresses for "other panel servers" now prefer a reachable allocation alias/IP and fall back to the node FQDN when the allocation is a private/bind address.
- Application API keys (`ptla_`) are no longer used for Client API operations.
- Power, resource telemetry, console, file, database, and backup operations use the configured Client API key (`ptlc_`).
- Restart uses the documented Pterodactyl `restart` power signal directly instead of a stop/start fallback that could race with Wings.
- Backup creation now uses a `Response` wrapper so HTTP errors are captured with the real status/detail instead of being converted into a generic Retrofit exception.
- Backup request model now matches the Pterodactyl frontend shape (`name`, optional `ignored`, `is_locked`).
- Error handling now distinguishes common 400/401/403/404/409/429/500 conditions.
- Live telemetry remains on a single-request-at-a-time 3-second cadence per polling loop and updates the Room cache used by the server cards.
- Settings/README now explicitly document the Client API key requirement for controlling servers discovered through the Application API.

## Required Pterodactyl configuration

When "Show other panel servers" is enabled:

1. Configure a valid `ptlc_...` Client API key for the account that is allowed to control the servers.
2. Configure a valid `ptla_...` Application API key for panel-wide server discovery.
3. The `ptla_...` key must not be used as a replacement for the Client API key.

Pterodactyl's Client API power endpoint accepts `start`, `stop`, `restart`, and `kill`, and successful power requests return HTTP 204. Resource usage is exposed by `/api/client/servers/{server}/resources`. Backup creation is exposed by `/api/client/servers/{server}/backups`.

## Verification

The source was statically reviewed for the requested flows and the project was checked for endpoint/auth consistency.

A full Gradle test/build could not be executed in this environment because the Gradle wrapper distribution was not cached and this environment has no outbound network access to download it. Run:

    ./gradlew testDebugUnitTest
    ./gradlew assembleDebug

For a release artifact, configure the signing environment used by `app/build.gradle.kts` and run:

    ./gradlew assembleRelease
