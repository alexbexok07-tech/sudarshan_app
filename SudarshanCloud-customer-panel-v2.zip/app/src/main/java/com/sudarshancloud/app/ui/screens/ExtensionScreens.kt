package com.sudarshancloud.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroStartupVariable
import com.sudarshancloud.app.data.tools.ModProject
import com.sudarshancloud.app.data.tools.ModVersion
import com.sudarshancloud.app.data.tools.PanelTools
import com.sudarshancloud.app.data.tools.SoftwareBuild
import com.sudarshancloud.app.data.tools.SoftwareType
import com.sudarshancloud.app.data.tools.SoftwareVersion
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.NumberFormat

internal val ExtGreen = Color(0xFF10B981)
internal val ExtBlue = Color(0xFF2563EB)
internal val ExtRed = Color(0xFFDC2626)
internal val ExtGold = Color(0xFFEAB308)
internal val ExtCardBg = Color(0xE6162032)

// ---------------------------------------------------------------------------
// Shared building blocks
// ---------------------------------------------------------------------------

@Composable
internal fun ExtHeader(title: String, subtitle: String, onRefresh: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextSecondary, fontSize = 12.sp)
        }
        if (onRefresh != null) IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = TextPrimary) }
    }
}

@Composable
internal fun ExtCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(ExtCardBg)
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp)).padding(12.dp),
        content = content
    )
}

@Composable
internal fun ExtButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    color: Color = ExtBlue, icon: ImageVector? = null, enabled: Boolean = true
) {
    Row(
        modifier.clip(RoundedCornerShape(6.dp)).background(if (enabled) color else color.copy(alpha = 0.35f))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(5.dp)) }
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
internal fun ExtIcon(url: String?, size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(6.dp)).background(Color(0xFF243247))) {
        if (!url.isNullOrBlank()) AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(size))
    }
}

@Composable
internal fun ExtDropdown(
    label: String, options: List<Pair<String, String>>, selected: String,
    onSelect: (String) -> Unit, modifier: Modifier = Modifier
) {
    var open by remember { mutableStateOf(false) }
    val shown = options.firstOrNull { it.first == selected }?.second ?: selected
    Column(modifier) {
        Text(label, color = TextSecondary, fontSize = 11.sp)
        Spacer(Modifier.height(3.dp))
        Box {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(DarkSurfaceElevated)
                    .border(1.dp, DarkBorder, RoundedCornerShape(6.dp)).clickable { open = true }
                    .padding(start = 10.dp, top = 9.dp, bottom = 9.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(shown, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Icon(Icons.Default.ArrowDropDown, null, tint = TextSecondary)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.heightIn(max = 360.dp)) {
                options.forEach { (value, text) ->
                    DropdownMenuItem(text = { Text(text) }, onClick = { onSelect(value); open = false })
                }
            }
        }
    }
}

private fun fmt(n: Long): String = NumberFormat.getInstance().format(n)

// ---------------------------------------------------------------------------
// MODS / PLUGINS browser (Modrinth)
// ---------------------------------------------------------------------------

@Composable
fun ModBrowserScreen(
    server: CachedServerEntity?,
    isPlugins: Boolean,
    defaultGameVersion: String?,
    installedFiles: List<PteroFileAttributes>,
    onRefreshInstalled: () -> Unit,
    onOpenFiles: () -> Unit,
    onDeleteInstalled: (String) -> Unit,
    onFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val dir = if (isPlugins) "/plugins" else "/mods"
    val projectType = if (isPlugins) "plugin" else "mod"
    val loaderChoices = if (isPlugins) listOf("paper", "spigot", "bukkit", "purpur", "folia", "velocity", "bungeecord", "waterfall")
    else listOf("fabric", "forge", "neoforge", "quilt")

    var tab by remember(isPlugins) { mutableStateOf(0) }
    var query by remember(isPlugins) { mutableStateOf("") }
    var gameVersion by remember(isPlugins, defaultGameVersion) { mutableStateOf(defaultGameVersion.orEmpty()) }
    var loader by remember(isPlugins) { mutableStateOf(loaderChoices.first()) }
    var sort by remember(isPlugins) { mutableStateOf("downloads") }
    var size by remember(isPlugins) { mutableStateOf("48") }
    var gameVersions by remember { mutableStateOf<List<String>>(emptyList()) }
    var results by remember(isPlugins) { mutableStateOf<List<ModProject>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var installing by remember { mutableStateOf<String?>(null) }
    var versionsFor by remember { mutableStateOf<ModProject?>(null) }
    var refreshTick by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val uriHandler = LocalUriHandler.current

    LaunchedEffect(Unit) { PanelTools.gameVersions().onSuccess { gameVersions = it } }

    LaunchedEffect(query, gameVersion, loader, sort, size, isPlugins, refreshTick) {
        delay(350)
        loading = true; error = null
        val r = PanelTools.searchProjects(projectType, query.trim(), gameVersion.ifBlank { null }, loader, sort, size.toIntOrNull() ?: 48)
        r.onSuccess { results = it }.onFailure { error = it.message ?: "Search failed" }
        loading = false
    }

    suspend fun installVersion(v: ModVersion, p: ModProject) {
        val srv = server ?: run { onFeedback("Select a server first"); return }
        installing = p.id
        PanelTools.ensureFolder(srv.identifier, "/", dir.trim('/'))
        val r = PanelTools.pullFile(srv.identifier, v.fileUrl, dir, v.fileName)
        installing = null
        if (r.isSuccess) {
            onFeedback("Installed ${p.title} (${v.fileName}). Restart the server to load it.")
            onRefreshInstalled()
        } else onFeedback(r.exceptionOrNull()?.message ?: "Install failed")
    }

    fun quickInstall(p: ModProject) {
        scope.launch {
            installing = p.id
            val vs = PanelTools.projectVersions(p.id, loader, gameVersion.ifBlank { null })
            val first = vs.getOrNull()?.firstOrNull()
            if (first == null) {
                installing = null
                onFeedback(vs.exceptionOrNull()?.message ?: "No $loader build of ${p.title} for ${gameVersion.ifBlank { "any version" }}")
            } else installVersion(first, p)
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ExtButton("Browse", { tab = 0 }, color = if (tab == 0) ExtGreen else Color(0xFF334155))
            ExtButton("Installed (${installedFiles.count { it.isFile }})", { tab = 1; onRefreshInstalled() }, color = if (tab == 1) ExtGreen else Color(0xFF334155))
        }
        if (tab == 1) {
            DirectoryToolScreen(
                title = if (isPlugins) "Plugins" else "Mods",
                description = "Files currently in $dir on your server.",
                directory = dir, files = installedFiles, onRefresh = onRefreshInstalled,
                onOpenFiles = onOpenFiles, onDelete = onDeleteInstalled
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(160.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExtHeader(if (isPlugins) "Plugins" else "Mods", "Browse Modrinth and install straight onto your server.")
                        OutlinedTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search ${if (isPlugins) "plugins" else "mods"}...") }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ExtDropdown("Versions", listOf("" to "Any") + gameVersions.map { it to it }, gameVersion, { gameVersion = it }, Modifier.weight(1f))
                            ExtDropdown("Server Loaders", loaderChoices.map { it to it.replaceFirstChar { c -> c.uppercase() } }, loader, { loader = it }, Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ExtDropdown("Sort By", listOf("downloads" to "Downloads", "relevance" to "Relevance", "newest" to "Newest", "updated" to "Recently updated", "follows" to "Follows"), sort, { sort = it }, Modifier.weight(1f))
                            ExtDropdown("Providers", listOf("modrinth" to "Modrinth"), "modrinth", { }, Modifier.weight(1f))
                            ExtDropdown("Size", listOf("12", "24", "48", "100").map { it to it }, size, { size = it }, Modifier.weight(0.7f))
                        }
                        if (loading) Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(16.dp), color = ExtGold, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp)); Text("Searching...", color = TextSecondary, fontSize = 12.sp)
                        }
                        error?.let {
                            Text(it, color = Color(0xFFF87171), fontSize = 12.sp)
                            ExtButton("Retry", { refreshTick++ })
                        }
                        if (!loading && error == null && results.isEmpty())
                            Text("Nothing found. Try another loader or set Versions to Any.", color = TextMuted, fontSize = 12.sp)
                    }
                }
                items(results, key = { it.id }) { p ->
                    ModCard(
                        p = p, busy = installing == p.id,
                        onInstall = { quickInstall(p) },
                        onVersions = { versionsFor = p },
                        onOpen = { uriHandler.openUri("https://modrinth.com/${p.projectType}/${p.slug}") }
                    )
                }
            }
        }
    }

    versionsFor?.let { proj ->
        var list by remember(proj.id, loader, gameVersion) { mutableStateOf<List<ModVersion>?>(null) }
        var listError by remember(proj.id, loader, gameVersion) { mutableStateOf<String?>(null) }
        LaunchedEffect(proj.id, loader, gameVersion) {
            PanelTools.projectVersions(proj.id, loader, gameVersion.ifBlank { null })
                .onSuccess { list = it }.onFailure { listError = it.message; list = emptyList() }
        }
        AlertDialog(
            onDismissRequest = { versionsFor = null },
            title = { Text(proj.title, fontSize = 16.sp) },
            text = {
                val l = list
                when {
                    l == null -> CircularProgressIndicator(color = ExtGold)
                    l.isEmpty() -> Text(listError ?: "No versions for $loader ${gameVersion.ifBlank { "(any version)" }}.", fontSize = 13.sp)
                    else -> LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(l, key = { it.id }) { v ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(v.name.ifBlank { v.versionNumber }, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${v.versionNumber} • MC ${v.gameVersions.take(3).joinToString(", ")}${if (v.gameVersions.size > 3) "…" else ""}", fontSize = 11.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${v.datePublished} • ${fmt(v.downloads)} downloads", fontSize = 10.sp, color = TextMuted)
                                }
                                ExtButton("Install", { scope.launch { installVersion(v, proj); versionsFor = null } }, icon = Icons.Default.Download)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { versionsFor = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun ModCard(p: ModProject, busy: Boolean, onInstall: () -> Unit, onVersions: () -> Unit, onOpen: () -> Unit) {
    var expanded by remember(p.id) { mutableStateOf(false) }
    ExtCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ExtIcon(p.iconUrl, 34.dp)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(p.title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("⬇ ${fmt(p.downloads)}", color = TextSecondary, fontSize = 10.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(p.description, color = TextSecondary, fontSize = 11.sp, maxLines = if (expanded) 20 else 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.heightIn(min = 44.dp))
        if (p.description.length > 90) Text(if (expanded) "Show less" else "Read more", color = TextMuted, fontSize = 10.sp, modifier = Modifier.clickable { expanded = !expanded }.padding(vertical = 2.dp))
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            IconButton(onClick = onOpen, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.OpenInNew, "Open on Modrinth", tint = TextSecondary, modifier = Modifier.size(16.dp)) }
            Spacer(Modifier.weight(1f))
            ExtButton("Versions", onVersions, color = Color(0xFF334155), icon = Icons.Default.List)
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = ExtGold, strokeWidth = 2.dp)
            else ExtButton("Install", onInstall, icon = Icons.Default.Download)
        }
    }
}

// ---------------------------------------------------------------------------
// VERSION CHANGER (MCJars)
// ---------------------------------------------------------------------------

private suspend fun installSoftwareBuild(
    serverId: String, build: SoftwareBuild, jarName: String
): Result<String> {
    PanelTools.powerSignal(serverId, "stop")
    delay(4000)
    val jar = build.jarUrl
    val downloads = build.steps.filter { it.type == "download" && !it.url.isNullOrBlank() }
    if (jar != null && downloads.size <= 1) {
        PanelTools.deletePath(serverId, "/", jarName)
        val r = PanelTools.pullFile(serverId, jar, "/", jarName)
        return if (r.isSuccess) Result.success("Installed as $jarName") else Result.failure(r.exceptionOrNull() ?: Exception("Download failed"))
    }
    if (build.steps.isNotEmpty()) {
        for (step in build.steps) {
            when (step.type) {
                "download" -> {
                    val u = step.url ?: continue
                    val f = step.file?.substringAfterLast('/') ?: jarName
                    PanelTools.deletePath(serverId, "/", f)
                    val r = PanelTools.pullFile(serverId, u, "/", f)
                    if (r.isFailure) return Result.failure(r.exceptionOrNull() ?: Exception("Download failed"))
                }
                "unzip" -> step.file?.let { f -> PanelTools.decompress(serverId, "/", f.substringAfterLast('/')) }
                "remove" -> step.file?.let { f -> PanelTools.deletePath(serverId, "/", f.substringAfterLast('/')) }
            }
        }
        return Result.success("Installed (${build.steps.size} steps)")
    }
    val zip = build.zipUrl
    if (zip != null) {
        val r = PanelTools.pullFile(serverId, zip, "/", "server-download.zip")
        if (r.isFailure) return Result.failure(r.exceptionOrNull() ?: Exception("Download failed"))
        PanelTools.decompress(serverId, "/", "server-download.zip")
        PanelTools.deletePath(serverId, "/", "server-download.zip")
        return Result.success("Extracted server files")
    }
    return Result.failure(Exception("This build has no downloadable file"))
}

@Composable
fun SoftwareChangerScreen(
    server: CachedServerEntity?,
    startupVariables: List<PteroStartupVariable>,
    onUpdateVariable: (String, String) -> Unit,
    onFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var stage by remember { mutableStateOf(0) }
    var types by remember { mutableStateOf<List<SoftwareType>>(emptyList()) }
    var type by remember { mutableStateOf<SoftwareType?>(null) }
    var versions by remember { mutableStateOf<List<SoftwareVersion>>(emptyList()) }
    var version by remember { mutableStateOf<SoftwareVersion?>(null) }
    var builds by remember { mutableStateOf<List<SoftwareBuild>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<SoftwareBuild?>(null) }
    var installing by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    val jarName = startupVariables.firstOrNull { it.envVariable == "SERVER_JARFILE" }
        ?.let { it.serverValue ?: it.defaultValue }?.takeIf { it.isNotBlank() } ?: "server.jar"

    LaunchedEffect(tick) {
        loading = true; error = null
        PanelTools.softwareTypes().onSuccess { types = it }.onFailure { error = it.message ?: "Could not reach MCJars" }
        loading = false
    }

    fun openType(t: SoftwareType) {
        type = t; stage = 1; versions = emptyList(); error = null
        scope.launch {
            loading = true
            PanelTools.softwareVersions(t.id).onSuccess { versions = it }.onFailure { error = it.message ?: "Could not load versions" }
            loading = false
        }
    }

    fun openVersion(v: SoftwareVersion) {
        val t = type ?: return
        version = v; stage = 2; builds = emptyList(); error = null
        scope.launch {
            loading = true
            PanelTools.softwareBuilds(t.id, v.id).onSuccess { builds = it }.onFailure { error = it.message ?: "Could not load builds" }
            loading = false
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(160.dp),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                ExtHeader(
                    when (stage) { 0 -> "Version Changer"; 1 -> type?.name ?: ""; else -> "${type?.name} ${version?.id}" },
                    when (stage) { 0 -> "Pick your server software"; 1 -> "Pick a Minecraft version"; else -> "Pick a build to install as $jarName" },
                    onRefresh = { if (stage == 0) tick++ else if (stage == 1) type?.let { openType(it) } else version?.let { openVersion(it) } }
                )
                if (loading) Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(16.dp), color = ExtGold, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp)); Text("Loading...", color = TextSecondary, fontSize = 12.sp)
                }
                error?.let { Text(it, color = Color(0xFFF87171), fontSize = 12.sp) }
                if (installing) Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(16.dp), color = ExtGreen, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp)); Text("Stopping server and installing...", color = TextPrimary, fontSize = 12.sp)
                }
            }
        }
        if (stage > 0) item {
            ExtCard(Modifier.clickable { if (stage == 2) { stage = 1; builds = emptyList() } else { stage = 0; versions = emptyList() } }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Go Back", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (stage == 2) "Return to versions" else "Return to server software types", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
        when (stage) {
            0 -> items(types, key = { it.id }) { t ->
                ExtCard(Modifier.clickable { openType(t) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ExtIcon(t.icon, 38.dp)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(t.name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (t.deprecated) { Spacer(Modifier.width(4.dp)); Text("☠", fontSize = 12.sp) }
                                else if (t.experimental) { Spacer(Modifier.width(4.dp)); Icon(Icons.Default.Warning, null, tint = ExtGold, modifier = Modifier.size(14.dp)) }
                            }
                            Text("${t.minecraftVersions} versions", color = TextSecondary, fontSize = 10.sp)
                            Text("${t.builds} builds", color = TextMuted, fontSize = 9.sp)
                        }
                    }
                }
            }
            1 -> items(versions, key = { it.id }) { v ->
                ExtCard(Modifier.clickable { openVersion(v) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ExtIcon(type?.icon, 32.dp)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.id, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(v.type, color = TextMuted, fontSize = 9.sp)
                        }
                        Text("${v.builds} ${if (v.builds == 1) "Build" else "Builds"}", color = TextSecondary, fontSize = 10.sp)
                    }
                }
            }
            else -> items(builds, key = { it.id }) { b ->
                ExtCard {
                    Text(b.name.ifBlank { "Build ${b.buildNumber}" }, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("#${b.buildNumber}${if (b.experimental) " • experimental" else ""}", color = if (b.experimental) ExtGold else TextSecondary, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    ExtButton("Install", { confirm = b }, Modifier.fillMaxWidth(), color = ExtGreen, icon = Icons.Default.Download, enabled = !installing)
                }
            }
        }
    }

    confirm?.let { b ->
        val srv = server
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Install ${type?.name} ${version?.id}?", fontSize = 16.sp) },
            text = {
                Text(
                    "The server will be stopped and $jarName will be replaced with ${type?.name} ${version?.id} (build #${b.buildNumber}).\n\n" +
                        "Downgrading can corrupt worlds — make a backup first. Start the server again once the install finishes." +
                        if (type?.id in listOf("FORGE", "NEOFORGE")) "\n\nForge/NeoForge may need its installer to run — check the console on first start." else "",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    if (srv == null) { onFeedback("Select a server first"); return@TextButton }
                    scope.launch {
                        installing = true
                        val r = installSoftwareBuild(srv.identifier, b, jarName)
                        installing = false
                        if (r.isSuccess) {
                            val mcVar = startupVariables.firstOrNull { it.envVariable in setOf("MINECRAFT_VERSION", "MC_VERSION", "VERSION") && it.isEditable }
                            val v = version
                            if (mcVar != null && v != null) onUpdateVariable(mcVar.envVariable, v.id)
                            onFeedback("${type?.name} ${version?.id} #${b.buildNumber} installed — start your server")
                        } else onFeedback(r.exceptionOrNull()?.message ?: "Install failed")
                    }
                }) { Text("Install", color = ExtGreen) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}
