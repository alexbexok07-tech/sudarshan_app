package com.sudarshancloud.app.data.tools

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Encrypted storage for the optional Cloudflare credentials used by the Subdomains tool. */
class ToolPrefs(context: Context) {
    private val prefs: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "sudarshan_tool_prefs", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        context.getSharedPreferences("sudarshan_tool_prefs_fallback", Context.MODE_PRIVATE)
    }

    fun cloudflare(): CloudflareConfig? {
        val t = prefs.getString("cf_token", "").orEmpty()
        val z = prefs.getString("cf_zone", "").orEmpty()
        val d = prefs.getString("cf_domain", "").orEmpty()
        return if (t.isNotBlank() && z.isNotBlank() && d.isNotBlank()) CloudflareConfig(t, z, d) else null
    }

    fun saveCloudflare(cfg: CloudflareConfig) {
        prefs.edit().putString("cf_token", cfg.token.trim()).putString("cf_zone", cfg.zoneId.trim())
            .putString("cf_domain", cfg.baseDomain.trim().lowercase().removePrefix(".")).apply()
    }

    fun clearCloudflare() { prefs.edit().remove("cf_token").remove("cf_zone").remove("cf_domain").apply() }
}
