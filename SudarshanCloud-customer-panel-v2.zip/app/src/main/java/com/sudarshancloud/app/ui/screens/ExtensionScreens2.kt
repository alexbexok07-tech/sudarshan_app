package com.sudarshancloud.app.ui.screens

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.tools.CloudflareConfig
import com.sudarshancloud.app.data.tools.DnsRecord
import com.sudarshancloud.app.data.tools.PanelTools
import com.sudarshancloud.app.data.tools.PingResult
import com.sudarshancloud.app.data.tools.ToolPrefs
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val IP_LITERAL = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

/** Hostnames/IPs that might reach this server, best first. */
internal fun serverHosts(server: CachedServerEntity?): List<String> {
    if (server == null) return emptyList()
    val all = listOf(server.ip, server.nodeAddress).map { it.trim() }
        .filter { it.isNotBlank() && it != "0.0.0.0" && !it.equals("unknown host", true) && !it.equals("unknown node", true) }
        .distinct()
    return all.filter { !IP_LITERAL.matches(it) } + all.filter { IP_LITERAL.matches(it) }
}

private val ANSI = Regex("\u001B\\[[;\\d]*[A-Za-z]")

private fun parseListedPlayers(lines: List<String>): List<String> {
    val clean = lines.map { ANSI.replace(it, "").trim() }
    val re = Regex("(?i)There are \\d+ of a max of \\d+ players online:?(.*)$")
    val idx = clean.indexOfLast { re.containsMatchIn(it) }
    if (idx < 0) return emptyList()
    var names = re.find(clean[idx])?.groupValues?.get(1)?.trim().orEmpty()
    if (names.isBlank() && idx + 1 < clean.size) names = clean[idx + 1].replace(Regex("^\\[[^\\]]*\\][^:]*:\\s*"), "").trim()
    return names.split(",").map { it.trim().removePrefix("[").substringAfterLast("] ").trim() }
        .filter { it.matches(Regex("[A-Za-z0-9_.]{1,20}")) }
}

// ---------------------------------------------------------------------------
// PLAYERS — live from the running server
// ---------------------------------------------------------------------------

@Composable
fun LivePlayersScreen(
    server: CachedServerEntity?,
    consoleLines: List<String>,
    onFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var ping by remember(server?.identifier) { mutableStateOf<PingResult?>(null) }
    var pingError by remember(server?.identifier) { mutableStateOf<String?>(null) }
    var polling by remember(server?.identifier) { mutableStateOf(true) }
    var confirmBan by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val hosts = remember(server?.identifier, server?.ip, server?.nodeAddress) { serverHosts(server) }

    LaunchedEffect(server?.identifier) {
        val s = server ?: return@LaunchedEffect
        while (true) {
            polling = true
            var ok: PingResult? = null
            var err: String? = null
            if (hosts.isEmpty()) err = "No usable address for this server"
            for (h in hosts) {
                val r = PanelTools.ping(h, s.port)
                if (r.isSuccess) { ok = r.getOrNull(); break } else err = r.exceptionOrNull()?.message ?: "Unreachable"
            }
            ping = ok
            pingError = if (ok == null) err else null
            if (ok != null && ok.online > 0) PanelTools.sendCommand(s.identifier, "list") // fills the full name list via console
            polling = false
            delay(8000)
        }
    }

    val parsed by remember(consoleLines.size, consoleLines.lastOrNull()) { derivedStateOf { parseListedPlayers(consoleLines.takeLast(300)) } }
    val p = ping
    val names: List<String> = when {
        p == null -> emptyList()
        p.online == 0 -> emptyList()
        parsed.size == p.online -> parsed
        p.players.isNotEmpty() -> (p.players + parsed).distinct()
        else -> parsed
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ExtHeader("Players", "Live from the running server", onRefresh = null)
        if (server == null) { Text("No server selected", color = TextSecondary); return@Column }
        ExtCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (p != null) Color(0xFF22C55E) else Color(0xFF64748B)))
                Spacer(Modifier.width(8.dp))
                Text(if (p != null) "Online" else "Offline / unreachable", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                if (polling) CircularProgressIndicator(Modifier.size(14.dp), color = ExtGold, strokeWidth = 2.dp)
            }
            if (p != null) {
                Spacer(Modifier.height(8.dp))
                Text("${p.online} / ${p.max} players", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (p.motd.isNotBlank()) Text(p.motd, color = TextSecondary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${p.versionName} • ${p.latencyMs} ms", color = TextMuted, fontSize = 11.sp)
            } else {
                Spacer(Modifier.height(6.dp))
                Text(pingError ?: "Checking...", color = TextMuted, fontSize = 12.sp)
                Text("Start the server and make sure its port is reachable. Updates every 8 seconds.", color = TextMuted, fontSize = 11.sp)
            }
        }
        if (p != null && p.online > 0 && names.isEmpty())
            Text("${p.online} player(s) online — fetching names from the console (the server may hide its player sample)...", color = TextSecondary, fontSize = 12.sp)
        names.forEach { name ->
            ExtCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ExtIcon("https://mc-heads.net/avatar/$name/64", 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExtButton("Kick", { scope.launch { PanelTools.sendCommand(server.identifier, "kick $name").also { onFeedback(if (it.isSuccess) "Kicked $name" else it.exceptionOrNull()?.message ?: "Failed") } } }, color = Color(0xFFD97706))
                    ExtButton("Ban", { confirmBan = name }, color = ExtRed)
                    ExtButton("OP", { scope.launch { PanelTools.sendCommand(server.identifier, "op $name").also { onFeedback(if (it.isSuccess) "Opped $name" else it.exceptionOrNull()?.message ?: "Failed") } } }, color = Color(0xFF334155))
                }
            }
        }
    }

    confirmBan?.let { name ->
        AlertDialog(
            onDismissRequest = { confirmBan = null },
            title = { Text("Ban $name?") },
            text = { Text("Runs \"ban $name\" on the server console.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmBan = null
                    val s = server ?: return@TextButton
                    scope.launch { PanelTools.sendCommand(s.identifier, "ban $name").also { onFeedback(if (it.isSuccess) "Banned $name" else it.exceptionOrNull()?.message ?: "Failed") } }
                }) { Text("Ban", color = ExtRed) }
            },
            dismissButton = { TextButton(onClick = { confirmBan = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------------------
// VOTIFIER TESTER
// ---------------------------------------------------------------------------

@Composable
fun VotifierScreen(server: CachedServerEntity?, onFeedback: (String) -> Unit, modifier: Modifier = Modifier) {
    var host by remember(server?.identifier) { mutableStateOf(serverHosts(server).firstOrNull().orEmpty()) }
    var port by remember { mutableStateOf("8192") }
    var username by remember { mutableStateOf("SudarshanTest") }
    var service by remember { mutableStateOf("SudarshanCloud") }
    var token by remember { mutableStateOf("") }
    var pubKey by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    var resultOk by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ExtHeader("Votifier Tester", "Send a real test vote to your server's Votifier / NuVotifier port")
        ExtCard {
            OutlinedTextField(host, { host = it }, label = { Text("Server address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("Votifier port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(username, { username = it }, label = { Text("Test username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(service, { service = it }, label = { Text("Vote site name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        ExtCard {
            Text("Keys", color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text("v2 (NuVotifier) uses a token, v1 uses the RSA public key. The port must be allocated to your server.", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(token, { token = it }, label = { Text("v2 token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(pubKey, { pubKey = it }, label = { Text("v1 public key (base64)") }, maxLines = 4, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            ExtButton("Auto-detect from server files", {
                val s = server ?: run { onFeedback("Select a server first"); return@ExtButton }
                scope.launch {
                    busy = true
                    var found = false
                    for (folder in listOf("Votifier", "NuVotifier")) {
                        PanelTools.readFile(s.identifier, "/plugins/$folder/config.yml").getOrNull()?.let { cfg ->
                            Regex("(?m)^port:\\s*(\\d+)").find(cfg)?.groupValues?.get(1)?.let { port = it }
                            Regex("(?m)^\\s+default:\\s*['\"]?([^'\"\\s]+)").find(cfg)?.groupValues?.get(1)?.let { token = it }
                            found = true
                        }
                        PanelTools.readFile(s.identifier, "/plugins/$folder/rsa/public.key").getOrNull()?.let { pubKey = it.trim(); found = true }
                        if (found) break
                    }
                    busy = false
                    onFeedback(if (found) "Votifier settings loaded from your server" else "No Votifier config found in /plugins")
                }
            }, color = Color(0xFF334155), enabled = !busy)
        }
        ExtButton(if (busy) "Working..." else "Send test vote", {
            val p = port.toIntOrNull()
            if (host.isBlank() || p == null) { onFeedback("Enter the address and port"); return@ExtButton }
            scope.launch {
                busy = true; result = null
                val r = PanelTools.sendTestVote(host.trim(), p, username.trim(), service.trim(), token.ifBlank { null }, pubKey.ifBlank { null })
                busy = false
                resultOk = r.isSuccess
                result = r.getOrNull() ?: (r.exceptionOrNull()?.message ?: "Failed")
            }
        }, Modifier.fillMaxWidth(), color = ExtGreen, enabled = !busy)
        result?.let { Text(it, color = if (resultOk) Color(0xFF4ADE80) else Color(0xFFF87171), fontSize = 13.sp) }
    }
}

// ---------------------------------------------------------------------------
// SUBDOMAINS (Cloudflare DNS)
// ---------------------------------------------------------------------------

@Composable
fun SubdomainsScreen(server: CachedServerEntity?, onFeedback: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember { ToolPrefs(context.applicationContext) }
    var cfg by remember { mutableStateOf(prefs.cloudflare()) }
    var editing by remember { mutableStateOf(prefs.cloudflare() == null) }
    var token by remember { mutableStateOf(cfg?.token.orEmpty()) }
    var zone by remember { mutableStateOf(cfg?.zoneId.orEmpty()) }
    var domain by remember { mutableStateOf(cfg?.baseDomain.orEmpty()) }
    var sub by remember { mutableStateOf("") }
    var records by remember { mutableStateOf<List<DnsRecord>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val target = serverHosts(server).firstOrNull()

    LaunchedEffect(cfg, server?.identifier, tick) {
        val c = cfg ?: return@LaunchedEffect
        if (server == null || target == null) return@LaunchedEffect
        PanelTools.listSubdomains(c, target, server.port).onSuccess { records = it }.onFailure { onFeedback(it.message ?: "Could not load DNS records") }
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ExtHeader("Subdomains", "Give your server a friendly address like play.yourdomain.com")
        if (server == null) { Text("No server selected", color = TextSecondary); return@Column }
        if (editing || cfg == null) {
            ExtCard {
                Text("Cloudflare setup", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text("Use a token limited to Zone → DNS → Edit on one zone. It is stored encrypted on this device. Only give the app a token if you trust everyone who can use this device.", color = TextMuted, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(token, { token = it }, label = { Text("API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(zone, { zone = it }, label = { Text("Zone ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(domain, { domain = it }, label = { Text("Base domain (e.g. sudarshancloud.com)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExtButton("Save", {
                        if (token.isBlank() || zone.isBlank() || domain.isBlank()) { onFeedback("Fill all three fields"); return@ExtButton }
                        val c = CloudflareConfig(token.trim(), zone.trim(), domain.trim().lowercase().removePrefix("."))
                        prefs.saveCloudflare(c); cfg = c; editing = false; tick++
                    }, color = ExtGreen)
                    if (cfg != null) ExtButton("Cancel", { editing = false }, color = Color(0xFF334155))
                }
            }
        } else {
            val c = cfg!!
            ExtCard {
                Text("Create subdomain", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text("Points to ${target ?: "?"}:${server.port}", color = TextMuted, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(sub, { sub = it.lowercase().filter { ch -> ch.isLetterOrDigit() || ch == '-' } }, singleLine = true, modifier = Modifier.weight(1f), placeholder = { Text("play") })
                    Spacer(Modifier.width(6.dp))
                    Text(".${c.baseDomain}", color = TextSecondary, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                ExtButton(if (busy) "Creating..." else "Create", {
                    val t = target ?: run { onFeedback("This server has no usable address"); return@ExtButton }
                    scope.launch {
                        busy = true
                        val r = PanelTools.createSubdomain(c, sub, t, server.port)
                        busy = false
                        r.onSuccess { onFeedback("Created $it — DNS can take a few minutes"); sub = ""; tick++ }
                            .onFailure { onFeedback(it.message ?: "Could not create subdomain") }
                    }
                }, color = ExtGreen, enabled = !busy && sub.length >= 3)
            }
            Text("Your subdomains", color = TextPrimary, fontWeight = FontWeight.SemiBold)
            if (records.isEmpty()) Text("None yet.", color = TextMuted, fontSize = 12.sp)
            records.forEach { r ->
                ExtCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, color = TextPrimary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("SRV → ${r.content}:${r.port}", color = TextMuted, fontSize = 10.sp)
                        }
                        IconButton(onClick = {
                            scope.launch {
                                PanelTools.deleteSubdomain(c, r.id).onSuccess { onFeedback("Deleted ${r.name}"); tick++ }
                                    .onFailure { onFeedback(it.message ?: "Delete failed") }
                            }
                        }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFEF4444)) }
                    }
                }
            }
            ExtButton("Edit Cloudflare settings", { editing = true }, color = Color(0xFF334155))
        }
    }
}

// ---------------------------------------------------------------------------
// SERVER SPLITTER (needs an Application API key)
// ---------------------------------------------------------------------------

@Composable
fun ServerSplitterScreen(
    server: CachedServerEntity?,
    appKey: String,
    onOpenSettings: () -> Unit,
    onFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var info by remember(server?.identifier) { mutableStateOf<PanelTools.AppServerInfo?>(null) }
    var loadError by remember(server?.identifier) { mutableStateOf<String?>(null) }
    var loading by remember(server?.identifier) { mutableStateOf(false) }
    var name by remember(server?.identifier) { mutableStateOf("") }
    var memShare by remember { mutableStateOf(0.5f) }
    var diskShare by remember { mutableStateOf(0.5f) }
    var cpuShare by remember { mutableStateOf(0.5f) }
    var confirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(server?.identifier, appKey) {
        val s = server ?: return@LaunchedEffect
        if (appKey.isBlank()) return@LaunchedEffect
        loading = true; loadError = null
        val id = PanelTools.applicationServerId(appKey, s.identifier)
        val r = id.getOrNull()?.let { PanelTools.applicationServer(appKey, it) }
        if (r != null && r.isSuccess) { info = r.getOrNull(); if (name.isBlank()) name = "${s.name} (split)" }
        else loadError = (id.exceptionOrNull() ?: r?.exceptionOrNull())?.message ?: "Could not load server details"
        loading = false
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ExtHeader("Server Splitter", "Carve part of this server's resources into a brand-new server")
        if (server == null) { Text("No server selected", color = TextSecondary); return@Column }
        if (appKey.isBlank()) {
            ExtCard {
                Text("Application API key needed", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text("Creating a server is an admin action on Pterodactyl. Add a ptla_ Application API key (with read & write on Servers, Nodes and Allocations) in Settings. Only panel admins can do this.", color = TextSecondary, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                ExtButton("Open Settings", onOpenSettings)
            }
            return@Column
        }
        if (loading) CircularProgressIndicator(color = ExtGold)
        loadError?.let { Text(it, color = Color(0xFFF87171), fontSize = 12.sp) }
        val i = info ?: return@Column
        val canSplit = i.memory >= 512 && i.disk >= 1024
        ExtCard {
            Text("${i.name} — current limits", color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text("RAM ${if (i.memory == 0) "unlimited" else "${i.memory} MB"} • Disk ${if (i.disk == 0) "unlimited" else "${i.disk} MB"} • CPU ${if (i.cpu == 0) "unlimited" else "${i.cpu}%"}", color = TextSecondary, fontSize = 12.sp)
        }
        if (!canSplit) {
            Text("This server needs limited RAM (≥ 512 MB) and disk (≥ 1 GB) to be split. Unlimited servers can't be divided.", color = ExtGold, fontSize = 12.sp)
            return@Column
        }
        fun share(total: Int, f: Float, min: Int): Int = ((total * f).toInt() / 64 * 64).coerceIn(min, total - min)
        val newMem = share(i.memory, memShare, 256)
        val newDisk = share(i.disk, diskShare, 512)
        val newCpu = if (i.cpu >= 20) (i.cpu * cpuShare).toInt().coerceIn(10, i.cpu - 10) else 0
        ExtCard {
            OutlinedTextField(name, { name = it }, label = { Text("New server name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Text("RAM for new server: $newMem MB (original keeps ${i.memory - newMem} MB)", color = TextPrimary, fontSize = 12.sp)
            Slider(memShare, { memShare = it }, valueRange = 0.1f..0.9f)
            Text("Disk for new server: $newDisk MB (original keeps ${i.disk - newDisk} MB)", color = TextPrimary, fontSize = 12.sp)
            Slider(diskShare, { diskShare = it }, valueRange = 0.1f..0.9f)
            if (i.cpu >= 20) {
                Text("CPU for new server: $newCpu% (original keeps ${i.cpu - newCpu}%)", color = TextPrimary, fontSize = 12.sp)
                Slider(cpuShare, { cpuShare = it }, valueRange = 0.1f..0.9f)
            }
            Text("The new server uses the same egg and settings, gets the next free port on this node and the same owner. Files are not copied — use a backup or the Importer to move data.", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            ExtButton(if (busy) "Splitting..." else "Split server", { confirm = true }, Modifier.fillMaxWidth(), color = ExtRed, enabled = !busy && name.isNotBlank())
        }
        if (confirm) {
            AlertDialog(
                onDismissRequest = { confirm = false },
                title = { Text("Split ${i.name}?") },
                text = { Text("Creates \"$name\" with $newMem MB RAM / $newDisk MB disk and shrinks ${i.name} by the same amount. The shrink is applied on next restart of the original server.") },
                confirmButton = {
                    TextButton(onClick = {
                        confirm = false
                        scope.launch {
                            busy = true
                            val alloc = PanelTools.freeAllocation(appKey, i.nodeId)
                            if (alloc.isFailure) { busy = false; onFeedback(alloc.exceptionOrNull()?.message ?: "No free port"); return@launch }
                            val r = PanelTools.splitServer(appKey, i, name.trim(), newMem, newDisk, newCpu, alloc.getOrThrow())
                            busy = false
                            r.onSuccess { onFeedback("New server created ($it). Pull to refresh the server list.") }
                                .onFailure { onFeedback(it.message ?: "Split failed") }
                        }
                    }) { Text("Split", color = ExtRed) }
                },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
            )
        }
    }
}

// ---------------------------------------------------------------------------
// SERVER IMPORTER (URL pull + phone upload, optional extract)
// ---------------------------------------------------------------------------

private fun isArchive(name: String): Boolean {
    val n = name.lowercase()
    return n.endsWith(".zip") || n.endsWith(".tar.gz") || n.endsWith(".tgz") || n.endsWith(".tar") || n.endsWith(".rar") || n.endsWith(".7z") || n.endsWith(".tar.xz") || n.endsWith(".tar.bz2")
}

@Composable
fun ServerImporterScreen(
    server: CachedServerEntity?,
    onFeedback: (String) -> Unit,
    onOpenFiles: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    var dir by remember { mutableStateOf("/") }
    var extract by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun finish(s: CachedServerEntity, file: String) {
        if (extract && isArchive(file)) {
            busy = "Extracting $file..."
            val d = PanelTools.decompress(s.identifier, dir, file)
            if (d.isSuccess) {
                PanelTools.deletePath(s.identifier, dir, file)
                onFeedback("Imported and extracted $file into $dir")
            } else onFeedback("Uploaded, but extraction failed: ${d.exceptionOrNull()?.message}")
        } else onFeedback("Imported $file into $dir")
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val s = server
        if (uri == null || s == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = "Reading file..."
            val loaded = withContext(Dispatchers.IO) {
                runCatching {
                    var fileName = "import.bin"
                    var size = -1L
                    context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ni >= 0) fileName = c.getString(ni) ?: fileName
                            val si = c.getColumnIndex(OpenableColumns.SIZE); if (si >= 0) size = c.getLong(si)
                        }
                    }
                    if (size > 200L * 1024 * 1024) throw java.io.IOException("File is over 200 MB — host it somewhere and use Import from URL")
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw java.io.IOException("Cannot read file")
                    fileName to bytes
                }
            }
            val pair = loaded.getOrNull()
            if (pair == null) { busy = null; onFeedback(loaded.exceptionOrNull()?.message ?: "Could not read file"); return@launch }
            busy = "Uploading ${pair.first}..."
            val r = PanelTools.uploadFile(s.identifier, dir, pair.first, pair.second, context.contentResolver.getType(uri))
            if (r.isSuccess) finish(s, pair.first) else onFeedback(r.exceptionOrNull()?.message ?: "Upload failed")
            busy = null
        }
    }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ExtHeader("Server Importer", "Bring an existing server's files onto this server")
        if (server == null) { Text("No server selected", color = TextSecondary); return@Column }
        ExtCard {
            OutlinedTextField(dir, { dir = it.ifBlank { "/" } }, label = { Text("Destination folder") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(extract, { extract = it })
                Text("Extract archives (.zip, .tar.gz…) and delete them afterwards", color = TextSecondary, fontSize = 12.sp)
            }
        }
        ExtCard {
            Text("Import from URL", color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text("Direct link to a zip/tar.gz of your server (Dropbox, Drive, GitHub release, your old host...). The server downloads it itself — fast, and nothing passes through your phone.", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(url, { url = it }, label = { Text("https://...") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            ExtButton("Import", {
                val u = url.trim()
                if (!u.startsWith("http://") && !u.startsWith("https://")) { onFeedback("Enter a full http(s) link"); return@ExtButton }
                val file = u.substringBefore('?').substringAfterLast('/').ifBlank { "import.zip" }
                scope.launch {
                    busy = "Downloading $file..."
                    val r = PanelTools.pullFile(server.identifier, u, dir, file)
                    if (r.isSuccess) finish(server, file) else onFeedback(r.exceptionOrNull()?.message ?: "Import failed")
                    busy = null
                }
            }, enabled = busy == null && url.isNotBlank())
        }
        ExtCard {
            Text("Upload from this phone", color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Text("Pick a file from your storage (up to 200 MB).", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            ExtButton("Choose file", { picker.launch("*/*") }, enabled = busy == null)
        }
        busy?.let {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(16.dp), color = ExtGold, strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp)); Text(it, color = TextPrimary, fontSize = 12.sp)
            }
        }
        Text("Moving a whole server from another Pterodactyl panel or SFTP host needs access to both machines. Make a backup or archive there, then import it here by link or upload.", color = TextMuted, fontSize = 11.sp)
        ExtButton("Open Files", onOpenFiles, color = Color(0xFF334155))
    }
}
