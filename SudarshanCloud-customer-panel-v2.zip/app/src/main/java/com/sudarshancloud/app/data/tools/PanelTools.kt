package com.sudarshancloud.app.data.tools

import android.util.Base64
import com.sudarshancloud.app.data.api.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URLEncoder
import java.security.KeyFactory
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

// ---------------------------------------------------------------------------
// Data holders
// ---------------------------------------------------------------------------

data class SoftwareType(
    val id: String,
    val name: String,
    val icon: String,
    val minecraftVersions: Int,
    val builds: Int,
    val deprecated: Boolean,
    val experimental: Boolean,
    val category: String
)

data class SoftwareVersion(val id: String, val type: String, val builds: Int, val java: Int)

data class SoftwareBuild(
    val id: Long,
    val name: String,
    val buildNumber: Int,
    val jarUrl: String?,
    val zipUrl: String?,
    val experimental: Boolean,
    val steps: List<InstallStep>
)

data class InstallStep(val type: String, val url: String?, val file: String?)

data class ModProject(
    val id: String,
    val slug: String,
    val title: String,
    val description: String,
    val iconUrl: String?,
    val downloads: Long,
    val projectType: String
)

data class ModVersion(
    val id: String,
    val name: String,
    val versionNumber: String,
    val gameVersions: List<String>,
    val loaders: List<String>,
    val fileUrl: String,
    val fileName: String,
    val downloads: Long,
    val datePublished: String
)

data class PingResult(
    val online: Int,
    val max: Int,
    val players: List<String>,
    val versionName: String,
    val motd: String,
    val latencyMs: Long
)

data class DnsRecord(val id: String, val type: String, val name: String, val content: String, val port: Int?)

data class CloudflareConfig(val token: String, val zoneId: String, val baseDomain: String)

// ---------------------------------------------------------------------------
// Public façade
// ---------------------------------------------------------------------------

object PanelTools {

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val UA = "SudarshanCloud-Android/1.0 (support@sudarshancloud.com)"
    private const val MCJARS = "https://mcjars.app"
    private const val MODRINTH = "https://api.modrinth.com/v2"
    private val JSON_MT = "application/json".toMediaType()

    private fun getJson(url: String, headers: Map<String, String> = emptyMap()): JSONObject {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json")
            .apply { headers.forEach { (k, v) -> header(k, v) } }.build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}: ${body.take(200)}")
            return JSONObject(body)
        }
    }

    private fun getJsonArray(url: String): JSONArray {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json").build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}: ${body.take(200)}")
            return JSONArray(body)
        }
    }

    // ------------------------------------------------------------------
    // MCJars (Version Changer)
    // ------------------------------------------------------------------

    suspend fun softwareTypes(): Result<List<SoftwareType>> = withContext(Dispatchers.IO) {
        runCatching {
            val types = getJson("$MCJARS/api/v2/types").getJSONObject("types")
            val out = mutableListOf<SoftwareType>()
            val seen = HashSet<String>()
            val cats = types.keys().asSequence().toList()
            for (cat in cats) {
                val group = types.optJSONObject(cat) ?: continue
                // Flat layout (id -> type object) vs grouped layout (category -> id -> type object)
                val entries: List<Pair<String, JSONObject>> =
                    if (group.opt("name") is String) listOf(cat to group)
                    else group.keys().asSequence().toList().mapNotNull { k -> group.optJSONObject(k)?.let { k to it } }
                for ((id, o) in entries) {
                    if (!seen.add(id)) continue
                    val v = o.optJSONObject("versions")
                    val minecraft = v?.optInt("minecraft", 0) ?: 0
                    val project = v?.optInt("project", 0) ?: 0
                    out += SoftwareType(
                        id = id,
                        name = o.optString("name", id),
                        icon = o.optString("icon").ifBlank { "$MCJARS/icons/$id" },
                        minecraftVersions = if (minecraft > 0) minecraft else project,
                        builds = o.optInt("builds", 0),
                        deprecated = o.optBoolean("deprecated", false),
                        experimental = o.optBoolean("experimental", false),
                        category = cat
                    )
                }
            }
            // "types" is {recommended, established, experimental, miscellaneous, limbos}; limbos are not real server jars
            out.filter { it.category != "limbos" }
        }
    }

    suspend fun softwareVersions(typeId: String): Result<List<SoftwareVersion>> = withContext(Dispatchers.IO) {
        runCatching {
            val builds = getJson("$MCJARS/api/v2/builds/$typeId").getJSONObject("builds")
            val list = mutableListOf<SoftwareVersion>()
            for (key in builds.keys()) {
                val o = builds.getJSONObject(key)
                list += SoftwareVersion(key, o.optString("type", "RELEASE"), o.optInt("builds", 0), o.optInt("java", 0))
            }
            list.reversed() // API lists oldest → newest; show newest first
        }
    }

    suspend fun softwareBuilds(typeId: String, version: String): Result<List<SoftwareBuild>> = withContext(Dispatchers.IO) {
        runCatching {
            val enc = URLEncoder.encode(version, "UTF-8")
            val arr = getJson("$MCJARS/api/v2/builds/$typeId/$enc").getJSONArray("builds")
            val list = mutableListOf<SoftwareBuild>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val steps = mutableListOf<InstallStep>()
                val inst = o.optJSONArray("installation")
                if (inst != null) {
                    for (a in 0 until inst.length()) {
                        val group = inst.optJSONArray(a) ?: continue
                        for (b in 0 until group.length()) {
                            val s = group.optJSONObject(b) ?: continue
                            steps += InstallStep(
                                s.optString("type"),
                                s.optString("url").takeIf { it.isNotBlank() && it != "null" },
                                (s.optString("file").ifBlank { s.optString("location") }).takeIf { it.isNotBlank() && it != "null" }
                            )
                        }
                    }
                }
                list += SoftwareBuild(
                    id = o.optLong("id"),
                    name = o.optString("name"),
                    buildNumber = o.optInt("buildNumber"),
                    jarUrl = o.optString("jarUrl").takeIf { it.isNotBlank() && it != "null" },
                    zipUrl = o.optString("zipUrl").takeIf { it.isNotBlank() && it != "null" },
                    experimental = o.optBoolean("experimental"),
                    steps = steps
                )
            }
            list.sortedByDescending { it.id }
        }
    }

    // ------------------------------------------------------------------
    // Modrinth (Mods / Plugins)
    // ------------------------------------------------------------------

    suspend fun gameVersions(): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            val arr = getJsonArray("$MODRINTH/tag/game_version")
            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("version_type") == "release") out += o.getString("version")
            }
            out
        }
    }

    suspend fun searchProjects(
        projectType: String,      // "mod" or "plugin"
        query: String,
        gameVersion: String?,     // null = any
        loader: String?,          // e.g. "fabric" / "paper"; null = any
        sort: String,             // downloads | relevance | newest | updated | follows
        limit: Int,
        offset: Int = 0
    ): Result<List<ModProject>> = withContext(Dispatchers.IO) {
        runCatching {
            val facets = JSONArray()
            facets.put(JSONArray().put("project_type:$projectType"))
            if (!loader.isNullOrBlank()) facets.put(JSONArray().put("categories:$loader"))
            if (!gameVersion.isNullOrBlank()) facets.put(JSONArray().put("versions:$gameVersion"))
            // Only things that can run server-side
            facets.put(JSONArray().put("server_side:required").put("server_side:optional"))
            val url = "$MODRINTH/search?query=${URLEncoder.encode(query, "UTF-8")}" +
                "&facets=${URLEncoder.encode(facets.toString(), "UTF-8")}" +
                "&index=$sort&limit=$limit&offset=$offset"
            val hits = getJson(url).getJSONArray("hits")
            val out = mutableListOf<ModProject>()
            for (i in 0 until hits.length()) {
                val h = hits.getJSONObject(i)
                out += ModProject(
                    id = h.getString("project_id"),
                    slug = h.optString("slug"),
                    title = h.optString("title"),
                    description = h.optString("description"),
                    iconUrl = h.optString("icon_url").takeIf { it.isNotBlank() && it != "null" },
                    downloads = h.optLong("downloads"),
                    projectType = h.optString("project_type", projectType)
                )
            }
            out
        }
    }

    suspend fun projectVersions(projectId: String, loader: String?, gameVersion: String?): Result<List<ModVersion>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val params = StringBuilder()
                if (!loader.isNullOrBlank()) params.append("&loaders=").append(URLEncoder.encode(JSONArray().put(loader).toString(), "UTF-8"))
                if (!gameVersion.isNullOrBlank()) params.append("&game_versions=").append(URLEncoder.encode(JSONArray().put(gameVersion).toString(), "UTF-8"))
                val arr = getJsonArray("$MODRINTH/project/$projectId/version?${params.toString().trimStart('&')}")
                val out = mutableListOf<ModVersion>()
                for (i in 0 until arr.length()) {
                    val v = arr.getJSONObject(i)
                    val files = v.optJSONArray("files") ?: continue
                    if (files.length() == 0) continue
                    var file = files.getJSONObject(0)
                    for (f in 0 until files.length()) if (files.getJSONObject(f).optBoolean("primary")) file = files.getJSONObject(f)
                    val gv = v.optJSONArray("game_versions")
                    val ld = v.optJSONArray("loaders")
                    out += ModVersion(
                        id = v.getString("id"),
                        name = v.optString("name"),
                        versionNumber = v.optString("version_number"),
                        gameVersions = (0 until (gv?.length() ?: 0)).map { gv!!.getString(it) },
                        loaders = (0 until (ld?.length() ?: 0)).map { ld!!.getString(it) },
                        fileUrl = file.getString("url"),
                        fileName = file.getString("filename"),
                        downloads = v.optLong("downloads"),
                        datePublished = v.optString("date_published").take(10)
                    )
                }
                out
            }
        }

    // ------------------------------------------------------------------
    // Pterodactyl client-API extras (pull / upload / decompress / raw)
    // ------------------------------------------------------------------

    private fun panelBase(): String = ApiClient.getBaseUrl().trimEnd('/')
    private fun bearer(key: String): String = if (key.startsWith("Bearer ", true)) key else "Bearer ${key.trim()}"

    private fun panelCall(
        method: String,
        path: String,
        body: JSONObject? = null,
        key: String = ApiClient.getApiKey(),
        applicationApi: Boolean = false
    ): String {
        val builder = Request.Builder()
            .url(panelBase() + path)
            .header("Authorization", bearer(key))
            .header("Accept", if (applicationApi) "application/vnd.pterodactyl.v1+json" else "application/json")
            .header("User-Agent", UA)
        val rb = body?.toString()?.toRequestBody(JSON_MT)
        when (method) {
            "GET" -> builder.get()
            "DELETE" -> if (rb != null) builder.delete(rb) else builder.delete()
            else -> builder.method(method, rb ?: "".toRequestBody(JSON_MT))
        }
        http.newCall(builder.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val detail = Regex("\"detail\"\\s*:\\s*\"([^\"]+)\"").find(text)?.groupValues?.get(1) ?: text.take(200)
                throw java.io.IOException("Panel said HTTP ${r.code}: $detail")
            }
            return text
        }
    }

    suspend fun ensureFolder(server: String, parent: String, name: String) = withContext(Dispatchers.IO) {
        runCatching {
            panelCall("POST", "/api/client/servers/$server/files/create-folder", JSONObject().put("root", parent).put("name", name))
        }
    }

    /** Tells Wings to download [url] straight into the server ([directory]/[filename]). */
    suspend fun pullFile(server: String, url: String, directory: String, filename: String?): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val b = JSONObject().put("url", url).put("directory", directory).put("use_header", false).put("foreground", true)
                if (!filename.isNullOrBlank()) b.put("filename", filename)
                panelCall("POST", "/api/client/servers/$server/files/pull", b)
                Unit
            }
        }

    suspend fun deletePath(server: String, root: String, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            panelCall("POST", "/api/client/servers/$server/files/delete", JSONObject().put("root", root).put("files", JSONArray().put(name)))
            Unit
        }
    }

    suspend fun decompress(server: String, root: String, file: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            panelCall("POST", "/api/client/servers/$server/files/decompress", JSONObject().put("root", root).put("file", file))
            Unit
        }
    }

    suspend fun readFile(server: String, path: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder()
                .url("${panelBase()}/api/client/servers/$server/files/contents?file=${URLEncoder.encode(path, "UTF-8")}")
                .header("Authorization", bearer(ApiClient.getApiKey())).header("User-Agent", UA).build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
                r.body?.string().orEmpty()
            }
        }
    }

    suspend fun sendCommand(server: String, command: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching { panelCall("POST", "/api/client/servers/$server/command", JSONObject().put("command", command)); Unit }
    }

    suspend fun powerSignal(server: String, signal: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching { panelCall("POST", "/api/client/servers/$server/power", JSONObject().put("signal", signal)); Unit }
    }

    /** Uploads raw bytes to the server using the signed Wings upload URL. */
    suspend fun uploadFile(server: String, directory: String, fileName: String, bytes: ByteArray, mime: String?): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val signed = JSONObject(panelCall("GET", "/api/client/servers/$server/files/upload"))
                    .getJSONObject("attributes").getString("url")
                val url = if (signed.contains("?")) "$signed&directory=${URLEncoder.encode(directory, "UTF-8")}"
                else "$signed?directory=${URLEncoder.encode(directory, "UTF-8")}"
                val part = bytes.toRequestBody((mime ?: "application/octet-stream").toMediaTypeOrNull())
                val multipart = MultipartBody.Builder().setType(MultipartBody.FORM).addFormDataPart("files", fileName, part).build()
                val req = Request.Builder().url(url).header("User-Agent", UA).post(multipart).build()
                http.newBuilder().writeTimeout(5, TimeUnit.MINUTES).readTimeout(5, TimeUnit.MINUTES).build().newCall(req).execute().use { r ->
                    if (!r.isSuccessful) throw java.io.IOException("Upload failed: HTTP ${r.code}")
                }
                Unit
            }
        }

    // ------------------------------------------------------------------
    // Application API (Server Splitter) — needs a ptla_ key
    // ------------------------------------------------------------------

    data class AppServerInfo(
        val id: Int, val name: String, val userId: Int, val nodeId: Int,
        val eggId: Int, val nestId: Int, val image: String, val startup: String,
        val environment: JSONObject, val memory: Int, val swap: Int, val disk: Int, val io: Int, val cpu: Int,
        val featureLimits: JSONObject, val allocationId: Int
    )

    suspend fun applicationServerId(appKey: String, identifier: String): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val root = JSONObject(panelCall("GET", "/api/application/servers?filter%5BuuidShort%5D=${URLEncoder.encode(identifier, "UTF-8")}", key = appKey, applicationApi = true))
            val data = root.getJSONArray("data")
            if (data.length() == 0) throw java.io.IOException("This server was not found with that Application API key (is it a ptla_ key from an admin?)")
            data.getJSONObject(0).getJSONObject("attributes").getInt("id")
        }
    }

    suspend fun applicationServer(appKey: String, internalId: Int): Result<AppServerInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val a = JSONObject(panelCall("GET", "/api/application/servers/$internalId", key = appKey, applicationApi = true)).getJSONObject("attributes")
            val limits = a.getJSONObject("limits")
            val container = a.getJSONObject("container")
            AppServerInfo(
                id = a.getInt("id"), name = a.getString("name"), userId = a.getInt("user"), nodeId = a.getInt("node"),
                eggId = a.getInt("egg"), nestId = a.getInt("nest"),
                image = container.getString("image"), startup = container.getString("startup_command"),
                environment = container.optJSONObject("environment") ?: JSONObject(),
                memory = limits.getInt("memory"), swap = limits.getInt("swap"), disk = limits.getInt("disk"),
                io = limits.getInt("io"), cpu = limits.getInt("cpu"),
                featureLimits = a.getJSONObject("feature_limits"), allocationId = a.getInt("allocation")
            )
        }
    }

    suspend fun freeAllocation(appKey: String, nodeId: Int): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            var page = 1
            while (page <= 20) {
                val root = JSONObject(panelCall("GET", "/api/application/nodes/$nodeId/allocations?per_page=100&page=$page", key = appKey, applicationApi = true))
                val data = root.getJSONArray("data")
                for (i in 0 until data.length()) {
                    val at = data.getJSONObject(i).getJSONObject("attributes")
                    if (!at.optBoolean("assigned")) return@runCatching at.getInt("id")
                }
                val pg = root.optJSONObject("meta")?.optJSONObject("pagination")
                if (pg == null || page >= pg.optInt("total_pages", 1)) break
                page++
            }
            throw java.io.IOException("No free allocation (port) left on this node. Ask your host to add ports.")
        }
    }

    suspend fun splitServer(
        appKey: String, src: AppServerInfo, newName: String,
        newMemory: Int, newDisk: Int, newCpu: Int, allocationId: Int
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            // 1) create the new server first — if it fails nothing has been touched
            val env = JSONObject()
            for (k in src.environment.keys()) if (k != "STARTUP" && !k.startsWith("P_")) env.put(k, src.environment.get(k))
            val body = JSONObject()
                .put("name", newName).put("user", src.userId).put("egg", src.eggId)
                .put("docker_image", src.image).put("startup", src.startup).put("environment", env)
                .put("limits", JSONObject().put("memory", newMemory).put("swap", src.swap).put("disk", newDisk).put("io", src.io).put("cpu", newCpu))
                .put("feature_limits", JSONObject().put("databases", 0).put("allocations", 1).put("backups", 0))
                .put("allocation", JSONObject().put("default", allocationId))
            val created = JSONObject(panelCall("POST", "/api/application/servers", body, appKey, true)).getJSONObject("attributes")
            // 2) shrink the original by the same amount
            val build = JSONObject()
                .put("allocation", src.allocationId)
                .put("memory", (src.memory - newMemory).coerceAtLeast(64)).put("swap", src.swap)
                .put("disk", (src.disk - newDisk).coerceAtLeast(256)).put("io", src.io)
                .put("cpu", if (src.cpu == 0) 0 else (src.cpu - newCpu).coerceAtLeast(10))
                .put("threads", JSONObject.NULL)
                .put("feature_limits", src.featureLimits)
            panelCall("PATCH", "/api/application/servers/${src.id}/build", build, appKey, true)
            created.optString("identifier", created.optString("uuid").take(8))
        }
    }

    // ------------------------------------------------------------------
    // Live player ping (Minecraft Server List Ping)
    // ------------------------------------------------------------------

    suspend fun ping(host: String, port: Int): Result<PingResult> = withContext(Dispatchers.IO) {
        runCatching {
            val start = System.currentTimeMillis()
            Socket().use { s ->
                s.soTimeout = 4000
                s.connect(InetSocketAddress(host, port), 4000)
                val out = DataOutputStream(s.getOutputStream())
                val inp = DataInputStream(s.getInputStream())

                val hs = ByteArrayOutputStream()
                val h = DataOutputStream(hs)
                writeVarInt(h, 0x00); writeVarInt(h, 767)
                val hb = host.toByteArray(Charsets.UTF_8)
                writeVarInt(h, hb.size); h.write(hb); h.writeShort(port); writeVarInt(h, 1)
                writeVarInt(out, hs.size()); out.write(hs.toByteArray())
                writeVarInt(out, 1); writeVarInt(out, 0x00) // status request
                out.flush()

                readVarInt(inp)           // packet length
                val id = readVarInt(inp)
                if (id != 0x00) throw java.io.IOException("Unexpected packet $id")
                val len = readVarInt(inp)
                val data = ByteArray(len); inp.readFully(data)
                val json = JSONObject(String(data, Charsets.UTF_8))
                val players = json.optJSONObject("players")
                val sample = players?.optJSONArray("sample")
                val names = (0 until (sample?.length() ?: 0)).map { sample!!.getJSONObject(it).optString("name") }.filter { it.isNotBlank() }
                val desc = json.opt("description")
                val motd = when (desc) {
                    is JSONObject -> desc.optString("text") + (desc.optJSONArray("extra")?.let { ex -> (0 until ex.length()).joinToString("") { ex.optJSONObject(it)?.optString("text").orEmpty() } } ?: "")
                    else -> desc?.toString().orEmpty()
                }
                PingResult(
                    online = players?.optInt("online", 0) ?: 0, max = players?.optInt("max", 0) ?: 0,
                    players = names, versionName = json.optJSONObject("version")?.optString("name").orEmpty(),
                    motd = motd.replace(Regex("§."), "").trim(), latencyMs = System.currentTimeMillis() - start
                )
            }
        }
    }

    private fun writeVarInt(out: java.io.OutputStream, value: Int) {
        var v = value
        while (true) {
            if ((v and 0x7F.inv()) == 0) { out.write(v); return }
            out.write((v and 0x7F) or 0x80); v = v ushr 7
        }
    }

    private fun readVarInt(inp: java.io.InputStream): Int {
        var num = 0; var shift = 0
        while (true) {
            val b = inp.read(); if (b < 0) throw java.io.EOFException()
            num = num or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) return num
            shift += 7; if (shift > 35) throw java.io.IOException("VarInt too big")
        }
    }

    // ------------------------------------------------------------------
    // Votifier (v1 RSA + v2 token)
    // ------------------------------------------------------------------

    /** v2: [token] is the NuVotifier token. v1: [publicKeyB64] is the contents of rsa/public.key. */
    suspend fun sendTestVote(
        host: String, port: Int, username: String, serviceName: String,
        token: String?, publicKeyB64: String?
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val address = "127.0.0.1"
            val timestamp = System.currentTimeMillis()
            Socket().use { s ->
                s.soTimeout = 6000
                s.connect(InetSocketAddress(host, port), 6000)
                val inp = s.getInputStream()
                val greeting = StringBuilder()
                while (true) { val c = inp.read(); if (c < 0 || c == '\n'.code) break; greeting.append(c.toChar()) }
                val g = greeting.toString().trim()
                if (!g.startsWith("VOTIFIER")) throw java.io.IOException("Not a Votifier port (got \"${g.take(40)}\")")
                val parts = g.split(" ")
                val out = s.getOutputStream()
                if (parts.size >= 3 && parts[1] == "2") {
                    if (token.isNullOrBlank()) throw java.io.IOException("This server uses Votifier v2 — enter the token from plugins/Votifier/config.yml")
                    val challenge = parts[2]
                    val payload = JSONObject().put("serviceName", serviceName).put("username", username)
                        .put("address", address).put("timestamp", timestamp).put("challenge", challenge).toString()
                    val mac = Mac.getInstance("HmacSHA256"); mac.init(SecretKeySpec(token.trim().toByteArray(Charsets.UTF_8), "HmacSHA256"))
                    val sig = Base64.encodeToString(mac.doFinal(payload.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
                    val msg = JSONObject().put("signature", sig).put("payload", payload).toString().toByteArray(Charsets.UTF_8)
                    val d = DataOutputStream(out)
                    d.writeShort(0x733A); d.writeShort(msg.size); d.write(msg); d.flush()
                    val resp = StringBuilder()
                    while (true) { val c = inp.read(); if (c < 0) break; resp.append(c.toChar()); if (resp.endsWith("}")) break }
                    val status = runCatching { JSONObject(resp.toString()) }.getOrNull()
                    val ok = status != null && status.optString("status") == "ok"
                    if (!ok) {
                        val cause = status?.optString("cause").orEmpty()
                        val error = status?.optString("error").orEmpty()
                        throw java.io.IOException(if (cause.isNotBlank() || error.isNotBlank()) "$cause: $error".trim(':', ' ') else "Rejected: ${resp.toString().take(120)}")
                    }
                    "Vote accepted by Votifier v2 ✔"
                } else {
                    if (publicKeyB64.isNullOrBlank()) throw java.io.IOException("This server uses Votifier v1 — enter the public key from plugins/Votifier/rsa/public.key")
                    val keyBytes = Base64.decode(publicKeyB64.replace("\\s".toRegex(), ""), Base64.DEFAULT)
                    val pub = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(keyBytes))
                    val block = "VOTE\n$serviceName\n$username\n$address\n$timestamp\n".toByteArray(Charsets.UTF_8)
                    val cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding"); cipher.init(Cipher.ENCRYPT_MODE, pub)
                    out.write(cipher.doFinal(block)); out.flush()
                    "Vote packet sent (Votifier v1 sends no reply). Check the server console for the vote."
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Cloudflare DNS (Subdomains)
    // ------------------------------------------------------------------

    private fun cf(cfg: CloudflareConfig, method: String, path: String, body: JSONObject? = null): JSONObject {
        val rb = body?.toString()?.toRequestBody(JSON_MT)
        val b = Request.Builder().url("https://api.cloudflare.com/client/v4/zones/${cfg.zoneId}$path")
            .header("Authorization", "Bearer ${cfg.token}").header("Content-Type", "application/json")
        when (method) {
            "GET" -> b.get()
            "DELETE" -> b.delete()
            else -> b.method(method, rb ?: "".toRequestBody(JSON_MT))
        }
        http.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            val json = runCatching { JSONObject(text) }.getOrNull()
            if (!r.isSuccessful || json?.optBoolean("success") == false) {
                val msg = json?.optJSONArray("errors")?.optJSONObject(0)?.optString("message") ?: "HTTP ${r.code}"
                throw java.io.IOException("Cloudflare: $msg")
            }
            return json ?: JSONObject()
        }
    }

    suspend fun listSubdomains(cfg: CloudflareConfig, targetHost: String, port: Int): Result<List<DnsRecord>> = withContext(Dispatchers.IO) {
        runCatching {
            val arr = cf(cfg, "GET", "/dns_records?type=SRV&per_page=100").getJSONArray("result")
            val out = mutableListOf<DnsRecord>()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val data = r.optJSONObject("data") ?: continue
                val p = data.optInt("port")
                val t = data.optString("target")
                if (p == port && (t.equals(targetHost, true) || t.endsWith(".${cfg.baseDomain}", true))) {
                    out += DnsRecord(r.getString("id"), "SRV", r.getString("name").removePrefix("_minecraft._tcp."), t, p)
                }
            }
            out
        }
    }

    /** Creates sub.base → SRV (_minecraft._tcp) pointing to the server. If the host is a raw IP an A record is added too. */
    suspend fun createSubdomain(cfg: CloudflareConfig, sub: String, targetHost: String, port: Int): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val clean = sub.trim().lowercase().replace(Regex("[^a-z0-9-]"), "")
            if (clean.length < 3) throw java.io.IOException("Subdomain must be at least 3 letters/numbers")
            val fqdn = "$clean.${cfg.baseDomain}"
            val isIp = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(targetHost)
            val srvTarget: String
            if (isIp) {
                cf(cfg, "POST", "/dns_records", JSONObject().put("type", "A").put("name", fqdn).put("content", targetHost).put("ttl", 1).put("proxied", false))
                srvTarget = fqdn
            } else srvTarget = targetHost
            val data = JSONObject().put("service", "_minecraft").put("proto", "_tcp").put("name", fqdn)
                .put("priority", 0).put("weight", 5).put("port", port).put("target", srvTarget)
            cf(cfg, "POST", "/dns_records", JSONObject().put("type", "SRV").put("name", "_minecraft._tcp.$fqdn").put("data", data).put("ttl", 1))
            fqdn
        }
    }

    suspend fun deleteSubdomain(cfg: CloudflareConfig, recordId: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching { cf(cfg, "DELETE", "/dns_records/$recordId"); Unit }
    }
}
