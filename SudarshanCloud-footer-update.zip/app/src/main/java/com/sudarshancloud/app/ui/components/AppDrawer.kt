package com.sudarshancloud.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sudarshancloud.app.R
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.DarkSurface
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary

enum class NavDestination {
    SERVERS,
    DASHBOARD,
    CONSOLE,
    SETTINGS,
    AUTHENTICATION,
    FILES,
    DATABASES,
    BACKUPS,
    WORLDS,
    STARTUP,
    SCHEDULES
}
@Composable
fun AppDrawer(
    currentDestination: NavDestination,
    selectedServerName: String?,
    userEmail: String,
    onNavigate: (NavDestination) -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uriHandler = LocalUriHandler.current

    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(Color(0xFF161E2D)) // Screenshot 3's dark navy background
            .padding(vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            // Drawer Header (Matches Screenshot 3)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Gold Emblem Logo
                    Image(
                        painter = painterResource(id = R.drawable.sudarshan_logo_mark),
                        contentDescription = "Sudarshan Logo",
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SudarshanCloud",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = userEmail,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }

                IconButton(
                    onClick = onCloseDrawer,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF283852))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Drawer",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Selected Server Indicator Banner
            if (!selectedServerName.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E2D44))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Active: $selectedServerName",
                            color = Color(0xFFFACC15),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Top level items: Servers & Account
            DrawerItem(
                icon = Icons.Default.Dns,
                label = "Servers",
                isSelected = currentDestination == NavDestination.SERVERS,
                onClick = {
                    onNavigate(NavDestination.SERVERS)
                    onCloseDrawer()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section: GENERAL
            DrawerSectionHeader(title = "GENERAL")
            DrawerItem(
                icon = Icons.Default.Dashboard,
                label = "Dashboard",
                isSelected = currentDestination == NavDestination.DASHBOARD,
                onClick = {
                    onNavigate(NavDestination.DASHBOARD)
                    onCloseDrawer()
                }
            )
            DrawerItem(
                icon = Icons.Default.Terminal,
                label = "Console",
                isSelected = currentDestination == NavDestination.CONSOLE,
                onClick = {
                    onNavigate(NavDestination.CONSOLE)
                    onCloseDrawer()
                }
            )
            DrawerItem(
                icon = Icons.Default.Settings,
                label = "Settings",
                isSelected = currentDestination == NavDestination.SETTINGS,
                onClick = {
                    onNavigate(NavDestination.SETTINGS)
                    onCloseDrawer()
                }
            )
            DrawerItem(
                icon = Icons.Default.LockReset,
                label = "Authentication",
                isSelected = currentDestination == NavDestination.AUTHENTICATION,
                highlightColor = Color(0xFFEAB308),
                onClick = {
                    onNavigate(NavDestination.AUTHENTICATION)
                    onCloseDrawer()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section: MANAGEMENT
            DrawerSectionHeader(title = "MANAGEMENT")
            DrawerItem(
                icon = Icons.Default.Folder,
                label = "Files",
                isSelected = currentDestination == NavDestination.FILES,
                highlightColor = Color(0xFF10B981),
                onClick = {
                    onNavigate(NavDestination.FILES)
                    onCloseDrawer()
                }
            )
            DrawerItem(
                icon = Icons.Default.Storage,
                label = "Databases",
                isSelected = currentDestination == NavDestination.DATABASES,
                onClick = {
                    onNavigate(NavDestination.DATABASES)
                    onCloseDrawer()
                }
            )
            DrawerItem(
                icon = Icons.Default.FolderZip,
                label = "Backups",
                isSelected = currentDestination == NavDestination.BACKUPS,
                onClick = {
                    onNavigate(NavDestination.BACKUPS)
                    onCloseDrawer()
                }
            )
            DrawerItem(
                icon = Icons.Default.Public,
                label = "World Manager",
                isSelected = currentDestination == NavDestination.WORLDS,
                onClick = { onNavigate(NavDestination.WORLDS); onCloseDrawer() }
            )
            DrawerItem(
                icon = Icons.Default.Tune,
                label = "Startup / Version",
                isSelected = currentDestination == NavDestination.STARTUP,
                onClick = { onNavigate(NavDestination.STARTUP); onCloseDrawer() }
            )
            DrawerItem(
                icon = Icons.Default.Schedule,
                label = "Schedules",
                isSelected = currentDestination == NavDestination.SCHEDULES,
                onClick = { onNavigate(NavDestination.SCHEDULES); onCloseDrawer() }
            )
        }

        DrawerFooter(onOpenWebsite = { uriHandler.openUri("https://portal.sudarshancloud.com") })
    }
}

@Composable
private fun DrawerFooter(onOpenWebsite: () -> Unit) {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        color = DarkBorder
    )
    Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(
            text = "Website Portal: https://portal.sudarshancloud.com",
            color = Color(0xFF60A5FA),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .clickable(onClick = onOpenWebsite)
                .padding(vertical = 3.dp)
        )
        Text(text = "App developer: @alexbexok.com", color = TextSecondary, fontSize = 11.sp)
        Text(text = "App tester: @yourlocal_pragbaler_73733", color = TextSecondary, fontSize = 11.sp)
        Text(text = "Helper: aayushmc0", color = TextSecondary, fontSize = 11.sp)
        Text(text = "Built using: Gradle 9.3.1", color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = "©️2026 SudarshanCloud. All rights reserved.",
            color = TextMuted,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun DrawerSectionHeader(title: String) {
    Text(
        text = title,
        color = Color(0xFF8C9DB5),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
    )
}

@Composable
private fun DrawerItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    highlightColor: Color? = null,
    onClick: () -> Unit
) {
    val activeBg = if (isSelected) Color(0xFF0F4938) else Color.Transparent
    val activeTint = if (isSelected) (highlightColor ?: Color(0xFF34D399)) else TextSecondary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(activeBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = activeTint,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = label,
                color = if (isSelected) TextPrimary else TextSecondary,
                fontSize = 14.5.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}
