# Build SudarshanCloud on GitHub Actions

1. Put this project ZIP at the repository root.
2. Keep `.github/workflows/build-apk.yml` in the repository.
3. Open **Actions → Build SudarshanCloud APK → Run workflow**.
4. Download the `SudarshanCloud-debug-APK` artifact when the job succeeds.

## Pterodactyl server sync

The app no longer seeds or displays the old screenshot/demo server cards. The server list is populated from the live Pterodactyl API.

- **Client API Key (`ptlc_...`)**: lists servers available to the authenticated client account and is used by the existing server-management features.
- **Application API Key (`ptla_...`)**: for a panel administrator, lists all panel servers through `/api/application/servers`, including servers that are not assigned to the admin as a client.
- You can configure both keys. When an Application API key is present, the home server list uses it to fetch the complete admin server inventory; the Client API key remains available for client-level server operations.

The Application API server endpoint is paginated, so the app follows all pages (up to 100 servers per page) before replacing the local cache. An empty successful API response clears the old cache as well.
