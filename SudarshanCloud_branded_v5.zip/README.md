# SudarshanCloud Android App

Android client for a Pterodactyl panel.

## Live server synchronization

The home server cards are populated from the configured Pterodactyl API; there are no hard-coded demo server cards.

In **Settings → Panel & API Configuration**:

- Enter the panel URL.
- Enter a **Client API Key (`ptlc_...`)** for client-level server operations.
- If you administer the panel and want the app to display **all servers**, also enter an **Application API Key (`ptla_...`)**. The app uses the Application API `/api/application/servers` endpoint, follows pagination, and replaces the local server cache with the live server inventory.

Keep API keys private.
