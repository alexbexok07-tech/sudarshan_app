package com.sudarshancloud.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sudarshancloud.app.data.api.ConnectionStatus
import com.sudarshancloud.app.data.api.ConsoleLogEntry
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import com.sudarshancloud.app.data.model.Server
import com.sudarshancloud.app.ui.components.MemoryUsageHeroCard
import com.sudarshancloud.app.ui.components.StatusBadge
import com.sudarshancloud.app.ui.components.TerminalView
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.StatusOnline
import com.sudarshancloud.app.ui.theme.StatusStarting
import com.sudarshancloud.app.ui.theme.StatusStopping
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary
import com.sudarshancloud.app.ui.viewmodel.ConsoleViewModel

/**
 * ConsoleScreen displaying real-time streaming console logs from the server
 * over WebSocket / recurring API polling and enabling interactive command dispatch.
 */
@Composable
fun ConsoleScreen(
    server: Server?,
    viewModel: ConsoleViewModel,
    modifier: Modifier = Modifier,
    onPowerAction: (String) -> Unit = {}
) {
    if (server == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No server selected. Select a server from the Servers menu.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    // Attach to real-time console stream when server is selected
    DisposableEffect(server.id) {
        viewModel.attachServer(server.id)
        onDispose {
            viewModel.detachServer()
        }
    }

    val logs by viewModel.logs.collectAsStateWithLifecycle()
    val connStatus by viewModel.connectionStatus.collectAsStateWithLifecycle()
    val isSending by viewModel.isSendingCommand.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Server Title & Quick Connection Status Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = server.name,
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Node: ${server.nodeName} | ${server.primaryAddress}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            // Connection indicator badge
            ConnectionStatusBadge(status = connStatus)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Power action bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onPowerAction("start") },
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("console_start_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF166534),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Start", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { onPowerAction("restart") },
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("console_restart_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF854D0E),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Restart", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { onPowerAction("stop") },
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("console_stop_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF991B1B),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Stop", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Remote Terminal View with streaming log lines and interactive command field
        TerminalView(
            logs = logs,
            onSendCommand = { command -> viewModel.sendCommand(command) },
            onClearLogs = { viewModel.clearLogs() }
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

/**
 * Overload allowing backward compatibility with CachedServerEntity / MainViewModel if needed.
 */
@Composable
fun ConsoleScreen(
    server: CachedServerEntity?,
    stats: PteroStatsAttributes?,
    logs: List<ConsoleLogEntry>,
    onSendCommand: (String) -> Unit,
    onClearLogs: () -> Unit,
    onPowerAction: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (server == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "No server selected. Select a server from the Servers menu.",
                color = TextSecondary,
                fontSize = 14.sp
            )
        }
        return
    }

    val memBytes = stats?.resources?.memoryBytes ?: server.memoryUsageBytes
    val memLimitMb = server.memoryLimit
    val currentState = stats?.currentState ?: server.currentState

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = server.name,
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Node: ${server.node} | ${server.ip}:${server.port}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
            StatusBadge(status = currentState)
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onPowerAction("start") },
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("console_start_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF166534),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Start", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { onPowerAction("restart") },
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("console_restart_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF854D0E),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Restart", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { onPowerAction("stop") },
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("console_stop_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF991B1B),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Stop", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        MemoryUsageHeroCard(
            memoryBytes = memBytes,
            limitMb = memLimitMb
        )

        Spacer(modifier = Modifier.height(16.dp))

        TerminalView(
            logs = logs,
            onSendCommand = onSendCommand,
            onClearLogs = onClearLogs
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ConnectionStatusBadge(status: ConnectionStatus) {
    val (label, bg, fg) = when (status) {
        ConnectionStatus.AUTHENTICATED -> Triple("WS CONNECTED", Color(0xFF14532D), Color(0xFF4ADE80))
        ConnectionStatus.CONNECTED -> Triple("AUTHENTICATING", Color(0xFF713F12), Color(0xFFFDE047))
        ConnectionStatus.CONNECTING -> Triple("CONNECTING...", Color(0xFF1E3A8A), Color(0xFF93C5FD))
        ConnectionStatus.ERROR -> Triple("POLLING FALLBACK", Color(0xFF7F1D1D), Color(0xFFFCA5A5))
        ConnectionStatus.DISCONNECTED -> Triple("DISCONNECTED", Color(0xFF262626), Color(0xFFA3A3A3))
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                color = fg,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
