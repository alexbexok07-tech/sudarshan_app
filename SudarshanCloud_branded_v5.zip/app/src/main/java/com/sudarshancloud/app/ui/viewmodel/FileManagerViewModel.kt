package com.sudarshancloud.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.Server
import com.sudarshancloud.app.data.repository.ServerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * UI State for file browsing, directory navigation, and file contents viewing/editing.
 */
data class FileManagerUiState(
    val server: Server? = null,
    val currentDirectory: String = "/",
    val files: List<PteroFileAttributes> = emptyList(),
    val isLoading: Boolean = false,
    val selectedFileContent: String? = null,
    val selectedFilePath: String? = null,
    val isSavingFile: Boolean = false,
    val hasUnsavedChanges: Boolean = false,
    val errorMessage: String? = null,
    val feedbackMessage: String? = null
)

/**
 * FileManagerViewModel interacts with the Pterodactyl API's file management endpoints:
 * - GET /api/client/servers/{server}/files/list?directory={dir}
 * - GET /api/client/servers/{server}/files/contents?file={file}
 * - POST /api/client/servers/{server}/files/write?file={file}
 * - POST /api/client/servers/{server}/files/create-folder
 * - POST /api/client/servers/{server}/files/delete
 */
class FileManagerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ServerRepository(application)

    private val _uiState = MutableStateFlow(FileManagerUiState())
    val uiState: StateFlow<FileManagerUiState> = _uiState.asStateFlow()

    fun setServer(server: Server) {
        if (_uiState.value.server?.id == server.id) return
        _uiState.value = _uiState.value.copy(server = server, currentDirectory = "/")
        loadFiles(server.id, "/")
    }

    fun loadFiles(serverId: String, directory: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, currentDirectory = directory, errorMessage = null)
            val result = repository.listFiles(serverId, directory)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    files = result.getOrDefault(emptyList()),
                    isLoading = false
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Failed to list files: ${result.exceptionOrNull()?.localizedMessage}"
                )
            }
        }
    }

    fun navigateToDirectory(directory: String) {
        val server = _uiState.value.server ?: return
        val normalized = if (directory.startsWith("/")) directory else "/$directory"
        loadFiles(server.id, normalized)
    }

    fun openFile(filePath: String) {
        val server = _uiState.value.server ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, selectedFilePath = filePath)
            val result = repository.getFileContent(server.id, filePath)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    selectedFileContent = result.getOrDefault(""),
                    hasUnsavedChanges = false
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    selectedFileContent = null,
                    errorMessage = "Failed to read file: ${result.exceptionOrNull()?.localizedMessage}"
                )
            }
        }
    }

    fun updateEditorContent(newContent: String) {
        _uiState.value = _uiState.value.copy(
            selectedFileContent = newContent,
            hasUnsavedChanges = true
        )
    }

    fun saveCurrentFile() {
        val server = _uiState.value.server ?: return
        val filePath = _uiState.value.selectedFilePath ?: return
        val content = _uiState.value.selectedFileContent ?: return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSavingFile = true)
            val result = repository.saveFileContent(server.id, filePath, content)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    isSavingFile = false,
                    hasUnsavedChanges = false,
                    feedbackMessage = "Saved ${filePath.substringAfterLast('/')} successfully!"
                )
                loadFiles(server.id, _uiState.value.currentDirectory)
            } else {
                _uiState.value = _uiState.value.copy(
                    isSavingFile = false,
                    errorMessage = "Failed to save file: ${result.exceptionOrNull()?.localizedMessage}"
                )
            }
        }
    }

    fun closeFile() {
        _uiState.value = _uiState.value.copy(
            selectedFilePath = null,
            selectedFileContent = null,
            hasUnsavedChanges = false
        )
    }

    fun createFolder(name: String) {
        val server = _uiState.value.server ?: return
        val dir = _uiState.value.currentDirectory
        viewModelScope.launch {
            val result = repository.createFolder(server.id, dir, name)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(feedbackMessage = "Folder '$name' created")
                loadFiles(server.id, dir)
            } else {
                _uiState.value = _uiState.value.copy(errorMessage = "Failed to create folder: ${result.exceptionOrNull()?.localizedMessage}")
            }
        }
    }

    fun deleteFile(name: String) {
        val server = _uiState.value.server ?: return
        val dir = _uiState.value.currentDirectory
        viewModelScope.launch {
            val result = repository.deleteFiles(server.id, dir, listOf(name))
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(feedbackMessage = "Deleted $name")
                loadFiles(server.id, dir)
            } else {
                _uiState.value = _uiState.value.copy(errorMessage = "Failed to delete: ${result.exceptionOrNull()?.localizedMessage}")
            }
        }
    }

    fun clearFeedback() {
        _uiState.value = _uiState.value.copy(feedbackMessage = null, errorMessage = null)
    }
}
