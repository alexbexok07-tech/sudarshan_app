package com.sudarshancloud.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "panel_config")
data class PanelConfigEntity(
    @PrimaryKey val id: Int = 1,
    val panelUrl: String = "https://portal.sudarshancloud.com",
    val apiKey: String = "",
    val applicationApiKey: String = "",
    val showOtherServers: Boolean = false,
    val activeServerIdentifier: String? = null,
    val isDemoMode: Boolean = false,
    val userEmail: String = "",
    val username: String = "SudarshanUser"
)

@Entity(tableName = "server_folders")
data class ServerFolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val serverCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_servers")
data class CachedServerEntity(
    @PrimaryKey val identifier: String,
    val name: String,
    val node: String,
    val ip: String,
    val port: Int,
    val cpuLimit: Double,
    val memoryLimit: Long,
    val diskLimit: Long,
    val currentState: String,
    val cpuUsage: Double,
    val memoryUsageBytes: Long,
    val diskUsageBytes: Long,
    val folderName: String? = null,
    val isOtherServer: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val serverIdentifier: String,
    val command: String,
    val timestamp: Long = System.currentTimeMillis()
)
