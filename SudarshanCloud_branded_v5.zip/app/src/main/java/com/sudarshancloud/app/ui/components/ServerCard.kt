package com.sudarshancloud.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.DarkSurfaceHighlight
import com.sudarshancloud.app.ui.theme.StatusOnline
import com.sudarshancloud.app.ui.theme.StatusStarting
import com.sudarshancloud.app.ui.theme.StatusStopping
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun ServerCard(
    server: CachedServerEntity,
    liveStats: PteroStatsAttributes?,
    onManageClick: () -> Unit,
    onPowerAction: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val effectiveCpu = liveStats?.resources?.cpuAbsolute ?: server.cpuUsage
    val effectiveMemBytes = liveStats?.resources?.memoryBytes ?: server.memoryUsageBytes
    val effectiveDiskBytes = liveStats?.resources?.diskBytes ?: server.diskUsageBytes
    val effectiveState = liveStats?.currentState ?: server.currentState

    val cpuStr = String.format(Locale.US, "%.2f%%", effectiveCpu)
    val cpuLimitStr = if (server.cpuLimit > 0) "${server.cpuLimit.toInt()}%" else "Unlimited"

    val memUsedGiB = effectiveMemBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
    val memLimitGiB = server.memoryLimit.toDouble() / 1024.0
    val memStr = String.format(Locale.US, "%.2f GiB", memUsedGiB)
    val memLimitStr = if (memLimitGiB > 0) String.format(Locale.US, "%.0f GiB", memLimitGiB) else "Unlimited"

    val diskUsedGiB = effectiveDiskBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
    val diskLimitGiB = server.diskLimit.toDouble() / 1024.0
    val diskStr = String.format(Locale.US, "%.2f GiB", diskUsedGiB)
    val diskLimitStr = if (diskLimitGiB > 0) String.format(Locale.US, "%.0f GiB", diskLimitGiB) else "Unlimited"

    val fullIp = "${server.ip}:${server.port}"

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("server_card_${server.identifier}")
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header: Name and Status Badge (as seen in Screenshot 2)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = server.name,
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (server.isOtherServer) {
                        Text(
                            text = "Other panel user • view-only",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
                StatusBadge(status = effectiveState)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // IP Address Row with Quick Copy
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Server IP", fullIp))
                        Toast.makeText(context, "Copied IP: $fullIp", Toast.LENGTH_SHORT).show()
                    }
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "IP: ",
                    color = TextSecondary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = fullIp,
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy IP",
                    tint = TextMuted,
                    modifier = Modifier.size(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // CPU Stat
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CPU: ",
                    color = TextSecondary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "$cpuStr / $cpuLimitStr",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // RAM Stat
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RAM: ",
                    color = TextSecondary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "$memStr / $memLimitStr",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Disk Stat
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Disk: ",
                    color = TextSecondary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "$diskStr / $diskLimitStr",
                    color = TextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Power Buttons Row + Manage Server Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick Power Icons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { if (!server.isOtherServer) onPowerAction("start") },
                        enabled = !server.isOtherServer,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF14532D))
                            .testTag("power_start_${server.identifier}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Start",
                            tint = StatusOnline,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = { if (!server.isOtherServer) onPowerAction("restart") },
                        enabled = !server.isOtherServer,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF713F12))
                            .testTag("power_restart_${server.identifier}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restart",
                            tint = StatusStarting,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { if (!server.isOtherServer) onPowerAction("stop") },
                        enabled = !server.isOtherServer,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF7F1D1D))
                            .testTag("power_stop_${server.identifier}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop",
                            tint = StatusStopping,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Primary "Manage server" button (Styled precisely like Screenshot 2)
                Button(
                    onClick = onManageClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("manage_server_btn_${server.identifier}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFA2A039), // Screenshot's iconic greenish-gold tone
                        contentColor = Color(0xFF0F1726)
                    )
                ) {
                    Text(
                        text = if (server.isOtherServer) "View server" else "Manage server",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
