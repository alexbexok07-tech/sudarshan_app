package com.sudarshancloud.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sudarshancloud.app.data.api.PterodactylApi
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.db.PanelConfigEntity
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import com.sudarshancloud.app.data.model.Server
import com.sudarshancloud.app.data.model.toServer
import com.sudarshancloud.app.data.repository.ServerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ServerViewModel provides server state, live telemetry stats, and refresh logic
 * specifically for ServerListScreen.
 */
open class ServerViewModel(application: Application) : AndroidViewModel(application) {
    protected val repository = ServerRepository(application)

    val config: StateFlow<PanelConfigEntity?> = repository.configFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Real-time server telemetry stats (CPU, RAM, Disk, Status)
    val realtimeStats: StateFlow<Map<String, PteroStatsAttributes>> = repository.realtimeStatsMap

    // Domain Server models converted from database / API
    val servers: StateFlow<List<Server>> = repository.cachedServersFlow.map { entities ->
        entities.map { entity ->
            Server(
                id = entity.identifier,
                name = entity.name,
                node = entity.node,
                status = entity.currentState,
                limits = com.sudarshancloud.app.data.model.ServerLimits(
                    memoryMb = entity.memoryLimit,
                    diskMb = entity.diskLimit,
                    cpuLimit = entity.cpuLimit
                )
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadServers()
    }

    fun loadServers() {
        viewModelScope.launch {
            _isLoading.value = true
            repository.initialize()
            val result = repository.fetchServersFromPanel()
            if (result.isFailure) {
                _errorMessage.value = repository.lastError.value
            } else {
                _errorMessage.value = null
            }
            _isLoading.value = false
        }
    }

    fun refreshServers() {
        loadServers()
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun sendPowerAction(serverId: String, signal: String) {
        viewModelScope.launch {
            repository.sendPowerAction(serverId, signal)
        }
    }
}
