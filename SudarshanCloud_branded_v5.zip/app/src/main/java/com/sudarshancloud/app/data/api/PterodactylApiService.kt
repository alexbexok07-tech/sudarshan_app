package com.sudarshancloud.app.data.api

import com.sudarshancloud.app.data.model.ConsoleCommandRequest
import com.sudarshancloud.app.data.model.CreateBackupRequest
import com.sudarshancloud.app.data.model.CreateFolderRequest
import com.sudarshancloud.app.data.model.DeleteFilesRequest
import com.sudarshancloud.app.data.model.PowerSignalRequest
import com.sudarshancloud.app.data.model.PteroAccountResponse
import com.sudarshancloud.app.data.model.PteroBackupItem
import com.sudarshancloud.app.data.model.PteroBackupListResponse
import com.sudarshancloud.app.data.model.PteroDatabaseListResponse
import com.sudarshancloud.app.data.model.PteroFileListResponse
import com.sudarshancloud.app.data.model.PteroServerItem
import com.sudarshancloud.app.data.model.PteroServerListResponse
import com.sudarshancloud.app.data.model.PteroStatsResponse
import com.sudarshancloud.app.data.model.PteroWebsocketResponse
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

typealias PterodactylApiService = PterodactylApi

