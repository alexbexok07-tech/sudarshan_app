package com.sudarshancloud.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sudarshancloud.app.data.model.PteroBackupAttributes
import com.sudarshancloud.app.data.model.Server
import com.sudarshancloud.app.data.repository.ServerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * UI State for backup management
 */
data class BackupManagerUiState(
    val server: Server? = null,
    val backups: List<PteroBackupAttributes> = emptyList(),
    val isLoading: Boolean = false,
    val isCreatingBackup: Boolean = false,
    val feedbackMessage: String? = null,
    val errorMessage: String? = null
)

/**
 * BackupManagerViewModel handles manual backup triggers, listing existing backups,
 * and deleting backups via Pterodactyl API endpoints:
 * - GET /api/client/servers/{server}/backups
 * - POST /api/client/servers/{server}/backups
 * - DELETE /api/client/servers/{server}/backups/{backup}
 */
class BackupManagerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ServerRepository(application)

    private val _uiState = MutableStateFlow(BackupManagerUiState())
    val uiState: StateFlow<BackupManagerUiState> = _uiState.asStateFlow()

    fun setServer(server: Server) {
        if (_uiState.value.server?.id == server.id) return
        _uiState.value = _uiState.value.copy(server = server)
        loadBackups(server.id)
    }

    fun loadBackups(serverId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            val result = repository.listBackups(serverId)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    backups = result.getOrDefault(emptyList()),
                    isLoading = false
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Failed to load backups: ${result.exceptionOrNull()?.localizedMessage}"
                )
            }
        }
    }

    fun createBackup(name: String?) {
        val server = _uiState.value.server ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isCreatingBackup = true, errorMessage = null)
            val result = repository.createBackup(server.id, name)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    isCreatingBackup = false,
                    feedbackMessage = "Backup initiated successfully! Generating archive on daemon node..."
                )
                // Reload list to fetch updated state
                loadBackups(server.id)
            } else {
                _uiState.value = _uiState.value.copy(
                    isCreatingBackup = false,
                    errorMessage = "Failed to create backup: ${result.exceptionOrNull()?.localizedMessage}"
                )
            }
        }
    }

    fun deleteBackup(backupUuid: String) {
        val server = _uiState.value.server ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val result = repository.deleteBackup(server.id, backupUuid)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    feedbackMessage = "Backup deleted successfully"
                )
                loadBackups(server.id)
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Failed to delete backup: ${result.exceptionOrNull()?.localizedMessage}"
                )
            }
        }
    }

    fun clearFeedback() {
        _uiState.value = _uiState.value.copy(feedbackMessage = null, errorMessage = null)
    }
}
