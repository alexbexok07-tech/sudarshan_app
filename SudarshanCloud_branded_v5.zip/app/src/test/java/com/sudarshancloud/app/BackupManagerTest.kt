package com.sudarshancloud.app

import com.sudarshancloud.app.data.model.PteroBackupAttributes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupManagerTest {

    @Test
    fun backupAttributes_parsingAndStatusCheck() {
        val backup = PteroBackupAttributes(
            uuid = "backup-uuid-1234",
            name = "Manual Pre-Deploy Backup",
            bytes = 524288000L,
            isSuccessful = true,
            isLocked = false,
            createdAt = "2026-09-26 18:25"
        )

        assertEquals("backup-uuid-1234", backup.uuid)
        assertEquals("Manual Pre-Deploy Backup", backup.name)
        assertEquals(524288000L, backup.bytes)
        assertTrue(backup.isSuccessful)
        assertFalse(backup.isLocked)
    }

    @Test
    fun backupLockedState_verification() {
        val lockedBackup = PteroBackupAttributes(
            uuid = "locked-uuid-5678",
            name = "Gold Release Archive",
            bytes = 1048576000L,
            isSuccessful = true,
            isLocked = true,
            createdAt = "2026-09-20 12:00"
        )

        assertTrue(lockedBackup.isLocked)
        assertTrue(lockedBackup.isSuccessful)
    }
}
