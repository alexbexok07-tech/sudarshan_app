package com.sudarshancloud.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.sudarshancloud.app.data.security.SecureCredentialsManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class SecureCredentialsManagerTest {

    private lateinit var context: Context
    private lateinit var secureCredentialsManager: SecureCredentialsManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        secureCredentialsManager = SecureCredentialsManager(context)
        secureCredentialsManager.clearCredentials()
    }

    @Test
    fun saveCredentials_storesAndRetrievesSuccessfully() {
        assertFalse(secureCredentialsManager.hasCredentials())

        secureCredentialsManager.saveCredentials(
            panelUrl = "https://portal.sudarshancloud.com",
            apiKey = "ptlc_sample_secret_key_12345",
            email = "user@test.com"
        )

        assertTrue(secureCredentialsManager.hasCredentials())
        assertEquals("https://portal.sudarshancloud.com", secureCredentialsManager.getPanelUrl())
        assertEquals("ptlc_sample_secret_key_12345", secureCredentialsManager.getApiKey())
        assertEquals("user@test.com", secureCredentialsManager.getUserEmail())
    }

    @Test
    fun clearCredentials_removesAllKeys() {
        secureCredentialsManager.saveCredentials(
            panelUrl = "https://portal.sudarshancloud.com",
            apiKey = "ptlc_key",
            email = "admin@sudarshancloud.com"
        )
        assertTrue(secureCredentialsManager.hasCredentials())

        secureCredentialsManager.clearCredentials()
        assertFalse(secureCredentialsManager.hasCredentials())
        assertEquals("", secureCredentialsManager.getApiKey())
        assertEquals("", secureCredentialsManager.getPanelUrl())
    }
}
