package com.sudarshancloud.app

import com.sudarshancloud.app.data.model.NodeDetails
import com.sudarshancloud.app.data.model.Server
import com.sudarshancloud.app.data.model.ServerLimits
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test

class ServerModelJsonTest {

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    @Test
    fun parseServerJson_successfullyMapsFields() {
        val json = """
            {
                "identifier": "c2e5b721",
                "uuid": "c2e5b721-a1b2-c3d4-e5f6-7890abcdef12",
                "name": "Sum",
                "node": "in-01",
                "node_details": {
                    "id": 1,
                    "name": "in-01",
                    "fqdn": "in-01.sudarshancloud.com",
                    "daemon_listen": 8080,
                    "daemon_sftp": 2022
                },
                "status": "online",
                "is_suspended": false,
                "is_installing": false,
                "limits": {
                    "memory": 20480,
                    "swap": 0,
                    "disk": 5120,
                    "io": 500,
                    "cpu": 0.0
                }
            }
        """.trimIndent()

        val adapter = moshi.adapter(Server::class.java)
        val server = adapter.fromJson(json)

        assertNotNull(server)
        assertEquals("c2e5b721", server?.id)
        assertEquals("Sum", server?.name)
        assertEquals("online", server?.status)
        assertEquals("online", server?.effectiveStatus)
        assertEquals("in-01", server?.node)
        assertFalse(server?.isSuspended ?: true)

        val nodeDetails = server?.nodeDetails
        assertNotNull(nodeDetails)
        assertEquals("in-01", nodeDetails?.name)
        assertEquals("in-01.sudarshancloud.com", nodeDetails?.fqdn)
        assertEquals(8080, nodeDetails?.daemonPort)
        assertEquals(2022, nodeDetails?.sftpPort)

        val limits = server?.limits
        assertNotNull(limits)
        assertEquals(20480L, limits?.memoryMb)
        assertEquals(5120L, limits?.diskMb)
    }
}
