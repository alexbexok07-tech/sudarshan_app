package com.sudarshancloud.app

import com.sudarshancloud.app.data.model.PteroFileAttributes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FileManagerTest {

    @Test
    fun pteroFileAttributes_fileAndFolderDetection() {
        val folder = PteroFileAttributes(
            name = "plugins",
            size = 0,
            isFile = false,
            mimetype = "inode/directory"
        )

        val file = PteroFileAttributes(
            name = "server.properties",
            size = 1024,
            isFile = true,
            mimetype = "text/plain"
        )

        assertFalse(folder.isFile)
        assertEquals("plugins", folder.name)
        assertTrue(file.isFile)
        assertEquals(1024L, file.size)
    }

    @Test
    fun pathBreadcrumb_segmentsSplit() {
        val path = "/home/container/plugins/WorldEdit"
        val segments = path.trim('/').split('/').filter { it.isNotBlank() }

        assertEquals(4, segments.size)
        assertEquals("home", segments[0])
        assertEquals("container", segments[1])
        assertEquals("plugins", segments[2])
        assertEquals("WorldEdit", segments[3])
    }
}
