package com.sudarshancloud.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sudarshancloud.app.ui.components.AppDrawer
import com.sudarshancloud.app.ui.components.NavDestination
import com.sudarshancloud.app.ui.screens.AuthenticationScreen
import com.sudarshancloud.app.ui.screens.BackupManagerScreen
import com.sudarshancloud.app.ui.screens.BackupsDatabasesScreen
import com.sudarshancloud.app.ui.screens.ConsoleScreen
import com.sudarshancloud.app.ui.screens.FileManagerScreen
import com.sudarshancloud.app.ui.screens.ServerDetailScreen
import com.sudarshancloud.app.ui.screens.ServersScreen
import com.sudarshancloud.app.ui.screens.SettingsScreen
import com.sudarshancloud.app.ui.theme.DarkBackground
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.DarkSurface
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.MyApplicationTheme
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary
import com.sudarshancloud.app.ui.viewmodel.MainViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val showSplash = rememberSaveable { mutableStateOf(true) }

                LaunchedEffect(Unit) {
                    // Keep the branded startup screen visible for a short, deliberate
                    // intro while the app's repositories and UI initialize.
                    delay(2600)
                    showSplash.value = false
                }

                if (showSplash.value) {
                    SudarshanCloudSplashScreen()
                } else {
                    SudarshanCloudApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
private fun SudarshanCloudSplashScreen() {
    val transition = rememberInfiniteTransition(label = "splashGlow")
    val logoScale by transition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1300),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logoScale"
    )
    val logoAlpha by transition.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1300),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logoAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050608)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.sudarshan_splash),
                contentDescription = "SudarshanCloud logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1536f / 1517f)
                    .graphicsLayer {
                        scaleX = logoScale
                        scaleY = logoScale
                        alpha = logoAlpha
                    }
            )

            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "SudarshanCloud",
                color = Color(0xFFF5C15A),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Server management, made simpler.",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(22.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                color = Color(0xFFEAB308),
                strokeWidth = 2.5.dp
            )
            Spacer(modifier = Modifier.height(34.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SudarshanCloudApp(viewModel: MainViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentDestination by viewModel.currentDestination.collectAsStateWithLifecycle()
    val selectedServer by viewModel.selectedServer.collectAsStateWithLifecycle()
    val servers by viewModel.serversState.collectAsStateWithLifecycle()
    val realtimeStats by viewModel.realtimeStats.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.userFeedback.collectAsStateWithLifecycle()
    val consoleLogs by viewModel.consoleLogs.collectAsStateWithLifecycle()
    val config by viewModel.configState.collectAsStateWithLifecycle()

    val currentDir by viewModel.currentDirectory.collectAsStateWithLifecycle()
    val filesList by viewModel.filesList.collectAsStateWithLifecycle()
    val isLoadingFiles by viewModel.isLoadingFiles.collectAsStateWithLifecycle()
    val editorState by viewModel.fileEditorState.collectAsStateWithLifecycle()
    val backups by viewModel.backupsList.collectAsStateWithLifecycle()
    val databases by viewModel.databasesList.collectAsStateWithLifecycle()

    // Request notification permission on Android 13+ (TIRAMISU)
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Handle feedback snackbar
    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    // Hardware Back Handling
    BackHandler(enabled = drawerState.isOpen || currentDestination != NavDestination.SERVERS) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (editorState != null) {
            viewModel.closeFileEditor()
        } else {
            viewModel.selectDestination(NavDestination.SERVERS)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFF161E2D),
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            ) {
                AppDrawer(
                    currentDestination = currentDestination,
                    selectedServerName = selectedServer?.name,
                    userEmail = config?.userEmail ?: "",
                    onNavigate = { dest ->
                        viewModel.selectDestination(dest)
                        scope.launch { drawerState.close() }
                    },
                    onCloseDrawer = {
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { viewModel.selectDestination(NavDestination.SERVERS) }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.sudarshan_logo_mark),
                                contentDescription = "Logo",
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "SudarshanCloud",
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("drawer_menu_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open Navigation Menu",
                                tint = TextPrimary
                            )
                        }
                    },
                    actions = {
                        if (isRefreshing) {
                            CircularProgressIndicator(
                                modifier = Modifier
                                    .padding(horizontal = 12.dp)
                                    .size(20.dp),
                                color = Color(0xFFEAB308),
                                strokeWidth = 2.dp
                            )
                        } else {
                            IconButton(
                                onClick = { viewModel.refreshAll() },
                                modifier = Modifier.testTag("refresh_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Sync Panel",
                                    tint = TextPrimary
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.selectDestination(NavDestination.SETTINGS) },
                            modifier = Modifier.testTag("top_settings_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = if (currentDestination == NavDestination.SETTINGS) Color(0xFFEAB308) else TextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkBackground,
                        titleContentColor = TextPrimary
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    contentColor = TextPrimary
                ) {
                    NavigationBarItem(
                        selected = currentDestination == NavDestination.SERVERS,
                        onClick = { viewModel.selectDestination(NavDestination.SERVERS) },
                        icon = { Icon(Icons.Default.Dns, contentDescription = "Servers") },
                        label = { Text("Servers", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFEAB308),
                            selectedTextColor = Color(0xFFEAB308),
                            indicatorColor = DarkSurfaceElevated,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )

                    NavigationBarItem(
                        selected = currentDestination == NavDestination.SETTINGS,
                        onClick = { viewModel.selectDestination(NavDestination.SETTINGS) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFEAB308),
                            selectedTextColor = Color(0xFFEAB308),
                            indicatorColor = DarkSurfaceElevated,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = DarkBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentDestination, label = "screen_transition") { dest ->
                    when (dest) {
                        NavDestination.SERVERS -> {
                            ServersScreen(
                                servers = servers,
                                realtimeStats = realtimeStats,
                                searchQuery = searchQuery,
                                onSearchQueryChange = viewModel::setSearchQuery,
                                onManageServer = { server ->
                                    viewModel.selectServer(server)
                                    viewModel.selectDestination(NavDestination.DASHBOARD)
                                },
                                onPowerAction = viewModel::sendPowerAction
                            )
                        }

                        NavDestination.CONSOLE -> {
                            ConsoleScreen(
                                server = selectedServer,
                                stats = selectedServer?.let { realtimeStats[it.identifier] },
                                logs = consoleLogs,
                                onSendCommand = viewModel::sendConsoleCommand,
                                onClearLogs = viewModel::clearConsoleLogs,
                                onPowerAction = { signal ->
                                    selectedServer?.let { viewModel.sendPowerAction(it.identifier, signal) }
                                }
                            )
                        }

                        NavDestination.DASHBOARD -> {
                            ServerDetailScreen(
                                server = selectedServer,
                                stats = selectedServer?.let { realtimeStats[it.identifier] },
                                onPowerAction = { signal ->
                                    selectedServer?.let { viewModel.sendPowerAction(it.identifier, signal) }
                                },
                                onNavigate = viewModel::selectDestination
                            )
                        }

                        NavDestination.FILES -> {
                            FileManagerScreen(
                                server = selectedServer,
                                currentDirectory = currentDir,
                                files = filesList,
                                isLoading = isLoadingFiles,
                                fileEditorState = editorState,
                                onNavigateDirectory = { dir ->
                                    selectedServer?.let { viewModel.loadFiles(it.identifier, dir) }
                                },
                                onOpenFile = viewModel::openFile,
                                onUpdateEditorContent = viewModel::updateEditorContent,
                                onSaveEditorContent = viewModel::saveFileEditorContent,
                                onCloseEditor = viewModel::closeFileEditor,
                                onCreateFolder = viewModel::createFolder,
                                onCreateFile = viewModel::createFile,
                                onDeleteFile = viewModel::deleteFile
                            )
                        }

                        NavDestination.BACKUPS -> {
                            BackupManagerScreen(
                                server = selectedServer,
                                backups = backups,
                                onCreateBackup = viewModel::createBackup,
                                onDeleteBackup = viewModel::deleteBackup,
                                onRefresh = { selectedServer?.let { viewModel.loadBackups(it.identifier) } }
                            )
                        }

                        NavDestination.DATABASES -> {
                            BackupsDatabasesScreen(
                                server = selectedServer,
                                backups = backups,
                                databases = databases,
                                onCreateBackup = viewModel::createBackup,
                                onCreateDatabase = viewModel::createDatabase
                            )
                        }

                        NavDestination.AUTHENTICATION -> {
                            AuthenticationScreen(
                                viewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
                                onAuthenticationSuccess = {
                                    viewModel.refreshAll()
                                    viewModel.selectDestination(NavDestination.SERVERS)
                                }
                            )
                        }

                        NavDestination.SETTINGS -> {
                            SettingsScreen(
                                config = config,
                                onSaveConfig = viewModel::saveApiConfig,
                                onTestConnection = viewModel::refreshAll
                            )
                        }
                    }
                }
            }
        }
    }
}
