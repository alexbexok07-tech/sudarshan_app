# Build the APK from a phone

1. Upload this ZIP to a private GitHub repository.
2. If the repository contains the ZIP as `sudarshancloud_fixed.zip`, keep it at the repository root.
3. The repository workflow at `.github/workflows/build-apk.yml` can also be copied into the repository separately.
4. Open **Actions** -> **Build SudarshanCloud APK** -> **Run workflow**.
5. After the run succeeds, open the run and download **SudarshanCloud-debug-APK** under Artifacts.
6. Extract that artifact and install `app-debug.apk` on Android.

This workflow deliberately does not enable Gradle dependency caching before the ZIP is extracted. That was the cause of the `No file in ... matched ...` failure in the previous workflow.
