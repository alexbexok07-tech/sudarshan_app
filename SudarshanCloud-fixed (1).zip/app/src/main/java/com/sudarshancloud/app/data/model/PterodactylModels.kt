package com.sudarshancloud.app.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass


@JsonClass(generateAdapter = true)
data class PteroApplicationServerListResponse(
    val data: List<PteroApplicationServerItem> = emptyList(),
    val meta: PteroPaginationMeta? = null
)

@JsonClass(generateAdapter = true)
data class PteroApplicationServerItem(
    val attributes: PteroApplicationServerAttributes
)

@JsonClass(generateAdapter = true)
data class PteroApplicationServerAttributes(
    val identifier: String,
    val uuid: String? = null,
    val name: String,
    val description: String? = "",
    val status: String? = null,
    val limits: PteroLimits = PteroLimits(),
    @Json(name = "suspended") val suspended: Boolean = false,
    val relationships: PteroApplicationRelationships? = null
)

@JsonClass(generateAdapter = true)
data class PteroApplicationRelationships(
    val allocations: PteroApplicationAllocationsData? = null,
    val node: PteroApplicationNodeData? = null,
    val user: PteroApplicationUserData? = null
)

@JsonClass(generateAdapter = true)
data class PteroApplicationAllocationsData(
    val data: List<PteroApplicationAllocationItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PteroApplicationAllocationItem(
    val attributes: PteroApplicationAllocationAttributes
)

@JsonClass(generateAdapter = true)
data class PteroApplicationAllocationAttributes(
    val ip: String = "",
    @Json(name = "ip_alias") val ipAlias: String? = null,
    val port: Int = 25565,
    @Json(name = "is_default") val isDefault: Boolean = false
)

@JsonClass(generateAdapter = true)
data class PteroApplicationNodeData(
    val data: PteroApplicationNodeItem? = null
)

@JsonClass(generateAdapter = true)
data class PteroApplicationNodeItem(
    val attributes: PteroApplicationNodeAttributes
)

@JsonClass(generateAdapter = true)
data class PteroApplicationNodeAttributes(
    val name: String = "",
    val fqdn: String = ""
)

@JsonClass(generateAdapter = true)
data class PteroApplicationUserData(
    val data: PteroApplicationUserItem? = null
)

@JsonClass(generateAdapter = true)
data class PteroApplicationUserItem(
    val attributes: PteroApplicationUserAttributes
)

@JsonClass(generateAdapter = true)
data class PteroApplicationUserAttributes(
    val id: Int = 0,
    val username: String = "",
    val email: String = ""
)

@JsonClass(generateAdapter = true)
data class PteroApplicationNodeListResponse(
    val data: List<PteroApplicationNodeListItem> = emptyList(),
    val meta: PteroPaginationMeta? = null
)

@JsonClass(generateAdapter = true)
data class PteroApplicationNodeListItem(
    val attributes: PteroApplicationNodeListAttributes
)

@JsonClass(generateAdapter = true)
data class PteroApplicationNodeListAttributes(
    val id: Int = 0,
    val name: String = "",
    val fqdn: String = ""
)

@JsonClass(generateAdapter = true)
data class PteroPaginationMeta(
    val pagination: PteroPagination? = null
)

@JsonClass(generateAdapter = true)
data class PteroPagination(
    @Json(name = "current_page") val currentPage: Int = 1,
    @Json(name = "total_pages") val totalPages: Int = 1,
    val total: Int = 0
)

@JsonClass(generateAdapter = true)
data class PteroServerListResponse(
    val data: List<PteroServerItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PteroServerItem(
    val attributes: PteroServerAttributes
)

@JsonClass(generateAdapter = true)
data class PteroServerAttributes(
    val identifier: String,
    val uuid: String? = null,
    val name: String,
    val node: String? = "in-01",
    val description: String? = "",
    val limits: PteroLimits = PteroLimits(),
    @Json(name = "feature_limits") val featureLimits: PteroFeatureLimits = PteroFeatureLimits(),
    val status: String? = null,
    @Json(name = "is_suspended") val isSuspended: Boolean = false,
    @Json(name = "is_installing") val isInstalling: Boolean = false,
    val relationships: PteroRelationships? = null
)

@JsonClass(generateAdapter = true)
data class PteroLimits(
    val memory: Long = 0, // In MB (0 = unlimited)
    val swap: Long = 0,
    val disk: Long = 0, // In MB
    val io: Long = 500,
    val cpu: Double = 0.0 // 0 = unlimited, 100 = 1 core
)

@JsonClass(generateAdapter = true)
data class PteroFeatureLimits(
    val databases: Int = 0,
    val allocations: Int = 1,
    val backups: Int = 0
)

@JsonClass(generateAdapter = true)
data class PteroRelationships(
    val allocations: PteroAllocationsData? = null
)

@JsonClass(generateAdapter = true)
data class PteroAllocationsData(
    val data: List<PteroAllocationItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PteroAllocationItem(
    val attributes: PteroAllocationAttributes
)

@JsonClass(generateAdapter = true)
data class PteroAllocationAttributes(
    val id: Int = 0,
    val ip: String = "",
    @Json(name = "ip_alias") val ipAlias: String? = null,
    val port: Int = 25565,
    @Json(name = "is_default") val isDefault: Boolean = false
)

@JsonClass(generateAdapter = true)
data class PteroStatsResponse(
    val attributes: PteroStatsAttributes
)

@JsonClass(generateAdapter = true)
data class PteroStatsAttributes(
    @Json(name = "current_state") val currentState: String = "offline", // running, offline, starting, stopping
    @Json(name = "is_suspended") val isSuspended: Boolean = false,
    val resources: PteroResources = PteroResources()
)

@JsonClass(generateAdapter = true)
data class PteroResources(
    @Json(name = "memory_bytes") val memoryBytes: Long = 0,
    @Json(name = "cpu_absolute") val cpuAbsolute: Double = 0.0,
    @Json(name = "disk_bytes") val diskBytes: Long = 0,
    @Json(name = "network_rx_bytes") val networkRxBytes: Long = 0,
    @Json(name = "network_tx_bytes") val networkTxBytes: Long = 0,
    val uptime: Long = 0
)

@JsonClass(generateAdapter = true)
data class PteroWebsocketResponse(
    val data: PteroWebsocketData
)

@JsonClass(generateAdapter = true)
data class PteroWebsocketData(
    val token: String,
    val socket: String
)

@JsonClass(generateAdapter = true)
data class PowerSignalRequest(
    val signal: String // "start", "stop", "restart", "kill"
)

@JsonClass(generateAdapter = true)
data class ConsoleCommandRequest(
    val command: String
)

@JsonClass(generateAdapter = true)
data class PteroFileListResponse(
    val data: List<PteroFileItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PteroFileItem(
    val attributes: PteroFileAttributes
)

@JsonClass(generateAdapter = true)
data class PteroFileAttributes(
    val name: String,
    val mode: String = "-rw-r--r--",
    val size: Long = 0,
    @Json(name = "is_file") val isFile: Boolean = true,
    @Json(name = "is_symlink") val isSymlink: Boolean = false,
    val mimetype: String = "text/plain",
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "modified_at") val modifiedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateFolderRequest(
    val root: String,
    val name: String
)

@JsonClass(generateAdapter = true)
data class DeleteFilesRequest(
    val root: String,
    val files: List<String>
)

@JsonClass(generateAdapter = true)
data class PteroBackupListResponse(
    val data: List<PteroBackupItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PteroBackupItem(
    val attributes: PteroBackupAttributes
)

@JsonClass(generateAdapter = true)
data class PteroBackupAttributes(
    val uuid: String,
    val name: String,
    val bytes: Long = 0,
    @Json(name = "is_successful") val isSuccessful: Boolean = true,
    @Json(name = "is_locked") val isLocked: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "completed_at") val completedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateBackupRequest(
    val name: String? = null,
    @Json(name = "is_locked") val isLocked: Boolean = false
)

@JsonClass(generateAdapter = true)
data class PteroDatabaseListResponse(
    val data: List<PteroDatabaseItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PteroDatabaseItem(
    val attributes: PteroDatabaseAttributes
)

@JsonClass(generateAdapter = true)
data class PteroDatabaseAttributes(
    val id: String,
    val name: String,
    val username: String,
    val host: PteroDatabaseHost? = null
)

@JsonClass(generateAdapter = true)
data class PteroDatabaseHost(
    val address: String = "127.0.0.1",
    val port: Int = 3306
)

@JsonClass(generateAdapter = true)
data class PteroAccountResponse(
    val attributes: PteroUserAttributes
)

@JsonClass(generateAdapter = true)
data class PteroUserAttributes(
    val id: Int = 1,
    val admin: Boolean = false,
    val username: String = "",
    val email: String = "",
    @Json(name = "first_name") val firstName: String? = "",
    @Json(name = "last_name") val lastName: String? = "",
    val language: String? = "en"
)
