package com.sudarshancloud.app.data.api

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    private const val DEFAULT_BASE_URL = "https://portal.sudarshancloud.com/"
    
    @Volatile
    private var currentBaseUrl: String = DEFAULT_BASE_URL
    
    @Volatile
    private var currentApiKey: String = ""

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val requestBuilder = original.newBuilder()
            .header("Accept", "application/json")
            .header("User-Agent", "SudarshanCloud-Android/1.0")

        // Do not overwrite an endpoint-specific credential. Application API calls
        // (ptla_) and client API calls (ptlc_) can be used by the same Retrofit
        // service, so the explicit @Header value must win here.
        if (original.header("Authorization").isNullOrBlank() && currentApiKey.isNotBlank()) {
            val key = currentApiKey.trim()
            val bearerToken = if (key.startsWith("Bearer ", ignoreCase = true)) {
                key
            } else {
                "Bearer $key"
            }
            requestBuilder.header("Authorization", bearerToken)
        }

        chain.proceed(requestBuilder.build())
    }

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.HEADERS
        })
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var apiService: PterodactylApi? = null

    fun updateConfig(baseUrl: String, apiKey: String) {
        var normalizedUrl = baseUrl.trim()
        if (!normalizedUrl.endsWith("/")) {
            normalizedUrl += "/"
        }
        if (!normalizedUrl.startsWith("http://") && !normalizedUrl.startsWith("https://")) {
            normalizedUrl = "https://$normalizedUrl"
        }
        
        currentBaseUrl = normalizedUrl
        currentApiKey = apiKey.trim()
        
        // Invalidate retrofit instance to recreate with new baseUrl
        apiService = null
    }

    fun getService(): PterodactylApi {
        return apiService ?: synchronized(this) {
            apiService ?: buildRetrofit().create(PterodactylApi::class.java).also {
                apiService = it
            }
        }
    }

    fun getPterodactylApi(): PterodactylApi = getService()

    private fun buildRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(currentBaseUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    fun getBaseUrl(): String = currentBaseUrl
    fun getApiKey(): String = currentApiKey
}
