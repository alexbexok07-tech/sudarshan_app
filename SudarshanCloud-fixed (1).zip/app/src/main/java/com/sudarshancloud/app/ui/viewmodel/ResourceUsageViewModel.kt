package com.sudarshancloud.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import com.sudarshancloud.app.data.model.Server
import com.sudarshancloud.app.data.repository.ServerRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * State representing live telemetry and resource consumption for a server.
 */
data class ResourceUsageUiState(
    val serverId: String = "",
    val currentState: String = "offline",
    val cpuPercentage: Double = 0.0,
    val cpuLimit: Double = 0.0,
    val memoryBytes: Long = 0L,
    val memoryLimitBytes: Long = 0L,
    val diskBytes: Long = 0L,
    val diskLimitBytes: Long = 0L,
    val networkRxBytes: Long = 0L,
    val networkTxBytes: Long = 0L,
    val uptimeMs: Long = 0L,
    val isPolling: Boolean = false,
    val lastUpdatedTimestamp: Long = 0L,
    val errorMessage: String? = null
)

/**
 * ResourceUsageViewModel polls the Pterodactyl API on portal.sudarshancloud.com
 * for real-time CPU, RAM, and Disk usage statistics of a selected server.
 */
class ResourceUsageViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ServerRepository(application)

    private val _uiState = MutableStateFlow(ResourceUsageUiState())
    val uiState: StateFlow<ResourceUsageUiState> = _uiState.asStateFlow()

    private var pollingJob: Job? = null
    private var currentServer: Server? = null

    /**
     * Start polling resource utilization for [server] every three seconds by default.
     */
    fun selectServerAndStartPolling(server: Server, intervalMs: Long = 3000L) {
        currentServer = server
        val memLimitBytes = (server.limits?.memoryMb ?: 0L) * 1024L * 1024L
        val diskLimitBytes = (server.limits?.diskMb ?: 0L) * 1024L * 1024L
        val cpuLimit = server.limits?.cpuLimit ?: 0.0

        _uiState.value = _uiState.value.copy(
            serverId = server.id,
            currentState = server.effectiveStatus,
            cpuLimit = cpuLimit,
            memoryLimitBytes = memLimitBytes,
            diskLimitBytes = diskLimitBytes,
            isPolling = true,
            errorMessage = null
        )

        startPolling(server.id, intervalMs)
    }

    /**
     * Polls the Pterodactyl REST endpoint: GET /api/client/servers/{server}/resources
     */
    private fun startPolling(serverId: String, intervalMs: Long) {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            // This ViewModel can be used independently of MainViewModel. Make
            // sure the Room-backed panel configuration is loaded before the
            // first request instead of silently polling with an empty client.
            repository.initialize()
            while (isActive) {
                val result = repository.fetchServerResources(serverId)
                if (result.isSuccess) {
                    val stats = result.getOrThrow()
                    val res = stats.resources
                    _uiState.value = _uiState.value.copy(
                        serverId = serverId,
                        currentState = stats.currentState,
                        cpuPercentage = res.cpuAbsolute,
                        memoryBytes = res.memoryBytes,
                        diskBytes = res.diskBytes,
                        networkRxBytes = res.networkRxBytes,
                        networkTxBytes = res.networkTxBytes,
                        uptimeMs = res.uptime,
                        isPolling = true,
                        lastUpdatedTimestamp = System.currentTimeMillis(),
                        errorMessage = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isPolling = true,
                        errorMessage = result.exceptionOrNull()?.localizedMessage ?: "Failed to poll server resources"
                    )
                }
                // Keep one request in flight at a time, then wait the requested
                // interval before the next sample. The app-wide monitor uses the
                // same three-second cadence.
                delay(intervalMs.coerceAtLeast(3000L))
            }
        }
    }

    /**
     * Immediately refresh stats once.
     */
    fun refreshOnce() {
        val serverId = _uiState.value.serverId
        if (serverId.isNotBlank()) {
            viewModelScope.launch {
                val result = repository.fetchServerResources(serverId)
                if (result.isSuccess) {
                    val stats = result.getOrThrow()
                    val res = stats.resources
                    _uiState.value = _uiState.value.copy(
                        currentState = stats.currentState,
                        cpuPercentage = res.cpuAbsolute,
                        memoryBytes = res.memoryBytes,
                        diskBytes = res.diskBytes,
                        networkRxBytes = res.networkRxBytes,
                        networkTxBytes = res.networkTxBytes,
                        uptimeMs = res.uptime,
                        lastUpdatedTimestamp = System.currentTimeMillis(),
                        errorMessage = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        errorMessage = result.exceptionOrNull()?.localizedMessage ?: "Failed to fetch resources"
                    )
                }
            }
        }
    }

    /**
     * Pause polling when UI is not active.
     */
    fun stopPolling() {
        pollingJob?.cancel()
        pollingJob = null
        _uiState.value = _uiState.value.copy(isPolling = false)
    }

    override fun onCleared() {
        super.onCleared()
        stopPolling()
    }
}
