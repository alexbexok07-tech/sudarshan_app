package com.sudarshancloud.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import com.sudarshancloud.app.ui.components.MetricProgressBar
import com.sudarshancloud.app.ui.components.NavDestination
import com.sudarshancloud.app.ui.components.StatusBadge
import com.sudarshancloud.app.ui.components.formatUptime
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.DarkSurfaceHighlight
import com.sudarshancloud.app.ui.theme.StatusOnline
import com.sudarshancloud.app.ui.theme.StatusStarting
import com.sudarshancloud.app.ui.theme.StatusStopping
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun ServerDetailScreen(
    server: CachedServerEntity?,
    stats: PteroStatsAttributes?,
    onPowerAction: (String) -> Unit,
    onNavigate: (NavDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (server == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "No server selected", color = TextSecondary)
        }
        return
    }

    var statsExpanded by remember { mutableStateOf(true) }

    val effectiveCpu = stats?.resources?.cpuAbsolute ?: server.cpuUsage
    val effectiveMemBytes = stats?.resources?.memoryBytes ?: server.memoryUsageBytes
    val effectiveDiskBytes = stats?.resources?.diskBytes ?: server.diskUsageBytes
    val effectiveState = stats?.currentState ?: server.currentState

    val cpuProgress = if (server.cpuLimit > 0) (effectiveCpu / server.cpuLimit).toFloat() else (effectiveCpu / 100.0).toFloat()
    val memUsedMb = (effectiveMemBytes / (1024 * 1024))
    val memProgress = if (server.memoryLimit > 0) (memUsedMb.toFloat() / server.memoryLimit.toFloat()) else 0.2f
    val diskUsedMb = (effectiveDiskBytes / (1024 * 1024))
    val diskProgress = if (server.diskLimit > 0) (diskUsedMb.toFloat() / server.diskLimit.toFloat()) else 0.3f

    val uptimeStr = stats?.resources?.uptime?.let(::formatUptime) ?: "—"
    val rxMb = (stats?.resources?.networkRxBytes ?: 0L).toDouble() / (1024.0 * 1024.0)
    val txMb = (stats?.resources?.networkTxBytes ?: 0L).toDouble() / (1024.0 * 1024.0)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Header (Matches Screenshot 4)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = server.name,
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Node: ${server.node}  •  ${server.ip}:${server.port}",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                if (server.isOtherServer) {
                    Text(
                        text = "Other panel server • actions use the configured API keys",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
            StatusBadge(status = effectiveState)
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            InfoChip(label = "Uptime", value = uptimeStr, modifier = Modifier.weight(1f))
            InfoChip(
                label = "Network",
                value = if (stats != null) "↓ ${String.format(Locale.US, "%.1f", rxMb)} MB  ↑ ${String.format(Locale.US, "%.1f", txMb)} MB" else "—",
                modifier = Modifier.weight(1.5f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Power Controls (Screenshot 4 Buttons: Green Play, Yellow Restart, Red Stop)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Green Play
            Button(
                onClick = { onPowerAction("start") },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("detail_power_start"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF166534),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Start",
                    tint = StatusOnline,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Yellow Restart
            Button(
                onClick = { onPowerAction("restart") },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("detail_power_restart"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF854D0E),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Restart",
                    tint = StatusStarting,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Red Stop / Kill
            Button(
                onClick = { onPowerAction("stop") },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("detail_power_stop"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF991B1B),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = "Stop",
                    tint = StatusStopping,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // "Server stats ∨" collapsible header (Screenshot 4)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSurfaceElevated)
                .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { statsExpanded = !statsExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Server stats",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = if (statsExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                        contentDescription = "Toggle stats",
                        tint = TextSecondary
                    )
                }

                AnimatedVisibility(visible = statsExpanded) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricProgressBar(
                            label = "CPU Load",
                            currentValueStr = if (stats != null) String.format(Locale.US, "%.2f%%", effectiveCpu) else "—",
                            limitStr = if (server.cpuLimit > 0) "${server.cpuLimit.toInt()}%" else "Unlimited",
                            progress = cpuProgress,
                            barColor = Color(0xFF38BDF8),
                            icon = Icons.Default.Speed
                        )

                        MetricProgressBar(
                            label = "Memory (RAM)",
                            currentValueStr = String.format(Locale.US, "%.2f GiB", memUsedMb / 1024.0),
                            limitStr = if (server.memoryLimit > 0) "${server.memoryLimit / 1024} GiB" else "Unlimited",
                            progress = memProgress,
                            barColor = Color(0xFF10B981),
                            icon = Icons.Default.Memory
                        )

                        MetricProgressBar(
                            label = "Disk Storage",
                            currentValueStr = String.format(Locale.US, "%.2f GiB", diskUsedMb / 1024.0),
                            limitStr = if (server.diskLimit > 0) "${server.diskLimit / 1024} GiB" else "Unlimited",
                            progress = diskProgress,
                            barColor = Color(0xFFF59E0B),
                            icon = Icons.Default.PieChart
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Uptime: $uptimeStr", color = TextSecondary, fontSize = 12.sp)
                            Text(
                                text = if (server.nodeAddress.isNotBlank()) "Node: ${server.nodeAddress}" else "Node: ${server.node}",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Server SFTP Connection Info Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSurfaceElevated)
                .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Connection Details",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                DetailRow("Primary Address", "${server.ip}:${server.port}") {
                    copyToClipboard(context, "Address", "${server.ip}:${server.port}")
                }
                val sftpHost = if (server.nodeAddress.isNotBlank()) server.nodeAddress else server.node
                DetailRow("SFTP Host", "$sftpHost:2022") {
                    copyToClipboard(context, "SFTP Host", "$sftpHost:2022")
                }
                DetailRow("Server ID", server.identifier) {
                    copyToClipboard(context, "Server ID", server.identifier)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Navigation to Submodules
        Text(
            text = "Management Modules",
            color = TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ModuleNavCard(
                title = "Remote Console",
                icon = Icons.Default.Terminal,
                accentColor = Color(0xFF38BDF8),
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(NavDestination.CONSOLE) }
            )

            ModuleNavCard(
                title = "File Manager",
                icon = Icons.Default.Folder,
                accentColor = Color(0xFF10B981),
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(NavDestination.FILES) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ModuleNavCard(
                title = "Backups",
                icon = Icons.Default.FolderZip,
                accentColor = Color(0xFFF59E0B),
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(NavDestination.BACKUPS) }
            )

            ModuleNavCard(
                title = "Databases",
                icon = Icons.Default.Storage,
                accentColor = Color(0xFFA855F7),
                modifier = Modifier.weight(1f),
                onClick = { onNavigate(NavDestination.DATABASES) }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun DetailRow(label: String, value: String, onCopy: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCopy)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondary, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = value, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Default.ContentCopy,
                contentDescription = "Copy",
                tint = TextMuted,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun ModuleNavCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Column {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accentColor,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, "Copied $label", Toast.LENGTH_SHORT).show()
}

@Composable
private fun InfoChip(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSurfaceHighlight)
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label, color = TextMuted, fontSize = 10.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

