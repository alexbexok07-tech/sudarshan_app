package com.sudarshancloud.app.data.repository

import android.content.Context
import android.util.Log
import com.sudarshancloud.app.data.api.ApiClient
import com.sudarshancloud.app.data.api.ConsoleLogEntry
import com.sudarshancloud.app.data.api.ConsoleWebSocketManager
import com.sudarshancloud.app.data.api.LogLevel
import com.sudarshancloud.app.data.db.AppDatabase
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.db.CommandHistoryEntity
import com.sudarshancloud.app.data.db.PanelConfigEntity
import com.sudarshancloud.app.data.db.ServerFolderEntity
import com.sudarshancloud.app.data.model.ConsoleCommandRequest
import com.sudarshancloud.app.data.model.CreateBackupRequest
import com.sudarshancloud.app.data.model.CreateFolderRequest
import com.sudarshancloud.app.data.model.DeleteFilesRequest
import com.sudarshancloud.app.data.model.PowerSignalRequest
import com.sudarshancloud.app.data.model.PteroApplicationServerAttributes
import com.sudarshancloud.app.data.model.PteroBackupAttributes
import com.sudarshancloud.app.data.model.PteroDatabaseAttributes
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroServerItem
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ServerRepository(context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val configDao = database.panelConfigDao()
    private val folderDao = database.serverFolderDao()
    private val serverDao = database.cachedServerDao()
    private val historyDao = database.commandHistoryDao()

    val webSocketManager = ConsoleWebSocketManager()

    val configFlow: Flow<PanelConfigEntity?> = configDao.getConfigFlow()
    val foldersFlow: Flow<List<ServerFolderEntity>> = folderDao.getAllFoldersFlow()
    val cachedServersFlow: Flow<List<CachedServerEntity>> = serverDao.getAllCachedServersFlow()

    private val _realtimeStatsMap = MutableStateFlow<Map<String, PteroStatsAttributes>>(emptyMap())
    val realtimeStatsMap: StateFlow<Map<String, PteroStatsAttributes>> = _realtimeStatsMap.asStateFlow()

    private val _isLiveConnected = MutableStateFlow(false)
    val isLiveConnected: StateFlow<Boolean> = _isLiveConnected.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    suspend fun initialize() {
        withContext(Dispatchers.IO) {
            val currentConfig = configDao.getConfig()
            if (currentConfig == null) {
                val defaultConfig = PanelConfigEntity(
                    panelUrl = "https://portal.sudarshancloud.com",
                    apiKey = "",
                    applicationApiKey = "",
                    showOtherServers = false,
                    userEmail = "",
                    username = "SudarshanUser"
                )
                configDao.saveConfig(defaultConfig)
                ApiClient.updateConfig(defaultConfig.panelUrl, defaultConfig.apiKey)
            } else {
                ApiClient.updateConfig(currentConfig.panelUrl, currentConfig.apiKey)
            }

            // Folders were an old local/demo feature. The panel is the source of truth
            // for the server list, so remove any legacy folder chips from existing installs.
            folderDao.clearFolders()
        }
    }

    suspend fun savePanelConfig(
        panelUrl: String,
        apiKey: String,
        applicationApiKey: String = "",
        showOtherServers: Boolean = false,
        userEmail: String? = null
    ) {
        withContext(Dispatchers.IO) {
            val existing = configDao.getConfig() ?: PanelConfigEntity()
            val updated = existing.copy(
                panelUrl = panelUrl.trim(),
                apiKey = apiKey.trim(),
                applicationApiKey = applicationApiKey.trim(),
                showOtherServers = showOtherServers,
                userEmail = userEmail?.trim()?.takeIf { it.isNotBlank() } ?: existing.userEmail
            )
            configDao.saveConfig(updated)
            ApiClient.updateConfig(updated.panelUrl, updated.apiKey)
        }
    }

    suspend fun fetchServersFromPanel(): Result<List<CachedServerEntity>> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val clientApiKey = config?.apiKey.orEmpty().trim()
        val applicationApiKey = config?.applicationApiKey.orEmpty().trim()
        val showOtherServers = config?.showOtherServers ?: false

        if (clientApiKey.isBlank() && applicationApiKey.isBlank()) {
            _lastError.value = "Add your Client API key in Settings to connect to the panel."
            return@withContext Result.failure(Exception("Client API key not configured"))
        }
        if (showOtherServers && applicationApiKey.isBlank()) {
            _lastError.value = "See other panel servers is enabled, but no Application API key (ptla_) is configured."
            return@withContext Result.failure(Exception("Application API key required for other servers"))
        }

        try {
            val service = ApiClient.getService()
            // If an Application key is available, use the real node FQDN and resolve it
            // to an address for the UI. The Client API only exposes the node name.
            val nodeAddresses = if (applicationApiKey.isNotBlank()) {
                loadNodeAddresses(service, applicationApiKey)
            } else {
                emptyMap()
            }
            val entities: List<CachedServerEntity>

            if (showOtherServers && applicationApiKey.isNotBlank()) {
                // Application API is the authoritative panel-wide list. Pterodactyl documents
                // this endpoint as paginated, with up to 100 servers per page.
                val allItems = mutableListOf<PteroApplicationServerAttributes>()
                var page = 1
                var totalPages = 1
                do {
                    val response = service.getApplicationServers(
                        page = page,
                        perPage = 100,
                        include = "allocations,node,user",
                        authHeader = "Bearer $applicationApiKey"
                    )
                    allItems += response.data.map { it.attributes }
                    totalPages = response.meta?.pagination?.totalPages ?: page
                    page++
                } while (page <= totalPages)

                // Best-effort lookup of the signed-in client account. Application API records
                // can then be marked as other/view-only when they belong to another panel user.
                val currentUserId = if (clientApiKey.isNotBlank()) {
                    runCatching { service.getAccount("Bearer $clientApiKey").attributes.id }.getOrNull()
                } else null

                entities = allItems.map { attr ->
                    val allocation = attr.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: attr.relationships?.allocations?.data?.firstOrNull()
                    val node = attr.relationships?.node?.data?.attributes
                    val allocationIp = allocation?.attributes?.ipAlias?.takeIf { isUsableHost(it) }
                        ?: allocation?.attributes?.ip?.takeIf { isUsableHost(it) }
                    val host = allocationIp
                        ?: node?.fqdn?.takeIf { isUsableHost(it) }
                        ?: node?.name?.takeIf { it.isNotBlank() }
                        ?: "Unknown host"
                    val ownerId = attr.relationships?.user?.data?.attributes?.id
                    val isOther = currentUserId == null || ownerId == null || ownerId != currentUserId

                    CachedServerEntity(
                        identifier = attr.identifier,
                        name = attr.name,
                        node = node?.name?.takeIf { it.isNotBlank() } ?: "Unknown node",
                        nodeAddress = resolveNodeAddress(node?.fqdn, node?.name?.let { nodeAddresses[it] }),
                        ip = host,
                        port = allocation?.attributes?.port ?: 25565,
                        cpuLimit = attr.limits.cpu,
                        memoryLimit = attr.limits.memory,
                        diskLimit = attr.limits.disk,
                        currentState = if (attr.suspended) "suspended" else (attr.status?.takeIf { it.isNotBlank() } ?: "unknown"),
                        cpuUsage = 0.0,
                        memoryUsageBytes = 0,
                        diskUsageBytes = 0,
                        folderName = null,
                        isOtherServer = isOther
                    )
                }
            } else {
                // Client API is the correct source when the toggle is off: it returns only
                // servers the authenticated client account can access.
                val response = service.getServers(authHeader = "Bearer $clientApiKey")
                entities = response.data.map { item ->
                    val attr = item.attributes
                    val defaultAllocation = attr.relationships?.allocations?.data
                        ?.firstOrNull { it.attributes.isDefault }
                        ?: attr.relationships?.allocations?.data?.firstOrNull()
                    val allocationIp = defaultAllocation?.attributes?.ipAlias?.takeIf { isUsableHost(it) }
                        ?: defaultAllocation?.attributes?.ip?.takeIf { isUsableHost(it) }
                    CachedServerEntity(
                        identifier = attr.identifier,
                        name = attr.name,
                        node = attr.node ?: "Unknown node",
                        nodeAddress = resolveNodeAddress(attr.node?.let { nodeAddresses[it] }, attr.node?.let { nodeAddresses[it] }),
                        ip = allocationIp ?: attr.node?.let { nodeAddresses[it] }.orEmpty().takeIf { isUsableHost(it) } ?: "Unknown host",
                        port = defaultAllocation?.attributes?.port ?: 25565,
                        cpuLimit = attr.limits.cpu,
                        memoryLimit = attr.limits.memory,
                        diskLimit = attr.limits.disk,
                        currentState = if (attr.isSuspended) "suspended" else "offline",
                        cpuUsage = 0.0,
                        memoryUsageBytes = 0,
                        diskUsageBytes = 0,
                        folderName = null,
                        isOtherServer = false
                    )
                }
            }

            // The API is authoritative: never retain stale/demo cards after a sync.
            serverDao.clearServers()
            if (entities.isNotEmpty()) serverDao.insertOrUpdateServers(entities)
            _isLiveConnected.value = true
            _lastError.value = null
            Result.success(entities)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Error fetching live servers from Pterodactyl", e)
            _lastError.value = "Pterodactyl sync failed: ${friendlyApiError(e)}"
            Result.failure(e)
        }
    }

    private suspend fun loadNodeAddresses(
        service: com.sudarshancloud.app.data.api.PterodactylApi,
        applicationApiKey: String
    ): Map<String, String> {
        return runCatching {
            val result = mutableMapOf<String, String>()
            var page = 1
            var totalPages = 1
            do {
                val response = service.getApplicationNodes(
                    page = page,
                    perPage = 100,
                    authHeader = "Bearer $applicationApiKey"
                )
                response.data.forEach { item ->
                    val fqdn = item.attributes.fqdn.trim()
                    if (item.attributes.name.isNotBlank() && fqdn.isNotBlank()) {
                        val resolved = runCatching {
                            InetAddress.getByName(fqdn).hostAddress
                        }.getOrNull()
                        result[item.attributes.name] = resolved?.takeIf { isUsableHost(it) } ?: fqdn
                    }
                }
                totalPages = response.meta?.pagination?.totalPages ?: page
                page++
            } while (page <= totalPages)
            result
        }.getOrDefault(emptyMap())
    }

    private fun resolveNodeAddress(primary: String?, fallback: String?): String {
        val candidate = primary?.trim().takeIf { !it.isNullOrBlank() } ?: fallback?.trim().orEmpty()
        if (!isUsableHost(candidate)) return ""
        return runCatching { InetAddress.getByName(candidate).hostAddress }
            .getOrNull()
            ?.takeIf { isUsableHost(it) }
            ?: candidate
    }

    private fun isUsableHost(value: String?): Boolean {
        val host = value?.trim().orEmpty()
        return host.isNotBlank() && host != "0.0.0.0" && host != "::" && host != "::0"
    }

    private fun friendlyApiError(error: Throwable): String {
        val message = error.message.orEmpty()
        return when {
            message.contains("401") || message.contains("403") -> "API key was rejected (HTTP ${if (message.contains("403")) "403" else "401"}). Check the key and its permissions."
            message.contains("404") -> "Panel API endpoint was not found. Check the panel URL."
            message.contains("timeout", ignoreCase = true) -> "Panel request timed out."
            message.isBlank() -> error::class.simpleName ?: "Unknown error"
            else -> message.take(180)
        }
    }

    suspend fun fetchServerResources(serverIdentifier: String): Result<PteroStatsAttributes> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()

        if (apiKey.isNotBlank()) {
            try {
                val service = ApiClient.getService()
                val response = service.getServerResources(serverIdentifier)
                val stats = response.attributes
                
                val current = _realtimeStatsMap.value.toMutableMap()
                current[serverIdentifier] = stats
                _realtimeStatsMap.value = current

                // Update cached DB entity with latest stats
                val cached = serverDao.getServer(serverIdentifier)
                if (cached != null) {
                    serverDao.insertOrUpdateServers(
                        listOf(
                            cached.copy(
                                currentState = stats.currentState,
                                cpuUsage = stats.resources.cpuAbsolute,
                                memoryUsageBytes = stats.resources.memoryBytes,
                                diskUsageBytes = stats.resources.diskBytes
                            )
                        )
                    )
                }
                return@withContext Result.success(stats)
            } catch (e: Exception) {
                Log.w("ServerRepository", "Live stats fetch error: ${e.message}")
            }
        }

        val cached = serverDao.getServer(serverIdentifier)
        val message = if (cached?.isOtherServer == true) {
            "Live telemetry is unavailable for another user's server with the current Client API key."
        } else {
            "Live server telemetry is unavailable right now."
        }
        Log.w("ServerRepository", message)
        Result.failure(Exception(message))
    }

    suspend fun sendPowerAction(serverIdentifier: String, signal: String): Result<Unit> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))

        try {
            val service = ApiClient.getService()
            val res = service.sendPowerSignal(serverIdentifier, PowerSignalRequest(signal), "Bearer $apiKey")
            if (!res.isSuccessful) {
                val message = "Power action '$signal' failed (HTTP ${res.code()})."
                _lastError.value = message
                return@withContext Result.failure(Exception(message))
            }
            fetchServerResources(serverIdentifier)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Error sending power signal $signal", e)
            _lastError.value = "Power action failed: ${friendlyApiError(e)}"
            Result.failure(e)
        }
    }

    suspend fun sendConsoleCommand(serverIdentifier: String, command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanCmd = command.trim()
        if (cleanCmd.isEmpty()) return@withContext Result.success(Unit)

        historyDao.insertCommand(
            CommandHistoryEntity(
                serverIdentifier = serverIdentifier,
                command = cleanCmd
            )
        )

        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))

        // Prefer the live WebSocket. If it is not connected, use the documented HTTP
        // command endpoint; neither path fabricates server output.
        val wsSent = webSocketManager.sendConsoleCommand(cleanCmd)
        if (!wsSent) {
            try {
                val response = ApiClient.getService().sendConsoleCommand(
                    serverIdentifier,
                    ConsoleCommandRequest(cleanCmd),
                    "Bearer $apiKey"
                )
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Command failed (HTTP ${response.code()})."))
                }
            } catch (e: Exception) {
                Log.e("ServerRepository", "Console command failed", e)
                return@withContext Result.failure(e)
            }
        }

        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        webSocketManager.appendLocalLog(
            ConsoleLogEntry(
                rawText = "> $cleanCmd",
                timestamp = timeStr,
                level = LogLevel.COMMAND,
                source = "Console"
            )
        )
        Result.success(Unit)
    }

    suspend fun connectServerConsole(serverIdentifier: String) = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) {
            webSocketManager.appendLocalLog(
                ConsoleLogEntry(
                    rawText = "[System] Add a Client API key in Settings to open the live console.",
                    level = LogLevel.WARN,
                    source = "Client"
                )
            )
            return@withContext
        }

        try {
            val service = ApiClient.getService()
            val wsData = service.getWebsocketCredentials(serverIdentifier, "Bearer $apiKey")
            webSocketManager.connect(wsData.data.socket, wsData.data.token)
        } catch (e: Exception) {
            Log.e("ServerRepository", "Failed to retrieve websocket credentials", e)
            webSocketManager.appendLocalLog(
                ConsoleLogEntry(
                    rawText = "[System] Could not obtain live console credentials: ${friendlyApiError(e)}",
                    level = LogLevel.ERROR,
                    source = "Client"
                )
            )
        }
    }

    suspend fun listFiles(serverIdentifier: String, directory: String = "/"): Result<List<PteroFileAttributes>> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        val root = normalizeDirectory(directory)
        try {
            val response = ApiClient.getService().listFiles(serverIdentifier, root, "Bearer $apiKey")
            Result.success(response.data.map { it.attributes })
        } catch (e: Exception) {
            Log.e("ServerRepository", "List files failed", e)
            Result.failure(Exception("File list failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun getFileContent(serverIdentifier: String, filePath: String): Result<String> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        val path = normalizeFilePath(filePath)
        try {
            val body = ApiClient.getService().getFileContents(serverIdentifier, path, "Bearer $apiKey")
            Result.success(body.string())
        } catch (e: Exception) {
            Log.e("ServerRepository", "Get file contents failed", e)
            Result.failure(Exception("Could not open file: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun saveFileContent(serverIdentifier: String, filePath: String, content: String): Result<Unit> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        val path = normalizeFilePath(filePath)
        try {
            val body = content.toRequestBody("text/plain; charset=utf-8".toMediaTypeOrNull())
            val response = ApiClient.getService().writeFileContents(serverIdentifier, path, body, "Bearer $apiKey")
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("Save failed (HTTP ${response.code()})."))
        } catch (e: Exception) {
            Log.e("ServerRepository", "Save file failed", e)
            Result.failure(Exception("Save failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun createFolder(serverIdentifier: String, root: String, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        val cleanName = name.trim().trim('/')
        if (cleanName.isBlank() || cleanName.contains("/")) return@withContext Result.failure(Exception("Enter a valid folder name."))
        try {
            val response = ApiClient.getService().createFolder(
                serverIdentifier,
                CreateFolderRequest(normalizeDirectory(root), cleanName),
                "Bearer $apiKey"
            )
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("Create folder failed (HTTP ${response.code()})."))
        } catch (e: Exception) {
            Result.failure(Exception("Create folder failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun createFile(serverIdentifier: String, root: String, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        val cleanName = name.trim().trim('/')
        if (cleanName.isBlank() || cleanName.contains("/")) return@withContext Result.failure(Exception("Enter a valid file name."))
        val path = normalizeDirectory(root).trimEnd('/') + "/" + cleanName
        try {
            val body = "".toRequestBody("text/plain; charset=utf-8".toMediaTypeOrNull())
            val response = ApiClient.getService().writeFileContents(serverIdentifier, path, body, "Bearer $apiKey")
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("Create file failed (HTTP ${response.code()})."))
        } catch (e: Exception) {
            Result.failure(Exception("Create file failed: ${friendlyApiError(e)}", e))
        }
    }

    suspend fun deleteFiles(serverIdentifier: String, root: String, files: List<String>): Result<Unit> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        try {
            val response = ApiClient.getService().deleteFiles(
                serverIdentifier,
                DeleteFilesRequest(normalizeDirectory(root), files),
                "Bearer $apiKey"
            )
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(Exception("Delete failed (HTTP ${response.code()})."))
        } catch (e: Exception) {
            Result.failure(Exception("Delete failed: ${friendlyApiError(e)}", e))
        }
    }

    private fun normalizeDirectory(directory: String): String {
        val value = directory.trim()
        if (value.isBlank() || value == "/") return "/"
        return "/" + value.trim('/')
    }

    private fun normalizeFilePath(path: String): String {
        val value = path.trim()
        return if (value.startsWith("/")) value else "/$value"
    }


    suspend fun listBackups(serverIdentifier: String): Result<List<PteroBackupAttributes>> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        try {
            val res = ApiClient.getService().listBackups(serverIdentifier, "Bearer $apiKey")
            Result.success(res.data.map { it.attributes })
        } catch (e: Exception) {
            Log.e("ServerRepository", "Backups failed", e)
            Result.failure(e)
        }
    }

    suspend fun createBackup(serverIdentifier: String, name: String?): Result<Unit> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()

        if (apiKey.isNotBlank()) {
            try {
                val service = ApiClient.getService()
                service.createBackup(serverIdentifier, CreateBackupRequest(name = name))
                return@withContext Result.success(Unit)
            } catch (e: Exception) {
                return@withContext Result.failure(e)
            }
        }
        Result.success(Unit)
    }

    suspend fun deleteBackup(serverIdentifier: String, backupUuid: String): Result<Unit> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()

        if (apiKey.isNotBlank()) {
            try {
                val service = ApiClient.getService()
                service.deleteBackup(serverIdentifier, backupUuid)
                return@withContext Result.success(Unit)
            } catch (e: Exception) {
                return@withContext Result.failure(e)
            }
        }
        Result.success(Unit)
    }

    suspend fun listDatabases(serverIdentifier: String): Result<List<PteroDatabaseAttributes>> = withContext(Dispatchers.IO) {
        val config = configDao.getConfig()
        val apiKey = config?.apiKey.orEmpty().trim()
        if (apiKey.isBlank()) return@withContext Result.failure(Exception("Client API key is not configured."))
        try {
            val res = ApiClient.getService().listDatabases(serverIdentifier, "Bearer $apiKey")
            Result.success(res.data.map { it.attributes })
        } catch (e: Exception) {
            Log.e("ServerRepository", "Databases call failed", e)
            Result.failure(e)
        }
    }


}
