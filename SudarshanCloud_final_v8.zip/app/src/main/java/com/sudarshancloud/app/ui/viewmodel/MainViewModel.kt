package com.sudarshancloud.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sudarshancloud.app.data.api.ConsoleLogEntry
import com.sudarshancloud.app.data.api.LogLevel
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.db.PanelConfigEntity
import com.sudarshancloud.app.data.model.PteroBackupAttributes
import com.sudarshancloud.app.data.model.PteroDatabaseAttributes
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import com.sudarshancloud.app.data.repository.ServerRepository
import com.sudarshancloud.app.ui.components.NavDestination
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class FileEditorState(
    val filePath: String,
    val content: String,
    val isSaving: Boolean = false,
    val hasUnsavedChanges: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val repository = ServerRepository(application)

    val configState: StateFlow<PanelConfigEntity?> = repository.configFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val serversState: StateFlow<List<CachedServerEntity>> = repository.cachedServersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val realtimeStats: StateFlow<Map<String, PteroStatsAttributes>> = repository.realtimeStatsMap

    private val _selectedServer = MutableStateFlow<CachedServerEntity?>(null)
    val selectedServer: StateFlow<CachedServerEntity?> = _selectedServer.asStateFlow()

    private val _currentDestination = MutableStateFlow(NavDestination.SERVERS)
    val currentDestination: StateFlow<NavDestination> = _currentDestination.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _userFeedback = MutableStateFlow<String?>(null)
    val userFeedback: StateFlow<String?> = _userFeedback.asStateFlow()

    // Remote Console
    private val _consoleLogs = MutableStateFlow<List<ConsoleLogEntry>>(emptyList())
    val consoleLogs: StateFlow<List<ConsoleLogEntry>> = _consoleLogs.asStateFlow()

    // File Manager
    private val _currentDirectory = MutableStateFlow("/")
    val currentDirectory: StateFlow<String> = _currentDirectory.asStateFlow()

    private val _filesList = MutableStateFlow<List<PteroFileAttributes>>(emptyList())
    val filesList: StateFlow<List<PteroFileAttributes>> = _filesList.asStateFlow()

    private val _isLoadingFiles = MutableStateFlow(false)
    val isLoadingFiles: StateFlow<Boolean> = _isLoadingFiles.asStateFlow()

    private val _fileEditorState = MutableStateFlow<FileEditorState?>(null)
    val fileEditorState: StateFlow<FileEditorState?> = _fileEditorState.asStateFlow()

    // Backups & Databases
    private val _backupsList = MutableStateFlow<List<PteroBackupAttributes>>(emptyList())
    val backupsList: StateFlow<List<PteroBackupAttributes>> = _backupsList.asStateFlow()

    private val _databasesList = MutableStateFlow<List<PteroDatabaseAttributes>>(emptyList())
    val databasesList: StateFlow<List<PteroDatabaseAttributes>> = _databasesList.asStateFlow()

    private var pollingJob: Job? = null

    init {
        viewModelScope.launch {
            repository.initialize()
            val result = repository.fetchServersFromPanel()
            if (result.isSuccess) {
                _userFeedback.value = "Connected to SudarshanCloud"
            }
        }

        viewModelScope.launch {
            repository.webSocketManager.logsFlow.collect { entry ->
                _consoleLogs.value = (_consoleLogs.value + entry).takeLast(300)
            }
        }

        viewModelScope.launch {
            serversState.collectLatest { list ->
                val selected = _selectedServer.value
                if (selected == null || list.none { it.identifier == selected.identifier }) {
                    _selectedServer.value = list.firstOrNull()
                }
            }
        }

        startTelemetryLoop()
    }

    fun selectDestination(dest: NavDestination) {
        _currentDestination.value = dest
        val server = _selectedServer.value
        if (server != null) {
            when (dest) {
                NavDestination.CONSOLE -> {
                    if (!server.isOtherServer) {
                        viewModelScope.launch { repository.connectServerConsole(server.identifier) }
                    } else {
                        _userFeedback.value = "Console access is unavailable for another user's server."
                    }
                }
                NavDestination.FILES -> {
                    if (!server.isOtherServer) loadFiles(server.identifier, _currentDirectory.value)
                    else _userFeedback.value = "File access is unavailable for another user's server."
                }
                NavDestination.BACKUPS -> {
                    if (!server.isOtherServer) loadBackups(server.identifier)
                    else _userFeedback.value = "Backup access is unavailable for another user's server."
                }
                NavDestination.DATABASES -> {
                    if (!server.isOtherServer) loadDatabases(server.identifier)
                    else _userFeedback.value = "Database access is unavailable for another user's server."
                }
                else -> {}
            }
        }
    }

    fun selectServer(server: CachedServerEntity) {
        _selectedServer.value = server
        _currentDirectory.value = "/"
        _filesList.value = emptyList()
        _fileEditorState.value = null
        if (!server.isOtherServer) {
            viewModelScope.launch { repository.connectServerConsole(server.identifier) }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun refreshAll() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val res = repository.fetchServersFromPanel()
            if (res.isSuccess) {
                _userFeedback.value = "Synced with SudarshanCloud panel"
            } else {
                _userFeedback.value = repository.lastError.value ?: "Panel sync failed"
            }
            _isRefreshing.value = false
        }
    }

    fun sendPowerAction(serverIdentifier: String, signal: String) {
        viewModelScope.launch {
            repository.sendPowerAction(serverIdentifier, signal)
            _userFeedback.value = "Power signal '$signal' sent to $serverIdentifier"
            delay(500)
            repository.fetchServerResources(serverIdentifier)
        }
    }

    fun sendConsoleCommand(command: String) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            repository.sendConsoleCommand(server.identifier, command)
        }
    }

    fun clearConsoleLogs() {
        _consoleLogs.value = emptyList()
        _userFeedback.value = "Console terminal cleared"
    }

    fun saveApiConfig(panelUrl: String, apiKey: String, applicationApiKey: String, userEmail: String, showOtherServers: Boolean) {
        viewModelScope.launch {
            repository.savePanelConfig(panelUrl, apiKey, applicationApiKey, showOtherServers, userEmail)
            _userFeedback.value = "API settings saved. Connecting to SudarshanCloud..."
            val result = repository.fetchServersFromPanel()
            if (result.isSuccess) {
                _userFeedback.value = "Connected to SudarshanCloud! Loaded ${result.getOrNull()?.size ?: 0} servers."
            } else {
                _userFeedback.value = "Saved! ${repository.lastError.value ?: "Connection failed"}"
            }
        }
    }

    fun loadFiles(serverIdentifier: String, directory: String) {
        viewModelScope.launch {
            _isLoadingFiles.value = true
            _currentDirectory.value = directory
            val res = repository.listFiles(serverIdentifier, directory)
            if (res.isSuccess) {
                _filesList.value = res.getOrDefault(emptyList())
            } else {
                _filesList.value = emptyList()
                _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to load files"
            }
            _isLoadingFiles.value = false
        }
    }

    fun openFile(filePath: String) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.getFileContent(server.identifier, filePath)
            if (res.isSuccess) {
                _fileEditorState.value = FileEditorState(
                    filePath = filePath,
                    content = res.getOrDefault("")
                )
            }
        }
    }

    fun updateEditorContent(newContent: String) {
        _fileEditorState.value = _fileEditorState.value?.copy(
            content = newContent,
            hasUnsavedChanges = true
        )
    }

    fun saveFileEditorContent() {
        val current = _fileEditorState.value ?: return
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            _fileEditorState.value = current.copy(isSaving = true)
            val res = repository.saveFileContent(server.identifier, current.filePath, current.content)
            if (res.isSuccess) {
                _fileEditorState.value = current.copy(isSaving = false, hasUnsavedChanges = false)
                _userFeedback.value = "File saved successfully"
            } else {
                _fileEditorState.value = current.copy(isSaving = false)
                _userFeedback.value = "Failed to save file: ${res.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun closeFileEditor() {
        _fileEditorState.value = null
    }

    fun createFolder(name: String) {
        val server = _selectedServer.value ?: return
        val dir = _currentDirectory.value
        viewModelScope.launch {
            val res = repository.createFolder(server.identifier, dir, name)
            if (res.isSuccess) {
                _userFeedback.value = "Folder created: $name"
                loadFiles(server.identifier, dir)
            }
        }
    }

    fun createFile(name: String) {
        val server = _selectedServer.value ?: return
        val dir = _currentDirectory.value
        viewModelScope.launch {
            val res = repository.createFile(server.identifier, dir, name)
            if (res.isSuccess) {
                _userFeedback.value = "File created: $name"
                loadFiles(server.identifier, dir)
            } else {
                _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to create file"
            }
        }
    }

    fun deleteFile(fileName: String) {
        val server = _selectedServer.value ?: return
        val dir = _currentDirectory.value
        viewModelScope.launch {
            val res = repository.deleteFiles(server.identifier, dir, listOf(fileName))
            if (res.isSuccess) {
                _userFeedback.value = "Deleted $fileName"
                loadFiles(server.identifier, dir)
            }
        }
    }

    fun loadBackups(serverIdentifier: String) {
        viewModelScope.launch {
            val res = repository.listBackups(serverIdentifier)
            if (res.isSuccess) {
                _backupsList.value = res.getOrDefault(emptyList())
            }
        }
    }

    fun createBackup(name: String?) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.createBackup(server.identifier, name)
            if (res.isSuccess) {
                _userFeedback.value = "Backup created: ${name ?: "Snapshot"}"
                loadBackups(server.identifier)
            }
        }
    }

    fun loadDatabases(serverIdentifier: String) {
        viewModelScope.launch {
            val res = repository.listDatabases(serverIdentifier)
            if (res.isSuccess) {
                _databasesList.value = res.getOrDefault(emptyList())
            }
        }
    }

    fun clearFeedback() {
        _userFeedback.value = null
    }

    private fun startTelemetryLoop() {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            while (isActive) {
                val snapshot = serversState.value
                    .filter { !it.isOtherServer }
                    .map { it.identifier }
                    .distinct()
                if (snapshot.isNotEmpty()) {
                    coroutineScope {
                        snapshot.map { id ->
                            async { repository.fetchServerResources(id) }
                        }.awaitAll()
                    }
                }
                delay(3000)
            }
        }
    }
}
