# SudarshanCloud Android app

This is a native Android/Jetpack Compose project for managing Pterodactyl servers through the Pterodactyl Client API.

## Build

The project is packaged as a Gradle project with the Gradle wrapper at the project root. Open the ZIP as-is; do not add another folder around the project files.

On Linux/macOS:

```bash
./gradlew :app:assembleDebug
```

On Windows:

```bat
gradlew.bat :app:assembleDebug
```

The generated debug APK is under `app/build/outputs/apk/debug/`.

## Configure the app

Open Settings in the app and enter:

- Pterodactyl Panel URL, for example `https://portal.sudarshancloud.com`
- A Pterodactyl Client API key with the permissions required for the operations you want to perform
- Optional account email

The app stores the panel credentials using Android encrypted preferences when the device keystore is available.

## Converter requirements

The ZIP intentionally contains these wrapper files at its root:

- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`

The Android manifest includes the correct Android network and foreground-service permissions required by the app.
