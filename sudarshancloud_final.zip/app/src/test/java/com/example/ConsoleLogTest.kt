package com.example

import com.example.data.api.ConnectionStatus
import com.example.data.api.ConsoleLogEntry
import com.example.data.api.LogLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConsoleLogTest {

    @Test
    fun consoleLogEntry_creationAndDefaults() {
        val entry = ConsoleLogEntry(
            rawText = "[Server thread/INFO]: Done (2.41s)! For help, type \"help\"",
            level = LogLevel.INFO,
            source = "Server"
        )

        assertEquals(LogLevel.INFO, entry.level)
        assertEquals("Server", entry.source)
        assertTrue(entry.rawText.contains("Done (2.41s)"))
    }

    @Test
    fun connectionStatus_enumHierarchy() {
        val statuses = ConnectionStatus.values()
        assertTrue(statuses.contains(ConnectionStatus.AUTHENTICATED))
        assertTrue(statuses.contains(ConnectionStatus.CONNECTED))
        assertTrue(statuses.contains(ConnectionStatus.CONNECTING))
        assertTrue(statuses.contains(ConnectionStatus.DISCONNECTED))
        assertTrue(statuses.contains(ConnectionStatus.ERROR))
    }
}
