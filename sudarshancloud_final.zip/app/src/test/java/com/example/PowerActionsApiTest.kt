package com.example

import com.example.data.api.PterodactylApi
import com.example.data.model.PowerSignalRequest
import com.example.data.model.Server
import com.example.ui.components.PowerAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class PowerActionsTest {

    @Test
    fun powerActionEnum_mapsSignalsCorrectly() {
        assertEquals("start", PowerAction.START.signal)
        assertEquals("stop", PowerAction.STOP.signal)
        assertEquals("restart", PowerAction.RESTART.signal)
        assertEquals("kill", PowerAction.KILL.signal)
    }

    @Test
    fun powerSignalRequest_hasExpectedSignalPayload() {
        val startReq = PowerSignalRequest(PowerAction.START.signal)
        val stopReq = PowerSignalRequest(PowerAction.STOP.signal)
        val restartReq = PowerSignalRequest(PowerAction.RESTART.signal)
        val killReq = PowerSignalRequest(PowerAction.KILL.signal)

        assertEquals("start", startReq.signal)
        assertEquals("stop", stopReq.signal)
        assertEquals("restart", restartReq.signal)
        assertEquals("kill", killReq.signal)
    }

    @Test
    fun serverPowerActionState_detectsEffectiveStatus() {
        val serverOnline = Server(
            id = "c2e5b721",
            name = "Sum",
            status = "online"
        )
        assertEquals("online", serverOnline.effectiveStatus)

        val serverSuspended = Server(
            id = "c2e5b721",
            name = "Sum",
            isSuspended = true
        )
        assertEquals("suspended", serverSuspended.effectiveStatus)
    }
}
