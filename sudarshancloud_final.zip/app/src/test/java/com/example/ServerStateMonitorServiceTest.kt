package com.example

import com.example.service.ServerStateMonitorService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ServerStateMonitorServiceTest {

    @Test
    fun serviceConstants_areConfiguredCorrectly() {
        assertEquals("channel_server_monitor", ServerStateMonitorService.CHANNEL_MONITOR_ID)
        assertEquals("channel_server_alerts", ServerStateMonitorService.CHANNEL_ALERTS_ID)
        assertEquals(10001, ServerStateMonitorService.NOTIFICATION_ID_FOREGROUND)
        assertNotNull(ServerStateMonitorService.ACTION_START_SERVICE)
        assertNotNull(ServerStateMonitorService.ACTION_STOP_SERVICE)
    }
}
