package com.example

import com.example.data.model.Allocation
import com.example.data.model.Container
import com.example.data.model.Limits
import com.example.data.model.Server
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ServerSearchFilterTest {

    private val testServers = listOf(
        Server(
            id = "srv-1",
            uuid = "uuid-1",
            identifier = "a1b2c3d4",
            name = "Survival Hub [Paper 1.20]",
            nodeName = "node-in-01",
            status = "running",
            isSuspended = false,
            limits = Limits(memoryMb = 4096, cpuLimit = 200.0, diskMb = 10240),
            allocations = listOf(Allocation(id = 1, ip = "182.77.68.174", port = 25565, isDefault = true)),
            container = Container(image = "ghcr.io/pterodactyl/yolks:java_17", isInstalled = true)
        ),
        Server(
            id = "srv-2",
            uuid = "uuid-2",
            identifier = "e5f6g7h8",
            name = "Bedwars Lobby",
            nodeName = "node-in-02",
            status = "offline",
            isSuspended = false,
            limits = Limits(memoryMb = 2048, cpuLimit = 100.0, diskMb = 5120),
            allocations = listOf(Allocation(id = 2, ip = "182.77.68.175", port = 25566, isDefault = true)),
            container = Container(image = "ghcr.io/pterodactyl/yolks:java_17", isInstalled = true)
        ),
        Server(
            id = "srv-3",
            uuid = "uuid-3",
            identifier = "i9j0k1l2",
            name = "Creative Plot World",
            nodeName = "node-in-01",
            status = "starting",
            isSuspended = false,
            limits = Limits(memoryMb = 3072, cpuLimit = 150.0, diskMb = 8192),
            allocations = listOf(Allocation(id = 3, ip = "182.77.68.176", port = 25567, isDefault = true)),
            container = Container(image = "ghcr.io/pterodactyl/yolks:java_17", isInstalled = true)
        )
    )

    @Test
    fun filterByName_returnsMatchingServer() {
        val query = "bedwars"
        val results = testServers.filter { it.name.contains(query, ignoreCase = true) }
        assertEquals(1, results.size)
        assertEquals("Bedwars Lobby", results[0].name)
    }

    @Test
    fun filterByStatus_returnsMatchingServers() {
        val running = testServers.filter { it.status.equals("running", ignoreCase = true) }
        assertEquals(1, running.size)
        assertEquals("Survival Hub [Paper 1.20]", running[0].name)

        val offline = testServers.filter { it.status.equals("offline", ignoreCase = true) }
        assertEquals(1, offline.size)
        assertEquals("Bedwars Lobby", offline[0].name)
    }

    @Test
    fun filterBySearchQueryAndStatus_combinesCorrectly() {
        val statusFilter = "running"
        val query = "survival"

        val results = testServers.filter { server ->
            server.status.equals(statusFilter, ignoreCase = true) &&
            server.name.contains(query, ignoreCase = true)
        }

        assertEquals(1, results.size)
        assertEquals("Survival Hub [Paper 1.20]", results[0].name)
    }

    @Test
    fun filterBySearchQueryMatchingStatusKeyword() {
        val query = "offline"
        val results = testServers.filter { server ->
            server.name.contains(query, ignoreCase = true) ||
            server.status.contains(query, ignoreCase = true)
        }
        assertEquals(1, results.size)
        assertEquals("Bedwars Lobby", results[0].name)
    }
}
