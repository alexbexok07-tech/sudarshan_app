package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SudarshanCloud Brand Colors
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F1726)
val DarkSurfaceElevated = Color(0xFF162032)
val DarkSurfaceHighlight = Color(0xFF1E2D44)
val DarkBorder = Color(0xFF283852)

val BrandGold = Color(0xFFEAB308)
val BrandGoldLight = Color(0xFFFACC15)
val BrandGoldDark = Color(0xFFCA8A04)

val StatusOnline = Color(0xFF22C55E)
val StatusOnlineContainer = Color(0xFF052E16)
val StatusOffline = Color(0xFF64748B)
val StatusOfflineContainer = Color(0xFF1E293B)
val StatusStarting = Color(0xFFEAB308)
val StatusStartingContainer = Color(0xFF422006)
val StatusStopping = Color(0xFFEF4444)
val StatusStoppingContainer = Color(0xFF450A0A)

val TerminalBackground = Color(0xFF05080E)
val TerminalText = Color(0xFFE2E8F0)
val TerminalInfo = Color(0xFF38BDF8)
val TerminalWarn = Color(0xFFFBBF24)
val TerminalError = Color(0xFFF87171)
val TerminalSuccess = Color(0xFF4ADE80)
val TerminalPrompt = Color(0xFFA855F7)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AccentCyan = Color(0xFF06B6D4)
val AccentPurple = Color(0xFF8B5CF6)
