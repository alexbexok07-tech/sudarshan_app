package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StatusOffline
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusOnlineContainer
import com.example.ui.theme.StatusStarting
import com.example.ui.theme.StatusStopping

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val normalized = status.lowercase()
    val (bgColor, textColor, dotColor, label) = when {
        normalized.contains("running") || normalized.contains("online") -> {
            Tuple4(
                Color(0xFF1B432C),
                Color(0xFF4ADE80),
                StatusOnline,
                "Online"
            )
        }
        normalized.contains("starting") -> {
            Tuple4(
                Color(0xFF452D0D),
                Color(0xFFFBBF24),
                StatusStarting,
                "Starting"
            )
        }
        normalized.contains("stopping") || normalized.contains("kill") -> {
            Tuple4(
                Color(0xFF451417),
                Color(0xFFF87171),
                StatusStopping,
                "Stopping"
            )
        }
        else -> {
            Tuple4(
                Color(0xFF1E293B),
                Color(0xFF94A3B8),
                StatusOffline,
                "Offline"
            )
        }
    }

    Box(
        modifier = modifier
            .testTag("status_badge_${normalized}")
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = textColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
