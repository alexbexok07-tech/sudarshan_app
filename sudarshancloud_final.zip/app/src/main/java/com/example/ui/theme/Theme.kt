package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SudarshanColorScheme = darkColorScheme(
    primary = BrandGold,
    onPrimary = DarkBackground,
    primaryContainer = BrandGoldDark,
    onPrimaryContainer = TextPrimary,
    secondary = StatusOnline,
    onSecondary = DarkBackground,
    secondaryContainer = StatusOnlineContainer,
    onSecondaryContainer = StatusOnline,
    tertiary = AccentCyan,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    error = StatusStopping,
    onError = TextPrimary,
    errorContainer = StatusStoppingContainer,
    onErrorContainer = StatusStopping
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SudarshanColorScheme,
        typography = Typography,
        content = content
    )
}
