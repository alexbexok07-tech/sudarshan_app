package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.api.ConsoleLogEntry
import com.example.data.api.LogLevel
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalError
import com.example.ui.theme.TerminalInfo
import com.example.ui.theme.TerminalPrompt
import com.example.ui.theme.TerminalSuccess
import com.example.ui.theme.TerminalText
import com.example.ui.theme.TerminalWarn
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

enum class ConsoleFilter {
    ALL,
    INFO,
    WARN,
    ERROR
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TerminalView(
    logs: List<ConsoleLogEntry>,
    onSendCommand: (String) -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var activeFilter by remember { mutableStateOf(ConsoleFilter.ALL) }
    var commandInput by remember { mutableStateOf("") }
    var isExpanded by remember { mutableStateOf(false) }

    val allCount = logs.size
    val infoCount = logs.count { it.level == LogLevel.INFO }
    val warnCount = logs.count { it.level == LogLevel.WARN }
    val errorCount = logs.count { it.level == LogLevel.ERROR }

    val filteredLogs = remember(logs, activeFilter) {
        when (activeFilter) {
            ConsoleFilter.ALL -> logs
            ConsoleFilter.INFO -> logs.filter { it.level == LogLevel.INFO || it.level == LogLevel.COMMAND }
            ConsoleFilter.WARN -> logs.filter { it.level == LogLevel.WARN }
            ConsoleFilter.ERROR -> logs.filter { it.level == LogLevel.ERROR }
        }
    }

    // Auto-scroll to latest log entry
    LaunchedEffect(filteredLogs.size) {
        if (filteredLogs.isNotEmpty()) {
            listState.animateScrollToItem(filteredLogs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        // Top Toolbar: Filter Chips and Action Buttons (Matches Screenshot 1)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Filter tabs
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = activeFilter == ConsoleFilter.ALL,
                    onClick = { activeFilter = ConsoleFilter.ALL },
                    label = {
                        Text(
                            text = "View All (${if (allCount > 99) "99+" else allCount})",
                            fontSize = 11.sp
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF334155),
                        selectedLabelColor = TextPrimary,
                        containerColor = DarkSurface,
                        labelColor = TextSecondary
                    )
                )

                FilterChip(
                    selected = activeFilter == ConsoleFilter.INFO,
                    onClick = { activeFilter = ConsoleFilter.INFO },
                    label = {
                        Text(
                            text = "Info (${if (infoCount > 99) "99+" else infoCount})",
                            fontSize = 11.sp
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF0369A1),
                        selectedLabelColor = Color.White,
                        containerColor = DarkSurface,
                        labelColor = TextSecondary
                    )
                )

                FilterChip(
                    selected = activeFilter == ConsoleFilter.WARN,
                    onClick = { activeFilter = ConsoleFilter.WARN },
                    label = {
                        Text(
                            text = "Warning ($warnCount)",
                            fontSize = 11.sp
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFB45309),
                        selectedLabelColor = Color.White,
                        containerColor = DarkSurface,
                        labelColor = TextSecondary
                    )
                )

                if (errorCount > 0) {
                    FilterChip(
                        selected = activeFilter == ConsoleFilter.ERROR,
                        onClick = { activeFilter = ConsoleFilter.ERROR },
                        label = {
                            Text(
                                text = "Errors ($errorCount)",
                                fontSize = 11.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFB91C1C),
                            selectedLabelColor = Color.White,
                            containerColor = DarkSurface,
                            labelColor = TextSecondary
                        )
                    )
                }
            }

            // Action buttons: Trash, Copy, Fullscreen
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("terminal_clear_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear logs",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = {
                        val text = filteredLogs.joinToString("\n") { it.rawText }
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Terminal Logs", text))
                        Toast.makeText(context, "Terminal logs copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("terminal_copy_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy logs",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("terminal_expand_btn")
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = "Toggle height",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Terminal Screen Body
        SelectionContainer(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (isExpanded) 420.dp else 240.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(TerminalBackground)
                .padding(8.dp)
        ) {
            if (filteredLogs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Terminal idle. No console output received yet.",
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredLogs, key = { it.id }) { log ->
                        val annotated = buildAnnotatedString {
                            when (log.level) {
                                LogLevel.COMMAND -> {
                                    withStyle(SpanStyle(color = TerminalPrompt, fontWeight = FontWeight.Bold)) {
                                        append("> ")
                                    }
                                    withStyle(SpanStyle(color = TerminalSuccess)) {
                                        append(log.rawText.removePrefix(">").trim())
                                    }
                                }
                                LogLevel.WARN -> {
                                    withStyle(SpanStyle(color = TerminalWarn)) {
                                        append(log.rawText)
                                    }
                                }
                                LogLevel.ERROR -> {
                                    withStyle(SpanStyle(color = TerminalError, fontWeight = FontWeight.SemiBold)) {
                                        append(log.rawText)
                                    }
                                }
                                LogLevel.SYSTEM -> {
                                    withStyle(SpanStyle(color = Color(0xFFA855F7))) {
                                        append(log.rawText)
                                    }
                                }
                                LogLevel.INFO -> {
                                    // Highlight advancement brackets or usernames
                                    if (log.rawText.contains("[") && log.rawText.contains("]")) {
                                        val parts = log.rawText.split("]")
                                        if (parts.size >= 2) {
                                            withStyle(SpanStyle(color = TextSecondary)) {
                                                append(parts[0] + "]")
                                            }
                                            withStyle(SpanStyle(color = TerminalText)) {
                                                append(log.rawText.substring(parts[0].length + 1))
                                            }
                                        } else {
                                            withStyle(SpanStyle(color = TerminalText)) {
                                                append(log.rawText)
                                            }
                                        }
                                    } else {
                                        withStyle(SpanStyle(color = TerminalText)) {
                                            append(log.rawText)
                                        }
                                    }
                                }
                            }
                        }

                        Text(
                            text = annotated,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Command Suggestions
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val quickCommands = listOf("help", "list", "status", "save-all", "say Hello")
            quickCommands.forEach { cmd ->
                SuggestionChip(
                    onClick = {
                        commandInput = cmd
                        onSendCommand(cmd)
                        commandInput = ""
                    },
                    label = { Text("/$cmd", fontSize = 11.sp) },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = DarkSurfaceHighlight,
                        labelColor = TextPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Command Input Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = {
                    Text(
                        text = "Type command (e.g. /say, op, whitelist)...",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = {
                            if (commandInput.isNotBlank()) {
                                onSendCommand(commandInput)
                                commandInput = ""
                            }
                        },
                        modifier = Modifier.testTag("send_command_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send Command",
                            tint = Color(0xFFEAB308),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (commandInput.isNotBlank()) {
                            onSendCommand(commandInput)
                            commandInput = ""
                        }
                    }
                ),
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFEAB308),
                    unfocusedBorderColor = DarkBorder,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                )
            )
        }
    }
}
