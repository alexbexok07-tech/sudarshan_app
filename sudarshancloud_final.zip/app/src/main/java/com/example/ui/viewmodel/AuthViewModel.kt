package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ApiClient
import com.example.data.repository.ServerRepository
import com.example.data.security.SecureCredentialsManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val panelUrl: String = "https://portal.sudarshancloud.com",
    val apiKey: String = "",
    val userEmail: String = "",
    val isAuthenticating: Boolean = false,
    val isAuthenticated: Boolean = false,
    val feedbackMessage: String? = null,
    val isError: Boolean = false
)

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val secureCredentialsManager = SecureCredentialsManager.getInstance(application)
    private val serverRepository = ServerRepository(application)

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        loadSavedCredentials()
    }

    private fun loadSavedCredentials() {
        val savedUrl = secureCredentialsManager.getPanelUrl().ifBlank { "https://portal.sudarshancloud.com" }
        val savedKey = secureCredentialsManager.getApiKey()
        val savedEmail = secureCredentialsManager.getUserEmail()

        _uiState.value = _uiState.value.copy(
            panelUrl = savedUrl,
            apiKey = savedKey,
            userEmail = savedEmail,
            isAuthenticated = secureCredentialsManager.hasCredentials()
        )
    }

    fun updatePanelUrl(url: String) {
        _uiState.value = _uiState.value.copy(panelUrl = url, feedbackMessage = null)
    }

    fun updateApiKey(key: String) {
        _uiState.value = _uiState.value.copy(apiKey = key, feedbackMessage = null)
    }

    fun updateUserEmail(email: String) {
        _uiState.value = _uiState.value.copy(userEmail = email, feedbackMessage = null)
    }

    fun saveAndAuthenticate(onSuccess: (() -> Unit)? = null) {
        val state = _uiState.value
        val url = state.panelUrl.trim()
        val key = state.apiKey.trim()

        if (url.isBlank()) {
            _uiState.value = state.copy(
                isError = true,
                feedbackMessage = "Please enter your Pterodactyl Panel URL."
            )
            return
        }

        if (key.isBlank()) {
            _uiState.value = state.copy(
                isError = true,
                feedbackMessage = "Please enter your Client API Key."
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isAuthenticating = true, feedbackMessage = "Verifying credentials with panel...")

            // Save encrypted
            secureCredentialsManager.saveCredentials(url, key, state.userEmail)

            // Also synchronize with repository config DB
            serverRepository.savePanelConfig(url, key, state.userEmail)

            // Test connection by fetching servers
            val result = serverRepository.fetchServersFromPanel()
            if (result.isSuccess) {
                val servers = result.getOrNull().orEmpty()
                _uiState.value = _uiState.value.copy(
                    isAuthenticating = false,
                    isAuthenticated = true,
                    isError = false,
                    feedbackMessage = "Authenticated successfully! Found ${servers.size} server(s)."
                )
                onSuccess?.invoke()
            } else {
                // Keep credentials saved as requested, but flag warning
                _uiState.value = _uiState.value.copy(
                    isAuthenticating = false,
                    isAuthenticated = true,
                    isError = false,
                    feedbackMessage = "Credentials securely saved! (Note: ${serverRepository.lastError.value ?: "Cached servers mode active"})"
                )
                onSuccess?.invoke()
            }
        }
    }

    fun clearSavedCredentials() {
        secureCredentialsManager.clearCredentials()
        viewModelScope.launch {
            serverRepository.savePanelConfig("https://portal.sudarshancloud.com", "", "")
        }
        _uiState.value = AuthUiState(
            panelUrl = "https://portal.sudarshancloud.com",
            apiKey = "",
            userEmail = "",
            isAuthenticated = false,
            feedbackMessage = "Credentials erased from secure storage."
        )
    }
}
