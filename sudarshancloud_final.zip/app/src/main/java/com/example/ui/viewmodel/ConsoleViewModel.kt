package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ApiClient
import com.example.data.api.ConnectionStatus
import com.example.data.api.ConsoleLogEntry
import com.example.data.api.LogLevel
import com.example.data.model.ConsoleCommandRequest
import com.example.data.model.Server
import com.example.data.repository.ServerRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * ConsoleViewModel manages WebSocket streaming of console logs with an automatic
 * REST API polling fallback for servers on the Pterodactyl daemon (portal.sudarshancloud.com).
 * Also handles sending live terminal commands and managing command history.
 */
class ConsoleViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ServerRepository(application)
    val webSocketManager = repository.webSocketManager

    private val _logs = MutableStateFlow<List<ConsoleLogEntry>>(emptyList())
    val logs: StateFlow<List<ConsoleLogEntry>> = _logs.asStateFlow()

    private val _connectionStatus = MutableStateFlow(ConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _isSendingCommand = MutableStateFlow(false)
    val isSendingCommand: StateFlow<Boolean> = _isSendingCommand.asStateFlow()

    private val _commandHistory = MutableStateFlow<List<String>>(
        listOf("help", "list", "tps", "status", "version")
    )
    val commandHistory: StateFlow<List<String>> = _commandHistory.asStateFlow()

    private var activeServerId: String? = null
    private var webSocketCollectJob: Job? = null
    private var statusCollectJob: Job? = null
    private var fallbackPollingJob: Job? = null

    /**
     * Initializes console streaming for the target server identifier.
     * First requests websocket credentials from the Pterodactyl API:
     * GET /api/client/servers/{server}/websocket
     * Falls back to polling if the websocket fails or panel runs with self-signed certificate.
     */
    fun attachServer(serverId: String) {
        if (activeServerId == serverId && _connectionStatus.value == ConnectionStatus.AUTHENTICATED) {
            return
        }

        activeServerId = serverId
        _logs.value = listOf(
            ConsoleLogEntry(
                rawText = "[System] Connecting to server console ($serverId)...",
                level = LogLevel.SYSTEM,
                source = "Console"
            )
        )

        // Listen for incoming WebSocket messages
        webSocketCollectJob?.cancel()
        webSocketCollectJob = viewModelScope.launch {
            webSocketManager.logsFlow.collect { entry ->
                _logs.value = (_logs.value + entry).takeLast(300)
            }
        }

        statusCollectJob?.cancel()
        statusCollectJob = viewModelScope.launch {
            webSocketManager.connectionStatus.collect { status ->
                _connectionStatus.value = status
                if (status == ConnectionStatus.ERROR || status == ConnectionStatus.DISCONNECTED) {
                    startFallbackPolling(serverId)
                }
            }
        }

        // Connect through repository (which requests websocket token & establishes OkHttp WebSocket)
        viewModelScope.launch {
            _connectionStatus.value = ConnectionStatus.CONNECTING
            repository.connectServerConsole(serverId)
        }
    }

    /**
     * Polling fallback that queries server resources and heartbeats if WebSocket connection drops.
     */
    private fun startFallbackPolling(serverId: String) {
        if (fallbackPollingJob?.isActive == true) return
        fallbackPollingJob = viewModelScope.launch {
            while (isActive && activeServerId == serverId) {
                delay(3000)
                try {
                    val res = repository.fetchServerResources(serverId)
                    if (res.isSuccess) {
                        val stats = res.getOrNull()
                        val state = stats?.currentState ?: "online"
                        val cpu = stats?.resources?.cpuAbsolute ?: 0.0
                        val memBytes = stats?.resources?.memoryBytes ?: 0L
                        val memMb = memBytes / (1024 * 1024)

                        // If logs are sparse, emit periodic heartbeats
                        if (_logs.value.size < 3) {
                            val entry = ConsoleLogEntry(
                                rawText = "[Heartbeat] State: $state | CPU: $cpu% | RAM: ${memMb}MB",
                                level = LogLevel.INFO,
                                source = "Daemon"
                            )
                            _logs.value = (_logs.value + entry).takeLast(300)
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    /**
     * Sends a command line input to the running server.
     * Tries WebSocket first; if not authenticated, uses REST API:
     * POST /api/client/servers/{server}/command
     */
    fun sendCommand(command: String) {
        val trimmed = command.trim()
        if (trimmed.isBlank()) return
        val serverId = activeServerId ?: return

        // Update history
        if (!_commandHistory.value.contains(trimmed)) {
            _commandHistory.value = (_commandHistory.value + trimmed).takeLast(20)
        }

        // Echo command to local logs
        _logs.value = (_logs.value + ConsoleLogEntry(
            rawText = "> $trimmed",
            level = LogLevel.COMMAND,
            source = "User"
        )).takeLast(300)

        viewModelScope.launch {
            _isSendingCommand.value = true
            try {
                // If WS is connected, send command through WS
                if (webSocketManager.connectionStatus.value == ConnectionStatus.AUTHENTICATED) {
                    val sent = webSocketManager.sendConsoleCommand(trimmed)
                    if (!sent) {
                        // Fallback to REST API
                        repository.sendConsoleCommand(serverId, trimmed)
                    }
                } else {
                    repository.sendConsoleCommand(serverId, trimmed)
                }
            } catch (e: Exception) {
                _logs.value = (_logs.value + ConsoleLogEntry(
                    rawText = "[Error] Failed to send command: ${e.localizedMessage ?: "Unknown error"}",
                    level = LogLevel.ERROR,
                    source = "Client"
                )).takeLast(300)
            } finally {
                _isSendingCommand.value = false
            }
        }
    }

    /**
     * Clears all accumulated logs from memory.
     */
    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun detachServer() {
        webSocketCollectJob?.cancel()
        statusCollectJob?.cancel()
        fallbackPollingJob?.cancel()
        webSocketManager.disconnect()
        _connectionStatus.value = ConnectionStatus.DISCONNECTED
        activeServerId = null
    }

    override fun onCleared() {
        super.onCleared()
        detachServer()
    }
}
