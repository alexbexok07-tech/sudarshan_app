package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Server
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusStarting
import com.example.ui.theme.StatusStopping
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Power action types supported by the Pterodactyl daemon.
 */
enum class PowerAction(val signal: String, val label: String) {
    START("start", "Start"),
    RESTART("restart", "Restart"),
    STOP("stop", "Stop"),
    KILL("kill", "Kill")
}

/**
 * Component that displays power control actions (Start, Stop, Restart, Kill)
 * for a selected server with visual feedback, status awareness, and a confirmation
 * dialog for destructive actions (Stop / Kill).
 */
@Composable
fun ServerPowerActionsComponent(
    server: Server?,
    onPowerAction: (PowerAction) -> Unit,
    modifier: Modifier = Modifier,
    isExecuting: Boolean = false,
    currentAction: PowerAction? = null
) {
    if (server == null) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSurfaceElevated)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "No server selected for power controls",
                color = TextMuted,
                fontSize = 13.sp
            )
        }
        return
    }

    var showConfirmationDialog by remember { mutableStateOf<PowerAction?>(null) }
    val isRunning = server.effectiveStatus.equals("running", ignoreCase = true) ||
            server.effectiveStatus.equals("online", ignoreCase = true)
    val isStarting = server.effectiveStatus.equals("starting", ignoreCase = true)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = null,
                    tint = Color(0xFFFACC15),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Power Controls",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            StatusBadge(status = server.effectiveStatus)
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main Power Action Buttons Row (Start, Restart, Stop)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Start Button
            PowerActionButton(
                label = "Start",
                icon = Icons.Default.PlayArrow,
                backgroundColor = Color(0xFF166534),
                contentColor = Color.White,
                iconTint = StatusOnline,
                isLoading = isExecuting && currentAction == PowerAction.START,
                enabled = !isExecuting && !isRunning && !isStarting,
                testTag = "power_action_start",
                modifier = Modifier.weight(1f),
                onClick = { onPowerAction(PowerAction.START) }
            )

            // Restart Button
            PowerActionButton(
                label = "Restart",
                icon = Icons.Default.Refresh,
                backgroundColor = Color(0xFF854D0E),
                contentColor = Color.White,
                iconTint = StatusStarting,
                isLoading = isExecuting && currentAction == PowerAction.RESTART,
                enabled = !isExecuting && isRunning,
                testTag = "power_action_restart",
                modifier = Modifier.weight(1f),
                onClick = { showConfirmationDialog = PowerAction.RESTART }
            )

            // Stop Button
            PowerActionButton(
                label = "Stop",
                icon = Icons.Default.Stop,
                backgroundColor = Color(0xFF991B1B),
                contentColor = Color.White,
                iconTint = StatusStopping,
                isLoading = isExecuting && currentAction == PowerAction.STOP,
                enabled = !isExecuting && isRunning,
                testTag = "power_action_stop",
                modifier = Modifier.weight(1f),
                onClick = { showConfirmationDialog = PowerAction.STOP }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Kill (Forced Stop) Secondary Action
        OutlinedButton(
            onClick = { showConfirmationDialog = PowerAction.KILL },
            enabled = !isExecuting && (isRunning || isStarting),
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .testTag("power_action_kill"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color(0xFFF87171)
            ),
            border = ButtonDefaults.outlinedButtonBorder.copy(
                brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF7F1D1D))
            )
        ) {
            if (isExecuting && currentAction == PowerAction.KILL) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = Color(0xFFF87171),
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Killing Server...", fontSize = 12.sp)
            } else {
                Icon(
                    imageVector = Icons.Default.ElectricBolt,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = Color(0xFFF87171)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Force Kill Process",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.5.sp
                )
            }
        }
    }

    // Confirmation dialog for Restart, Stop, or Kill
    if (showConfirmationDialog != null) {
        val action = showConfirmationDialog!!
        AlertDialog(
            onDismissRequest = { showConfirmationDialog = null },
            title = {
                Text(
                    text = "Confirm ${action.label}",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = when (action) {
                        PowerAction.KILL -> "Force killing '${server.name}' abruptly terminates the container. Unsaved world data may be lost. Are you sure?"
                        PowerAction.STOP -> "Are you sure you want to stop '${server.name}'?"
                        PowerAction.RESTART -> "Restarting '${server.name}' will disconnect active players. Proceed?"
                        PowerAction.START -> "Start '${server.name}'?"
                    },
                    color = TextSecondary,
                    fontSize = 13.5.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val toExecute = action
                        showConfirmationDialog = null
                        onPowerAction(toExecute)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (action == PowerAction.KILL || action == PowerAction.STOP) Color(0xFFEF4444) else Color(0xFFEAB308),
                        contentColor = if (action == PowerAction.KILL || action == PowerAction.STOP) Color.White else Color.Black
                    )
                ) {
                    Text(action.label)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmationDialog = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }
}

@Composable
private fun PowerActionButton(
    label: String,
    icon: ImageVector,
    backgroundColor: Color,
    contentColor: Color,
    iconTint: Color,
    isLoading: Boolean,
    enabled: Boolean,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(44.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = contentColor,
            disabledContainerColor = DarkSurfaceHighlight,
            disabledContentColor = TextMuted
        )
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                color = contentColor,
                strokeWidth = 2.dp
            )
        } else {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (enabled) iconTint else TextMuted,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
    }
}
