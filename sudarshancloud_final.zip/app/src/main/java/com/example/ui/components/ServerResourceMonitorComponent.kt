package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Server
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ResourceUsageUiState
import com.example.ui.viewmodel.ResourceUsageViewModel
import java.util.Locale

/**
 * Real-time telemetry monitoring component that polls CPU, RAM, and Disk usage
 * statistics for a selected server using [ResourceUsageViewModel].
 */
@Composable
fun ServerResourceMonitorComponent(
    server: Server?,
    viewModel: ResourceUsageViewModel,
    modifier: Modifier = Modifier,
    pollIntervalMs: Long = 2000L
) {
    // Automatically start polling when a server is selected, stop on disposal
    DisposableEffect(server?.id) {
        if (server != null) {
            viewModel.selectServerAndStartPolling(server, pollIntervalMs)
        }
        onDispose {
            viewModel.stopPolling()
        }
    }

    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("resource_usage_monitor_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorder))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Title, Live indicator & Refresh button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Real-Time Telemetry",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (state.isPolling) {
                        // Pulsing live badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF14532D))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(StatusOnline)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "LIVE",
                                    color = StatusOnline,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                IconButton(
                    onClick = { viewModel.refreshOnce() },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("resource_refresh_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Refresh Telemetry",
                        tint = Color(0xFFEAB308),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Error notice if polling encountered issue
            if (!state.errorMessage.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF3B1E1E))
                        .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = state.errorMessage ?: "",
                        color = Color(0xFFFCA5A5),
                        fontSize = 11.5.sp
                    )
                }
            }

            // 1. CPU Telemetry Bar
            val cpuLimit = state.cpuLimit
            val cpuVal = state.cpuPercentage
            val cpuProgress = if (cpuLimit > 0.0) {
                (cpuVal / cpuLimit).toFloat().coerceIn(0.01f, 1f)
            } else {
                (cpuVal / 100.0).toFloat().coerceIn(0.01f, 1f)
            }
            val cpuLimitStr = if (cpuLimit > 0.0) "${cpuLimit.toInt()}%" else "Unlimited"

            TelemetryMeterBar(
                title = "CPU Utilization",
                valueText = String.format(Locale.US, "%.1f%%", cpuVal),
                limitText = cpuLimitStr,
                progress = cpuProgress,
                barColor = when {
                    cpuVal > 85.0 -> Color(0xFFEF4444)
                    cpuVal > 60.0 -> Color(0xFFF59E0B)
                    else -> Color(0xFF10B981)
                },
                icon = Icons.Default.Speed
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 2. RAM Telemetry Bar
            val ramBytes = state.memoryBytes
            val ramLimitBytes = state.memoryLimitBytes
            val ramGiB = ramBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val ramLimitGiB = ramLimitBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val ramProgress = if (ramLimitBytes > 0) {
                (ramBytes.toDouble() / ramLimitBytes.toDouble()).toFloat().coerceIn(0.01f, 1f)
            } else 0.15f
            val ramLimitStr = if (ramLimitGiB > 0) String.format(Locale.US, "%.1f GiB", ramLimitGiB) else "Unlimited"

            TelemetryMeterBar(
                title = "Memory (RAM)",
                valueText = String.format(Locale.US, "%.2f GiB", ramGiB),
                limitText = ramLimitStr,
                progress = ramProgress,
                barColor = when {
                    ramProgress > 0.85f -> Color(0xFFEF4444)
                    ramProgress > 0.65f -> Color(0xFF3B82F6)
                    else -> Color(0xFF6366F1)
                },
                icon = Icons.Default.Memory
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Disk Storage Telemetry Bar
            val diskBytes = state.diskBytes
            val diskLimitBytes = state.diskLimitBytes
            val diskGiB = diskBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val diskLimitGiB = diskLimitBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val diskProgress = if (diskLimitBytes > 0) {
                (diskBytes.toDouble() / diskLimitBytes.toDouble()).toFloat().coerceIn(0.01f, 1f)
            } else 0.20f
            val diskLimitStr = if (diskLimitGiB > 0) String.format(Locale.US, "%.1f GiB", diskLimitGiB) else "Unlimited"

            TelemetryMeterBar(
                title = "Disk Storage",
                valueText = String.format(Locale.US, "%.2f GiB", diskGiB),
                limitText = diskLimitStr,
                progress = diskProgress,
                barColor = Color(0xFFA855F7),
                icon = Icons.Default.Storage
            )
        }
    }
}

@Composable
private fun TelemetryMeterBar(
    title: String,
    valueText: String,
    limitText: String,
    progress: Float,
    barColor: Color,
    icon: ImageVector
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        label = title
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = barColor,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Text(
                text = "$valueText / $limitText",
                color = TextPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Progress Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(DarkSurfaceHighlight)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animatedProgress)
                    .clip(RoundedCornerShape(4.dp))
                    .background(barColor)
            )
        }
    }
}
