package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.api.ApiClient
import com.example.data.db.AppDatabase
import com.example.data.db.CachedServerEntity
import com.example.data.repository.ServerRepository
import com.example.data.security.SecureCredentialsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Background Foreground Service that continuously monitors server power states
 * (running, stopping, offline, starting) and delivers instant system notifications
 * whenever a server's power state changes.
 */
class ServerStateMonitorService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private lateinit var notificationManager: NotificationManager
    private lateinit var repository: ServerRepository
    private lateinit var credentialsManager: SecureCredentialsManager

    // Tracks last known power state per server ID
    private val lastKnownServerStates = ConcurrentHashMap<String, String>()

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        repository = ServerRepository(applicationContext)
        credentialsManager = SecureCredentialsManager.getInstance(applicationContext)

        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                Log.d(TAG, "Stopping ServerStateMonitorService")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                val initialNotification = buildForegroundNotification("Monitoring server power states...")
                startForeground(NOTIFICATION_ID_FOREGROUND, initialNotification)
                startMonitoringLoop()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        Log.d(TAG, "ServerStateMonitorService destroyed")
    }

    private fun startMonitoringLoop() {
        serviceScope.launch {
            // Seed initial states from local database cache
            try {
                val dbServers = repository.cachedServersFlow.firstOrNull().orEmpty()
                for (srv in dbServers) {
                    lastKnownServerStates[srv.identifier] = srv.currentState
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed seeding initial server states", e)
            }

            while (isActive) {
                try {
                    // Check if credentials exist
                    if (credentialsManager.hasCredentials()) {
                        val fetchResult = repository.fetchServersFromPanel()
                        if (fetchResult.isSuccess) {
                            val currentServers = fetchResult.getOrNull().orEmpty()
                            checkStateChanges(currentServers)
                        } else {
                            // Query resources for cached servers
                            val cached = repository.cachedServersFlow.firstOrNull().orEmpty()
                            checkStateChangesFromCached(cached)
                        }
                    } else {
                        // In offline or local mode, check cached database servers
                        val cached = repository.cachedServersFlow.firstOrNull().orEmpty()
                        checkStateChangesFromCached(cached)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error during server state polling", e)
                }

                // Poll every 10 seconds for timely power alerts
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private fun checkStateChanges(currentServers: List<CachedServerEntity>) {
        for (item in currentServers) {
            val serverId = item.identifier
            val serverName = item.name
            // We fetch telemetry/resources to find current power status
            serviceScope.launch {
                try {
                    val api = ApiClient.getService()
                    val res = api.getServerResources(serverId)
                    val newState = res.attributes.currentState

                    evaluateStateTransition(serverId, serverName, newState)
                } catch (e: Exception) {
                    // Fallback to checking local entity state
                    evaluateStateTransition(serverId, serverName, item.currentState)
                }
            }
        }
    }

    private fun checkStateChangesFromCached(cachedServers: List<CachedServerEntity>) {
        for (server in cachedServers) {
            val serverId = server.identifier
            val serverName = server.name
            val previousState = lastKnownServerStates[serverId]

            // If we have an active update or change
            if (previousState != null && !previousState.equals(server.currentState, ignoreCase = true)) {
                evaluateStateTransition(serverId, serverName, server.currentState)
            } else if (previousState == null) {
                lastKnownServerStates[serverId] = server.currentState
            }
        }
    }

    private fun evaluateStateTransition(serverId: String, serverName: String, newState: String) {
        val previousState = lastKnownServerStates[serverId]
        if (previousState != null && !previousState.equals(newState, ignoreCase = true)) {
            Log.i(TAG, "State transition detected for '$serverName': $previousState -> $newState")
            lastKnownServerStates[serverId] = newState
            sendStateChangeNotification(serverName, previousState, newState)
        } else if (previousState == null) {
            lastKnownServerStates[serverId] = newState
        }
    }

    private fun sendStateChangeNotification(serverName: String, oldState: String, newState: String) {
        val notificationId = serverName.hashCode()

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusEmoji = when (newState.lowercase()) {
            "running" -> "🟢"
            "offline" -> "🔴"
            "stopping" -> "🟠"
            "starting" -> "🟡"
            else -> "⚡"
        }

        val title = "$statusEmoji Server Status: $serverName"
        val message = "Server is now ${newState.uppercase()} (changed from $oldState)"

        val notification = NotificationCompat.Builder(this, CHANNEL_ALERTS_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))
            .build()

        notificationManager.notify(notificationId, notification)
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val stopIntent = Intent(this, ServerStateMonitorService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1001,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = Intent(this, MainActivity::class.java)
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            1002,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_MONITOR_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("SudarshanCloud Server Monitor")
            .setContentText(contentText)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Monitor", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Channel 1: Persistent Service Channel
            val monitorChannel = NotificationChannel(
                CHANNEL_MONITOR_ID,
                "Server Monitoring Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows the active status of background server power monitoring."
                setShowBadge(false)
            }

            // Channel 2: High priority alerts for state changes
            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS_ID,
                "Server Power Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Sends alerts when a server transitions between running, stopping, and offline."
                enableVibration(true)
                setShowBadge(true)
            }

            notificationManager.createNotificationChannel(monitorChannel)
            notificationManager.createNotificationChannel(alertsChannel)
        }
    }

    companion object {
        private const val TAG = "ServerMonitorService"
        const val CHANNEL_MONITOR_ID = "channel_server_monitor"
        const val CHANNEL_ALERTS_ID = "channel_server_alerts"
        const val NOTIFICATION_ID_FOREGROUND = 10001
        const val ACTION_START_SERVICE = "com.example.service.ACTION_START_MONITOR"
        const val ACTION_STOP_SERVICE = "com.example.service.ACTION_STOP_MONITOR"
        private const val POLL_INTERVAL_MS = 10_000L

        fun startService(context: Context) {
            val intent = Intent(context, ServerStateMonitorService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, ServerStateMonitorService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
