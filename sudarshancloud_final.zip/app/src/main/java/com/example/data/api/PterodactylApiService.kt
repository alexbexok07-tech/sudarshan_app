package com.example.data.api

import com.example.data.model.ConsoleCommandRequest
import com.example.data.model.CreateBackupRequest
import com.example.data.model.CreateFolderRequest
import com.example.data.model.DeleteFilesRequest
import com.example.data.model.PowerSignalRequest
import com.example.data.model.PteroAccountResponse
import com.example.data.model.PteroBackupItem
import com.example.data.model.PteroBackupListResponse
import com.example.data.model.PteroDatabaseListResponse
import com.example.data.model.PteroFileListResponse
import com.example.data.model.PteroServerItem
import com.example.data.model.PteroServerListResponse
import com.example.data.model.PteroStatsResponse
import com.example.data.model.PteroWebsocketResponse
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

typealias PterodactylApiService = PterodactylApi

