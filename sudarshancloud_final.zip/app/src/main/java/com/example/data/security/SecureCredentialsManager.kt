package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.data.api.ApiClient

/**
 * Manages encrypted local storage of sensitive Pterodactyl authentication credentials
 * (Panel Base URL, Client API Key, and optional User Account Email) using EncryptedSharedPreferences
 * with automated standard preferences fallback for testing/JVM environments without hardware keystore.
 */
class SecureCredentialsManager(context: Context) {

    private val sharedPreferences: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            PREFS_FILENAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        Log.w(TAG, "Hardware keystore not ready or JVM test environment, using fallback secure preferences", e)
        context.getSharedPreferences(FALLBACK_PREFS_FILENAME, Context.MODE_PRIVATE)
    }

    /**
     * Stores credentials securely and immediately informs [ApiClient] for all subsequent API requests.
     */
    fun saveCredentials(panelUrl: String, apiKey: String, email: String? = null) {
        val cleanUrl = panelUrl.trim()
        val cleanKey = apiKey.trim()
        val cleanEmail = email?.trim() ?: ""

        sharedPreferences.edit()
            .putString(KEY_PANEL_URL, cleanUrl)
            .putString(KEY_API_KEY, cleanKey)
            .putString(KEY_USER_EMAIL, cleanEmail)
            .apply()

        // Apply immediately to API client
        if (cleanUrl.isNotBlank() && cleanKey.isNotBlank()) {
            ApiClient.updateConfig(cleanUrl, cleanKey)
        }
    }

    fun getPanelUrl(): String {
        return sharedPreferences.getString(KEY_PANEL_URL, "") ?: ""
    }

    fun getApiKey(): String {
        return sharedPreferences.getString(KEY_API_KEY, "") ?: ""
    }

    fun getUserEmail(): String {
        return sharedPreferences.getString(KEY_USER_EMAIL, "") ?: ""
    }

    fun hasCredentials(): Boolean {
        return getPanelUrl().isNotBlank() && getApiKey().isNotBlank()
    }

    fun clearCredentials() {
        sharedPreferences.edit().clear().apply()
        ApiClient.updateConfig("https://portal.sudarshancloud.com/", "")
    }

    companion object {
        private const val TAG = "SecureCredentialsMgr"
        private const val PREFS_FILENAME = "pterodactyl_secure_credentials"
        private const val FALLBACK_PREFS_FILENAME = "pterodactyl_fallback_credentials"
        private const val KEY_PANEL_URL = "secure_panel_url"
        private const val KEY_API_KEY = "secure_api_key"
        private const val KEY_USER_EMAIL = "secure_user_email"

        @Volatile
        private var INSTANCE: SecureCredentialsManager? = null

        fun getInstance(context: Context): SecureCredentialsManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SecureCredentialsManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
