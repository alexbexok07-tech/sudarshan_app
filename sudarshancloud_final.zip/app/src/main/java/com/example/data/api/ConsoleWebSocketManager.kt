package com.example.data.api

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class ConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    AUTHENTICATED,
    ERROR
}

data class ConsoleLogEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val rawText: String,
    val timestamp: String = "",
    val level: LogLevel = LogLevel.INFO,
    val source: String = "Server"
)

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    SYSTEM,
    COMMAND
}

class ConsoleWebSocketManager(
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // keep-alive for websocket
        .build()
) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private var activeWebSocket: WebSocket? = null
    private var currentToken: String = ""

    private val _connectionStatus = MutableStateFlow(ConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _logsFlow = MutableSharedFlow<ConsoleLogEntry>(replay = 100)
    val logsFlow: SharedFlow<ConsoleLogEntry> = _logsFlow.asSharedFlow()

    private val _statsJsonFlow = MutableSharedFlow<String>(replay = 1)
    val statsJsonFlow: SharedFlow<String> = _statsJsonFlow.asSharedFlow()

    private val _serverStateFlow = MutableStateFlow<String?>("offline")
    val serverStateFlow: StateFlow<String?> = _serverStateFlow.asStateFlow()

    fun connect(socketUrl: String, token: String) {
        disconnect()

        currentToken = token
        _connectionStatus.value = ConnectionStatus.CONNECTING

        val request = Request.Builder()
            .url(socketUrl)
            .header("Origin", ApiClient.getBaseUrl())
            .build()

        activeWebSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _connectionStatus.value = ConnectionStatus.CONNECTED
                // Send authentication payload immediately
                val authPayload = JSONObject().apply {
                    put("event", "auth")
                    put("args", JSONArray().put(token))
                }
                webSocket.send(authPayload.toString())
                
                // Request back logs
                val logsRequest = JSONObject().apply {
                    put("event", "send logs")
                    put("args", JSONArray())
                }
                webSocket.send(logsRequest.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleIncomingMessage(webSocket, text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
                _connectionStatus.value = ConnectionStatus.DISCONNECTED
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e("ConsoleWebSocket", "WebSocket failure: ${t.message}", t)
                _connectionStatus.value = ConnectionStatus.ERROR
                scope.launch {
                    _logsFlow.emit(
                        ConsoleLogEntry(
                            rawText = "[System] Live socket disconnected: ${t.localizedMessage ?: "Connection error"}. Using API telemetry fallback.",
                            level = LogLevel.WARN,
                            source = "Client"
                        )
                    )
                }
            }
        })
    }

    private fun handleIncomingMessage(webSocket: WebSocket, message: String) {
        try {
            val json = JSONObject(message)
            val event = json.optString("event")
            val args = json.optJSONArray("args")

            when (event) {
                "auth success" -> {
                    _connectionStatus.value = ConnectionStatus.AUTHENTICATED
                    scope.launch {
                        _logsFlow.emit(
                            ConsoleLogEntry(
                                rawText = "[System] Successfully authenticated with SudarshanCloud daemon.",
                                level = LogLevel.SYSTEM,
                                source = "Daemon"
                            )
                        )
                    }
                }
                "status" -> {
                    val status = args?.optString(0) ?: "offline"
                    _serverStateFlow.value = status
                }
                "console output" -> {
                    val line = args?.optString(0) ?: ""
                    if (line.isNotBlank()) {
                        val parsed = parseLogLine(line)
                        scope.launch { _logsFlow.emit(parsed) }
                    }
                }
                "stats" -> {
                    val statsJson = args?.optString(0)
                    if (!statsJson.isNullOrBlank()) {
                        scope.launch { _statsJsonFlow.emit(statsJson) }
                    }
                }
                "token expiring" -> {
                    // Daemon indicates token will expire soon
                    Log.d("ConsoleWebSocket", "Token expiring soon")
                }
                "token expired" -> {
                    _connectionStatus.value = ConnectionStatus.DISCONNECTED
                }
            }
        } catch (e: Exception) {
            Log.e("ConsoleWebSocket", "Error parsing incoming ws packet", e)
        }
    }

    fun sendConsoleCommand(command: String): Boolean {
        val ws = activeWebSocket ?: return false
        val payload = JSONObject().apply {
            put("event", "send command")
            put("args", JSONArray().put(command))
        }
        return ws.send(payload.toString())
    }

    fun sendPowerSignal(signal: String): Boolean {
        val ws = activeWebSocket ?: return false
        val payload = JSONObject().apply {
            put("event", "set state")
            put("args", JSONArray().put(signal))
        }
        return ws.send(payload.toString())
    }

    fun disconnect() {
        try {
            activeWebSocket?.close(1000, "User switched server or exited")
        } catch (_: Exception) {}
        activeWebSocket = null
        _connectionStatus.value = ConnectionStatus.DISCONNECTED
    }

    fun appendLocalLog(entry: ConsoleLogEntry) {
        scope.launch {
            _logsFlow.emit(entry)
        }
    }

    private fun parseLogLine(line: String): ConsoleLogEntry {
        val cleanLine = line.replace(Regex("\u001B\\[[;\\d]*m"), "") // strip ANSI colors if present
        val level = when {
            cleanLine.contains("WARN", ignoreCase = true) || cleanLine.contains("WARNING", ignoreCase = true) -> LogLevel.WARN
            cleanLine.contains("ERROR", ignoreCase = true) || cleanLine.contains("FATAL", ignoreCase = true) || cleanLine.contains("Exception") -> LogLevel.ERROR
            cleanLine.startsWith(">") || cleanLine.contains("issued server command") -> LogLevel.COMMAND
            cleanLine.contains("INFO", ignoreCase = true) -> LogLevel.INFO
            else -> LogLevel.INFO
        }

        // extract timestamp like [17:17:22]
        val timeMatch = Regex("\\[(\\d{2}:\\d{2}:\\d{2})\\]").find(cleanLine)
        val timestamp = timeMatch?.groupValues?.getOrNull(1) ?: ""

        return ConsoleLogEntry(
            rawText = cleanLine,
            timestamp = timestamp,
            level = level
        )
    }
}
