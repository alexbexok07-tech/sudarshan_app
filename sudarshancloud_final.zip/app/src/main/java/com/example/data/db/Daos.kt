package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PanelConfigDao {
    @Query("SELECT * FROM panel_config WHERE id = 1 LIMIT 1")
    fun getConfigFlow(): Flow<PanelConfigEntity?>

    @Query("SELECT * FROM panel_config WHERE id = 1 LIMIT 1")
    suspend fun getConfig(): PanelConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveConfig(config: PanelConfigEntity)
}

@Dao
interface ServerFolderDao {
    @Query("SELECT * FROM server_folders ORDER BY id ASC")
    fun getAllFoldersFlow(): Flow<List<ServerFolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: ServerFolderEntity): Long

    @Query("DELETE FROM server_folders WHERE id = :id")
    suspend fun deleteFolder(id: Long)
}

@Dao
interface CachedServerDao {
    @Query("SELECT * FROM cached_servers ORDER BY name ASC")
    fun getAllCachedServersFlow(): Flow<List<CachedServerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateServers(servers: List<CachedServerEntity>)

    @Query("DELETE FROM cached_servers")
    suspend fun clearServers()

    @Query("SELECT * FROM cached_servers WHERE identifier = :identifier LIMIT 1")
    suspend fun getServer(identifier: String): CachedServerEntity?
}

@Dao
interface CommandHistoryDao {
    @Query("SELECT * FROM command_history WHERE serverIdentifier = :serverIdentifier ORDER BY timestamp DESC LIMIT 30")
    fun getRecentCommands(serverIdentifier: String): Flow<List<CommandHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommand(entry: CommandHistoryEntity)

    @Query("DELETE FROM command_history WHERE serverIdentifier = :serverIdentifier")
    suspend fun clearHistory(serverIdentifier: String)
}
