package com.example.data.api

import com.example.data.model.ConsoleCommandRequest
import com.example.data.model.CreateBackupRequest
import com.example.data.model.CreateFolderRequest
import com.example.data.model.DeleteFilesRequest
import com.example.data.model.PowerSignalRequest
import com.example.data.model.PteroAccountResponse
import com.example.data.model.PteroBackupItem
import com.example.data.model.PteroBackupListResponse
import com.example.data.model.PteroDatabaseListResponse
import com.example.data.model.PteroFileListResponse
import com.example.data.model.PteroServerItem
import com.example.data.model.PteroServerListResponse
import com.example.data.model.PteroStatsResponse
import com.example.data.model.PteroWebsocketResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.ResponseBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

/**
 * Retrofit API interface for interacting with the Pterodactyl Panel API at portal.sudarshancloud.com.
 *
 * Supports header-based API key authentication via Bearer token:
 * "Authorization: Bearer <API_KEY>"
 */
interface PterodactylApi {

    // ==========================================
    // ACCOUNT
    // ==========================================

    @Headers("Accept: application/json")
    @GET("api/client/account")
    suspend fun getAccount(
        @Header("Authorization") authHeader: String? = null
    ): PteroAccountResponse

    // ==========================================
    // SERVERS
    // ==========================================

    @Headers("Accept: application/json")
    @GET("api/client")
    suspend fun getServers(
        @Header("Authorization") authHeader: String? = null
    ): PteroServerListResponse

    @Headers("Accept: application/json")
    @GET("api/client/servers/{server}")
    suspend fun getServerDetails(
        @Path("server") serverId: String,
        @Header("Authorization") authHeader: String? = null
    ): PteroServerItem

    // ==========================================
    // REAL-TIME RESOURCE UTILIZATION & TELEMETRY
    // ==========================================

    @Headers("Accept: application/json")
    @GET("api/client/servers/{server}/resources")
    suspend fun getServerResources(
        @Path("server") serverId: String,
        @Header("Authorization") authHeader: String? = null
    ): PteroStatsResponse

    // ==========================================
    // REMOTE CONSOLE & POWER CONTROL
    // ==========================================

    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/power")
    suspend fun sendPowerSignal(
        @Path("server") serverId: String,
        @Body signal: PowerSignalRequest,
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    /**
     * Sends the 'start' power signal to the specified server.
     */
    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/power")
    suspend fun startServer(
        @Path("server") serverId: String,
        @Body signal: PowerSignalRequest = PowerSignalRequest(signal = "start"),
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    /**
     * Sends the 'stop' power signal (graceful shutdown) to the specified server.
     */
    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/power")
    suspend fun stopServer(
        @Path("server") serverId: String,
        @Body signal: PowerSignalRequest = PowerSignalRequest(signal = "stop"),
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    /**
     * Sends the 'restart' power signal to the specified server.
     */
    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/power")
    suspend fun restartServer(
        @Path("server") serverId: String,
        @Body signal: PowerSignalRequest = PowerSignalRequest(signal = "restart"),
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    /**
     * Sends the 'kill' power signal (forced immediate termination) to the specified server.
     */
    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/power")
    suspend fun killServer(
        @Path("server") serverId: String,
        @Body signal: PowerSignalRequest = PowerSignalRequest(signal = "kill"),
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/command")
    suspend fun sendConsoleCommand(
        @Path("server") serverId: String,
        @Body command: ConsoleCommandRequest,
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    @Headers("Accept: application/json")
    @GET("api/client/servers/{server}/websocket")
    suspend fun getWebsocketCredentials(
        @Path("server") serverId: String,
        @Header("Authorization") authHeader: String? = null
    ): PteroWebsocketResponse

    // ==========================================
    // FILE MANAGEMENT
    // ==========================================

    @Headers("Accept: application/json")
    @GET("api/client/servers/{server}/files/list")
    suspend fun listFiles(
        @Path("server") serverId: String,
        @Query("directory") directory: String = "/",
        @Header("Authorization") authHeader: String? = null
    ): PteroFileListResponse

    @GET("api/client/servers/{server}/files/contents")
    suspend fun getFileContents(
        @Path("server") serverId: String,
        @Query("file") filePath: String,
        @Header("Authorization") authHeader: String? = null
    ): ResponseBody

    @POST("api/client/servers/{server}/files/write")
    suspend fun writeFileContents(
        @Path("server") serverId: String,
        @Query("file") filePath: String,
        @Body content: RequestBody,
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/files/create-folder")
    suspend fun createFolder(
        @Path("server") serverId: String,
        @Body body: CreateFolderRequest,
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/files/delete")
    suspend fun deleteFiles(
        @Path("server") serverId: String,
        @Body body: DeleteFilesRequest,
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    // ==========================================
    // BACKUPS
    // ==========================================

    @Headers("Accept: application/json")
    @GET("api/client/servers/{server}/backups")
    suspend fun listBackups(
        @Path("server") serverId: String,
        @Header("Authorization") authHeader: String? = null
    ): PteroBackupListResponse

    @Headers("Accept: application/json", "Content-Type: application/json")
    @POST("api/client/servers/{server}/backups")
    suspend fun createBackup(
        @Path("server") serverId: String,
        @Body body: CreateBackupRequest,
        @Header("Authorization") authHeader: String? = null
    ): PteroBackupItem

    @Headers("Accept: application/json")
    @DELETE("api/client/servers/{server}/backups/{backup}")
    suspend fun deleteBackup(
        @Path("server") serverId: String,
        @Path("backup") backupUuid: String,
        @Header("Authorization") authHeader: String? = null
    ): Response<Unit>

    // ==========================================
    // DATABASES
    // ==========================================

    @Headers("Accept: application/json")
    @GET("api/client/servers/{server}/databases")
    suspend fun listDatabases(
        @Path("server") serverId: String,
        @Header("Authorization") authHeader: String? = null
    ): PteroDatabaseListResponse

    companion object {
        const val DEFAULT_BASE_URL = "https://portal.sudarshancloud.com/"

        /**
         * Creates an authenticated [PterodactylApi] Retrofit instance for SudarshanCloud.
         *
         * Automatically sets:
         * - 'Authorization: Bearer <apiKey>' header
         * - 'Accept: application/json' header
         * - 'User-Agent'
         * - Moshi JSON serialization
         *
         * @param apiKey The Pterodactyl client API key (e.g. ptlc_...)
         * @param baseUrl Defaults to https://portal.sudarshancloud.com/
         */
        fun create(
            apiKey: String,
            baseUrl: String = DEFAULT_BASE_URL
        ): PterodactylApi {
            val normalizedBaseUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

            val authInterceptor = Interceptor { chain ->
                val original = chain.request()
                val requestBuilder = original.newBuilder()
                    .header("Accept", "application/json")
                    .header("User-Agent", "SudarshanCloud-Android/1.0")

                // Add Authorization header if not already present on the request
                if (original.header("Authorization") == null && apiKey.isNotBlank()) {
                    val token = if (apiKey.startsWith("Bearer ", ignoreCase = true)) {
                        apiKey
                    } else {
                        "Bearer $apiKey"
                    }
                    requestBuilder.header("Authorization", token)
                }

                chain.proceed(requestBuilder.build())
            }

            val loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.HEADERS
            }

            val okHttpClient = OkHttpClient.Builder()
                .addInterceptor(authInterceptor)
                .addInterceptor(loggingInterceptor)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .build()

            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(normalizedBaseUrl)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(PterodactylApi::class.java)
        }
    }
}
