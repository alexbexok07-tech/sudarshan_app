package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Pterodactyl API Server model.
 *
 * In the Pterodactyl Client & Application API, servers are represented with an outer
 * wrapper structure or flattened domain model. This data class supports direct parsing
 * of the server object as well as convenient access to ID, name, status, and node details.
 */
@JsonClass(generateAdapter = true)
data class Server(
    @Json(name = "identifier")
    val id: String,

    @Json(name = "uuid")
    val uuid: String? = null,

    @Json(name = "name")
    val name: String,

    @Json(name = "node")
    val node: String = "in-01",

    @Json(name = "node_details")
    val nodeDetails: NodeDetails? = null,

    @Json(name = "status")
    val status: String? = "online",

    @Json(name = "is_suspended")
    val isSuspended: Boolean = false,

    @Json(name = "is_installing")
    val isInstalling: Boolean = false,

    @Json(name = "description")
    val description: String? = null,

    @Json(name = "limits")
    val limits: ServerLimits? = null,

    @Json(name = "allocations")
    val allocations: List<ServerAllocation> = emptyList(),

    @Json(name = "relationships")
    val relationships: PteroRelationships? = null
) {
    /**
     * Resolves the effective status of the server (e.g. "online", "suspended", "installing", "offline").
     */
    val effectiveStatus: String
        get() = when {
            isSuspended -> "suspended"
            isInstalling -> "installing"
            !status.isNullOrBlank() -> status
            else -> "online"
        }

    /**
     * Node name/identifier accessor.
     */
    val nodeName: String
        get() = nodeDetails?.name ?: node

    /**
     * Primary IP address formatted with port (e.g. in-01.sudarshancloud.com:25568).
     */
    val primaryAddress: String
        get() {
            val defaultAlloc = relationships?.allocations?.data?.firstOrNull { it.attributes.isDefault }?.attributes
                ?: relationships?.allocations?.data?.firstOrNull()?.attributes
            return if (defaultAlloc != null) {
                "${defaultAlloc.ipAlias ?: defaultAlloc.ip}:${defaultAlloc.port}"
            } else if (allocations.isNotEmpty()) {
                val alloc = allocations.firstOrNull { it.isDefault } ?: allocations.first()
                "${alloc.ipAlias ?: alloc.ip}:${alloc.port}"
            } else {
                "${nodeName}.sudarshancloud.com:25565"
            }
        }
}

/**
 * Details of the physical/virtual node hosting the server.
 */
@JsonClass(generateAdapter = true)
data class NodeDetails(
    @Json(name = "id")
    val id: Int = 1,

    @Json(name = "name")
    val name: String = "in-01",

    @Json(name = "fqdn")
    val fqdn: String = "in-01.sudarshancloud.com",

    @Json(name = "scheme")
    val scheme: String = "https",

    @Json(name = "daemon_listen")
    val daemonPort: Int = 8080,

    @Json(name = "daemon_sftp")
    val sftpPort: Int = 2022,

    @Json(name = "location_id")
    val locationId: Int = 1,

    @Json(name = "maintenance_mode")
    val isMaintenanceMode: Boolean = false
)

/**
 * Resource limits configured on the Pterodactyl node for the server.
 */
@JsonClass(generateAdapter = true)
data class ServerLimits(
    @Json(name = "memory")
    val memoryMb: Long = 0, // In megabytes (0 = unlimited)

    @Json(name = "swap")
    val swapMb: Long = 0,

    @Json(name = "disk")
    val diskMb: Long = 0, // In megabytes (0 = unlimited)

    @Json(name = "io")
    val io: Long = 500,

    @Json(name = "cpu")
    val cpuLimit: Double = 0.0 // 0 = unlimited, 100 = 100% of single core
)

/**
 * IP and port allocation assigned to the server.
 */
@JsonClass(generateAdapter = true)
data class ServerAllocation(
    @Json(name = "id")
    val id: Int = 0,

    @Json(name = "ip")
    val ip: String = "",

    @Json(name = "ip_alias")
    val ipAlias: String? = null,

    @Json(name = "port")
    val port: Int = 25565,

    @Json(name = "is_default")
    val isDefault: Boolean = false
)

/**
 * Extension mapper from API PteroServerAttributes to the domain Server model.
 */
fun PteroServerAttributes.toServer(): Server {
    return Server(
        id = identifier,
        uuid = uuid,
        name = name,
        node = node ?: "in-01",
        nodeDetails = NodeDetails(
            name = node ?: "in-01",
            fqdn = "${node ?: "in-01"}.sudarshancloud.com"
        ),
        status = status,
        isSuspended = isSuspended,
        isInstalling = isInstalling,
        description = description,
        limits = ServerLimits(
            memoryMb = limits.memory,
            swapMb = limits.swap,
            diskMb = limits.disk,
            io = limits.io,
            cpuLimit = limits.cpu
        ),
        relationships = relationships
    )
}
