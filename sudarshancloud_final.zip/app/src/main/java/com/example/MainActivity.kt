package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppDrawer
import com.example.ui.components.NavDestination
import com.example.ui.screens.AuthenticationScreen
import com.example.ui.screens.BackupManagerScreen
import com.example.ui.screens.BackupsDatabasesScreen
import com.example.ui.screens.ConsoleScreen
import com.example.ui.screens.FileManagerScreen
import com.example.ui.screens.ServerDetailScreen
import com.example.ui.screens.ServersScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SudarshanCloudApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SudarshanCloudApp(viewModel: MainViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentDestination by viewModel.currentDestination.collectAsStateWithLifecycle()
    val selectedServer by viewModel.selectedServer.collectAsStateWithLifecycle()
    val servers by viewModel.serversState.collectAsStateWithLifecycle()
    val folders by viewModel.foldersState.collectAsStateWithLifecycle()
    val selectedFolder by viewModel.selectedFolder.collectAsStateWithLifecycle()
    val realtimeStats by viewModel.realtimeStats.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.userFeedback.collectAsStateWithLifecycle()
    val consoleLogs by viewModel.consoleLogs.collectAsStateWithLifecycle()
    val config by viewModel.configState.collectAsStateWithLifecycle()

    val currentDir by viewModel.currentDirectory.collectAsStateWithLifecycle()
    val filesList by viewModel.filesList.collectAsStateWithLifecycle()
    val isLoadingFiles by viewModel.isLoadingFiles.collectAsStateWithLifecycle()
    val editorState by viewModel.fileEditorState.collectAsStateWithLifecycle()
    val backups by viewModel.backupsList.collectAsStateWithLifecycle()
    val databases by viewModel.databasesList.collectAsStateWithLifecycle()

    // Request notification permission on Android 13+ (TIRAMISU)
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Handle feedback snackbar
    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    // Hardware Back Handling
    BackHandler(enabled = drawerState.isOpen || currentDestination != NavDestination.SERVERS) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (editorState != null) {
            viewModel.closeFileEditor()
        } else {
            viewModel.selectDestination(NavDestination.SERVERS)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFF161E2D),
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            ) {
                AppDrawer(
                    currentDestination = currentDestination,
                    selectedServerName = selectedServer?.name,
                    userEmail = config?.userEmail ?: "shreela75@gmail.com",
                    onNavigate = { dest ->
                        viewModel.selectDestination(dest)
                        scope.launch { drawerState.close() }
                    },
                    onCloseDrawer = {
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { viewModel.selectDestination(NavDestination.SERVERS) }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.sudarshan_app_icon_1790443425621),
                                contentDescription = "Logo",
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Sudarshan Cloud",
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("drawer_menu_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open Navigation Menu",
                                tint = TextPrimary
                            )
                        }
                    },
                    actions = {
                        if (isRefreshing) {
                            CircularProgressIndicator(
                                modifier = Modifier
                                    .padding(horizontal = 12.dp)
                                    .size(20.dp),
                                color = Color(0xFFEAB308),
                                strokeWidth = 2.dp
                            )
                        } else {
                            IconButton(
                                onClick = { viewModel.refreshAll() },
                                modifier = Modifier.testTag("refresh_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Sync Panel",
                                    tint = TextPrimary
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.selectDestination(NavDestination.SETTINGS) },
                            modifier = Modifier.testTag("top_settings_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = if (currentDestination == NavDestination.SETTINGS) Color(0xFFEAB308) else TextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkBackground,
                        titleContentColor = TextPrimary
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    contentColor = TextPrimary
                ) {
                    NavigationBarItem(
                        selected = currentDestination == NavDestination.SERVERS,
                        onClick = { viewModel.selectDestination(NavDestination.SERVERS) },
                        icon = { Icon(Icons.Default.Dns, contentDescription = "Servers") },
                        label = { Text("Servers", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFEAB308),
                            selectedTextColor = Color(0xFFEAB308),
                            indicatorColor = DarkSurfaceElevated,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )

                    NavigationBarItem(
                        selected = currentDestination == NavDestination.CONSOLE,
                        onClick = { viewModel.selectDestination(NavDestination.CONSOLE) },
                        icon = { Icon(Icons.Default.Terminal, contentDescription = "Console") },
                        label = { Text("Console", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF38BDF8),
                            selectedTextColor = Color(0xFF38BDF8),
                            indicatorColor = DarkSurfaceElevated,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )

                    NavigationBarItem(
                        selected = currentDestination == NavDestination.FILES,
                        onClick = { viewModel.selectDestination(NavDestination.FILES) },
                        icon = { Icon(Icons.Default.Folder, contentDescription = "Files") },
                        label = { Text("Files", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF10B981),
                            selectedTextColor = Color(0xFF10B981),
                            indicatorColor = DarkSurfaceElevated,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )

                    NavigationBarItem(
                        selected = currentDestination == NavDestination.SETTINGS || currentDestination == NavDestination.ACCOUNT,
                        onClick = { viewModel.selectDestination(NavDestination.SETTINGS) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFEAB308),
                            selectedTextColor = Color(0xFFEAB308),
                            indicatorColor = DarkSurfaceElevated,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = DarkBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentDestination, label = "screen_transition") { dest ->
                    when (dest) {
                        NavDestination.SERVERS -> {
                            ServersScreen(
                                servers = servers,
                                folders = folders,
                                selectedFolder = selectedFolder,
                                realtimeStats = realtimeStats,
                                searchQuery = searchQuery,
                                onSearchQueryChange = viewModel::setSearchQuery,
                                onSelectFolder = viewModel::setFolder,
                                onCreateFolder = viewModel::createServerFolder,
                                onManageServer = { server ->
                                    viewModel.selectServer(server)
                                    viewModel.selectDestination(NavDestination.DASHBOARD)
                                },
                                onPowerAction = viewModel::sendPowerAction
                            )
                        }

                        NavDestination.CONSOLE -> {
                            ConsoleScreen(
                                server = selectedServer,
                                stats = selectedServer?.let { realtimeStats[it.identifier] },
                                logs = consoleLogs,
                                onSendCommand = viewModel::sendConsoleCommand,
                                onClearLogs = viewModel::clearConsoleLogs,
                                onPowerAction = { signal ->
                                    selectedServer?.let { viewModel.sendPowerAction(it.identifier, signal) }
                                }
                            )
                        }

                        NavDestination.DASHBOARD -> {
                            ServerDetailScreen(
                                server = selectedServer,
                                stats = selectedServer?.let { realtimeStats[it.identifier] },
                                onPowerAction = { signal ->
                                    selectedServer?.let { viewModel.sendPowerAction(it.identifier, signal) }
                                },
                                onNavigate = viewModel::selectDestination
                            )
                        }

                        NavDestination.FILES -> {
                            FileManagerScreen(
                                server = selectedServer,
                                currentDirectory = currentDir,
                                files = filesList,
                                isLoading = isLoadingFiles,
                                fileEditorState = editorState,
                                onNavigateDirectory = { dir ->
                                    selectedServer?.let { viewModel.loadFiles(it.identifier, dir) }
                                },
                                onOpenFile = viewModel::openFile,
                                onUpdateEditorContent = viewModel::updateEditorContent,
                                onSaveEditorContent = viewModel::saveFileEditorContent,
                                onCloseEditor = viewModel::closeFileEditor,
                                onCreateFolder = viewModel::createFolder,
                                onDeleteFile = viewModel::deleteFile
                            )
                        }

                        NavDestination.BACKUPS -> {
                            BackupManagerScreen(
                                server = selectedServer,
                                backups = backups,
                                onCreateBackup = viewModel::createBackup
                            )
                        }

                        NavDestination.DATABASES -> {
                            BackupsDatabasesScreen(
                                server = selectedServer,
                                backups = backups,
                                databases = databases,
                                onCreateBackup = viewModel::createBackup
                            )
                        }

                        NavDestination.AUTHENTICATION -> {
                            AuthenticationScreen(
                                viewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
                                onAuthenticationSuccess = {
                                    viewModel.refreshAll()
                                    viewModel.selectDestination(NavDestination.SERVERS)
                                }
                            )
                        }

                        NavDestination.SETTINGS, NavDestination.ACCOUNT, NavDestination.ACTIVITY,
                        NavDestination.NETWORK, NavDestination.SCHEDULES, NavDestination.USERS, NavDestination.STARTUP -> {
                            SettingsScreen(
                                config = config,
                                onSaveConfig = viewModel::saveApiConfig,
                                onTestConnection = viewModel::refreshAll
                            )
                        }
                    }
                }
            }
        }
    }
}
