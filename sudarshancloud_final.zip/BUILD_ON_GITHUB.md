# Build SudarshanCloud on GitHub Actions

1. Upload this ZIP to your GitHub repository.
2. Put `.github/workflows/build-apk.yml` in the repository (not inside this ZIP only).
3. Open **Actions** and run **Build SudarshanCloud APK**.
4. When it succeeds, open the run and download the **SudarshanCloud-debug-APK** artifact.

The workflow intentionally uses `android-actions/setup-android@v4` with only `platform-tools`. The old `tools` SDK package is no longer served by Google and causes setup-android v3 to fail. The workflow then installs Android API 36 and Build Tools 36.0.0 explicitly.
