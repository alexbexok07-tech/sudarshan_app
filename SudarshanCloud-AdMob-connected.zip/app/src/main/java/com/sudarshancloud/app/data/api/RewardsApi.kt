package com.sudarshancloud.app.data.api

import com.sudarshancloud.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** API client for the companion Rewards service. Never put an admin key in the Android app. */
object RewardsApi {
    private val baseUrl: String = BuildConfig.REWARDS_API_BASE_URL.trim().trimEnd('/')
    val isConfigured: Boolean
        get() = baseUrl.startsWith("https://") && !baseUrl.contains("YOUR-REWARDS-SERVICE", ignoreCase = true)

    data class Stats(
        val verifiedToday: Int,
        val availableToday: Int,
        val dailyLimit: Int
    )

    data class Claim(val url: String, val verifiedAds: Int, val status: String)

    suspend fun createAdSession(userId: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("user_id", userId)
        val json = request("POST", "/api/ad-session", body)
        json.getString("custom_data")
    }

    suspend fun getStats(userId: String): Stats = withContext(Dispatchers.IO) {
        val json = request("GET", "/api/stats?user_id=${encode(userId)}", null)
        Stats(
            verifiedToday = json.optInt("verified_today", 0),
            availableToday = json.optInt("available_today", 0),
            dailyLimit = json.optInt("daily_limit", 10)
        )
    }

    suspend fun createClaim(userId: String, offerId: String): Claim = withContext(Dispatchers.IO) {
        val body = JSONObject().put("user_id", userId).put("offer_id", offerId)
        val json = request("POST", "/api/claims", body)
        Claim(json.getString("claim_url"), json.optInt("verified_ads", 0), json.optString("status", "pending"))
    }

    private fun encode(value: String): String = java.net.URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun request(method: String, path: String, body: JSONObject?): JSONObject {
        check(isConfigured) { "Rewards verification service is not configured yet." }
        val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 9000
            readTimeout = 9000
            setRequestProperty("Accept", "application/json")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(response) } catch (_: Exception) {
                JSONObject().put("detail", "Rewards service returned an invalid response (HTTP $status).")
            }
            if (status !in 200..299) throw IllegalStateException(json.optString("detail", "Rewards service request failed (HTTP $status)."))
            return json
        } finally {
            connection.disconnect()
        }
    }
}
