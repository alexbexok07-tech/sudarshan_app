import base64
import json
import os
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from contextlib import contextmanager
from typing import Iterator
from html import escape
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs
from zoneinfo import ZoneInfo

import httpx
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

APP_NAME = "SudarshanCloud Rewards API"
DATA_DIR = Path(os.getenv("DATA_DIR", "./data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "rewards.sqlite3"
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/")
ADMIN_API_KEY = os.getenv("ADMIN_API_KEY", "")
ALLOWED_AD_UNIT = os.getenv("ADMOB_REWARDED_AD_UNIT_ID", "").strip()
TIME_ZONE_NAME = os.getenv("REWARD_TIME_ZONE", "Asia/Kolkata")
DAILY_LIMIT = max(1, min(int(os.getenv("DAILY_AD_LIMIT", "10")), 20))
SSV_KEYS_URL = "https://www.gstatic.com/admob/reward/verifier-keys.json"
OFFERS = {
    "ram1_3d": {"title": "Starter Boost", "ram": "1 GB RAM", "days": 3, "ads": 3, "description": "A small temporary server trial."},
    "ram2_3d": {"title": "Survival Trial", "ram": "2 GB RAM", "days": 3, "ads": 5, "description": "A temporary trial for a small SMP."},
    "ram4_3d": {"title": "Community Trial", "ram": "4 GB RAM", "days": 3, "ads": 8, "description": "A temporary trial for a growing world."},
    "ram4_7d": {"title": "Weekender", "ram": "4 GB RAM", "days": 7, "ads": 10, "description": "A longer temporary hosting trial."},
}

app = FastAPI(title=APP_NAME, docs_url="/api/docs", redoc_url=None)
_key_cache: dict = {"fetched_at": 0, "keys": {}}


def now_local() -> datetime:
    try:
        tz = ZoneInfo(TIME_ZONE_NAME)
    except Exception:
        tz = timezone.utc
    return datetime.now(tz)


@contextmanager
def connect_db() -> Iterator[sqlite3.Connection]:
    con = sqlite3.connect(DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def init_db() -> None:
    with connect_db() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS ad_sessions (
                token TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at TEXT NOT NULL,
                used INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS ad_events (
                transaction_id TEXT PRIMARY KEY, user_id TEXT NOT NULL,
                session_token TEXT NOT NULL UNIQUE, ad_unit TEXT NOT NULL,
                reward_amount INTEGER NOT NULL, reward_item TEXT NOT NULL,
                rewarded_at TEXT NOT NULL, reward_date TEXT NOT NULL,
                FOREIGN KEY(session_token) REFERENCES ad_sessions(token)
            );
            CREATE TABLE IF NOT EXISTS claims (
                token TEXT PRIMARY KEY, user_id TEXT NOT NULL, offer_id TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL,
                verified_ads INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS reserved_ads (
                transaction_id TEXT PRIMARY KEY, claim_token TEXT NOT NULL,
                FOREIGN KEY(transaction_id) REFERENCES ad_events(transaction_id),
                FOREIGN KEY(claim_token) REFERENCES claims(token)
            );
            CREATE INDEX IF NOT EXISTS idx_ad_events_user_date ON ad_events(user_id, reward_date);
            CREATE INDEX IF NOT EXISTS idx_ad_sessions_user ON ad_sessions(user_id, created_at);
            """
        )

@app.on_event("startup")
def startup() -> None:
    init_db()


class SessionRequest(BaseModel):
    user_id: str = Field(min_length=8, max_length=128)


class ClaimRequest(BaseModel):
    user_id: str = Field(min_length=8, max_length=128)
    offer_id: str = Field(min_length=1, max_length=64)


class StatusRequest(BaseModel):
    status: str


def count_events(con: sqlite3.Connection, user_id: str, available_only: bool) -> int:
    day = now_local().date().isoformat()
    join = "LEFT JOIN reserved_ads r ON r.transaction_id=e.transaction_id" if available_only else ""
    condition = " AND r.transaction_id IS NULL" if available_only else ""
    row = con.execute(
        f"SELECT COUNT(*) AS n FROM ad_events e {join} WHERE e.user_id=? AND e.reward_date=?{condition}",
        (user_id, day),
    ).fetchone()
    return int(row["n"])


@app.get("/")
def home():
    return {
        "service": APP_NAME,
        "health": "/health",
        "admob_ssv_callback": f"{PUBLIC_BASE_URL}/api/admob/ssv",
        "docs": "/api/docs",
        "note": "Configure the AdMob rewarded-ad SSV callback to the URL shown above before enabling claims.",
    }


@app.get("/health")
def health():
    return {"ok": True, "service": APP_NAME}


@app.post("/api/ad-session")
def create_ad_session(body: SessionRequest):
    token = secrets.token_urlsafe(32)
    created = datetime.now(timezone.utc).isoformat()
    with connect_db() as con:
        if count_events(con, body.user_id, False) >= DAILY_LIMIT:
            raise HTTPException(429, f"Daily limit of {DAILY_LIMIT} rewarded ads reached.")
        con.execute(
            "INSERT INTO ad_sessions(token,user_id,created_at,used) VALUES(?,?,?,0)",
            (token, body.user_id, created),
        )
    return {"custom_data": token, "expires_after_hours": 24}


@app.get("/api/stats")
def stats(user_id: str):
    if len(user_id) < 8 or len(user_id) > 128:
        raise HTTPException(400, "Invalid user_id.")
    with connect_db() as con:
        verified = count_events(con, user_id, False)
        available = count_events(con, user_id, True)
    return {"verified_today": verified, "available_today": available, "daily_limit": DAILY_LIMIT, "time_zone": TIME_ZONE_NAME}


async def get_verification_keys() -> dict:
    now = time.time()
    if _key_cache["keys"] and now - _key_cache["fetched_at"] < 3600:
        return _key_cache["keys"]
    async with httpx.AsyncClient(timeout=8) as client:
        response = await client.get(SSV_KEYS_URL)
        response.raise_for_status()
        payload = response.json()
    keys = {}
    for item in payload.get("keys", []):
        try:
            key = serialization.load_der_public_key(base64.b64decode(item["base64"]))
            if isinstance(key, ec.EllipticCurvePublicKey):
                keys[str(item["keyId"])] = key
        except Exception:
            continue
    if not keys:
        raise HTTPException(503, "Could not load AdMob SSV verification keys.")
    _key_cache.update({"fetched_at": now, "keys": keys})
    return keys


@app.get("/api/admob/ssv")
async def admob_ssv(request: Request):
    # Google requires the exact original query bytes and parameter order for signature verification.
    raw_query = request.scope.get("query_string", b"").decode("latin-1")
    sig_marker = "&signature="
    marker_pos = raw_query.find(sig_marker)
    if marker_pos < 0:
        raise HTTPException(400, "Missing signature parameter.")
    signed_payload = raw_query[:marker_pos].encode("utf-8")
    params = parse_qs(raw_query, keep_blank_values=True)
    signature_values = params.get("signature", [])
    key_values = params.get("key_id", [])
    if not signature_values or not key_values:
        raise HTTPException(400, "Missing signature or key_id.")
    try:
        signature = base64.urlsafe_b64decode(signature_values[0] + "=" * (-len(signature_values[0]) % 4))
        keys = await get_verification_keys()
        public_key = keys.get(key_values[0])
        if public_key is None:
            _key_cache["fetched_at"] = 0
            keys = await get_verification_keys()
            public_key = keys.get(key_values[0])
        if public_key is None:
            raise ValueError("Unknown AdMob signing key.")
        public_key.verify(signature, signed_payload, ec.ECDSA(hashes.SHA256()))
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(401, f"AdMob SSV signature was not verified: {type(exc).__name__}.")

    def param(name: str) -> str:
        return params.get(name, [""])[0]

    custom_data = param("custom_data")
    user_id = param("user_id")
    transaction_id = param("transaction_id")
    ad_unit = param("ad_unit")
    reward_item = param("reward_item")
    reward_amount_raw = param("reward_amount")
    try:
        reward_amount = int(reward_amount_raw)
    except (TypeError, ValueError):
        reward_amount = 0
    if not custom_data or not transaction_id or not ad_unit:
        raise HTTPException(400, "Missing required AdMob reward fields.")
    if ALLOWED_AD_UNIT:
        expected = ALLOWED_AD_UNIT.rsplit("/", 1)[-1]
        if ad_unit != expected and ad_unit != ALLOWED_AD_UNIT:
            raise HTTPException(403, "Reward callback is for an unexpected ad unit.")

    with connect_db() as con:
        session = con.execute("SELECT * FROM ad_sessions WHERE token=?", (custom_data,)).fetchone()
        if session is None:
            raise HTTPException(404, "No matching ad session was found.")
        if session["used"]:
            # Idempotently acknowledge a duplicate call only if its transaction was saved.
            exists = con.execute("SELECT 1 FROM ad_events WHERE transaction_id=?", (transaction_id,)).fetchone()
            if exists:
                return {"ok": True, "duplicate": True}
            raise HTTPException(409, "Ad session was already consumed.")
        session_time = datetime.fromisoformat(session["created_at"])
        if (datetime.now(timezone.utc) - session_time).total_seconds() > 24 * 3600:
            raise HTTPException(410, "Ad session expired.")
        if user_id != session["user_id"]:
            raise HTTPException(403, "Reward user does not match the ad session.")
        current_count = count_events(con, session["user_id"], False)
        if current_count >= DAILY_LIMIT:
            raise HTTPException(429, "Daily rewarded-ad limit reached.")
        reward_time = now_local()
        try:
            con.execute(
                "INSERT INTO ad_events(transaction_id,user_id,session_token,ad_unit,reward_amount,reward_item,rewarded_at,reward_date) VALUES(?,?,?,?,?,?,?,?)",
                (transaction_id, session["user_id"], custom_data, ad_unit, reward_amount, reward_item, reward_time.isoformat(), reward_time.date().isoformat()),
            )
        except sqlite3.IntegrityError:
            return {"ok": True, "duplicate": True}
        con.execute("UPDATE ad_sessions SET used=1 WHERE token=?", (custom_data,))
    return {"ok": True}


@app.post("/api/claims")
def create_claim(body: ClaimRequest):
    offer = OFFERS.get(body.offer_id)
    if offer is None:
        raise HTTPException(404, "Unknown offer.")
    token = secrets.token_urlsafe(32)
    created_at = now_local().isoformat()
    with connect_db() as con:
        events = con.execute(
            """SELECT e.transaction_id,e.rewarded_at FROM ad_events e
               LEFT JOIN reserved_ads r ON r.transaction_id=e.transaction_id
               WHERE e.user_id=? AND e.reward_date=? AND r.transaction_id IS NULL
               ORDER BY e.rewarded_at ASC LIMIT ?""",
            (body.user_id, now_local().date().isoformat(), offer["ads"]),
        ).fetchall()
        if len(events) < offer["ads"]:
            available = len(events)
            raise HTTPException(400, f"This offer needs {offer['ads']} server-verified, unused ads from today; only {available} are available. Refresh in a few moments if you just finished a video.")
        con.execute(
            "INSERT INTO claims(token,user_id,offer_id,status,created_at,verified_ads) VALUES(?,?,?,'pending',?,?)",
            (token, body.user_id, body.offer_id, created_at, len(events)),
        )
        con.executemany(
            "INSERT INTO reserved_ads(transaction_id,claim_token) VALUES(?,?)",
            [(row["transaction_id"], token) for row in events],
        )
    return {"claim_url": f"{PUBLIC_BASE_URL}/claim/{token}", "verified_ads": len(events), "status": "pending"}


@app.get("/claim/{token}", response_class=HTMLResponse)
def claim_page(token: str):
    with connect_db() as con:
        claim = con.execute("SELECT * FROM claims WHERE token=?", (token,)).fetchone()
        if claim is None:
            raise HTTPException(404, "This claim link is invalid or has expired.")
        offer = OFFERS.get(claim["offer_id"], {})
        proofs = con.execute(
            """SELECT e.transaction_id,e.rewarded_at,e.ad_unit,e.reward_item,e.reward_amount
               FROM reserved_ads r JOIN ad_events e ON e.transaction_id=r.transaction_id
               WHERE r.claim_token=? ORDER BY e.rewarded_at""",
            (token,),
        ).fetchall()
    proof_rows = "".join(
        f"<tr><td>{escape(row['transaction_id'][:12])}…</td><td>{escape(row['rewarded_at'])}</td><td>{escape(str(row['reward_amount']))} {escape(row['reward_item'])}</td></tr>"
        for row in proofs
    ) or "<tr><td colspan='3'>No proof records are available.</td></tr>"
    status = escape(claim["status"].replace("_", " ").title())
    ram = escape(offer.get("ram", "Hosting reward"))
    title = escape(offer.get("title", "SudarshanCloud Reward"))
    desc = escape(offer.get("description", "Temporary hosting offer"))
    days = int(offer.get("days", 0))
    ads = int(claim["verified_ads"])
    made = escape(claim["created_at"])
    discord = "https://discord.gg/3bHSDR524H"
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SudarshanCloud reward claim</title>
<style>*{{box-sizing:border-box}}body{{margin:0;background:#101722;color:#e5edf7;font:16px system-ui,-apple-system,Segoe UI,sans-serif}}main{{max-width:760px;margin:36px auto;padding:20px}}.card{{background:#192536;border:1px solid #2b3b50;border-radius:18px;padding:22px;margin:14px 0}}.muted{{color:#9aabc1}}.green{{color:#6ee7b7}}.pill{{display:inline-block;background:#294337;color:#bbf7d0;padding:7px 11px;border-radius:99px;font-size:13px}}a.btn{{display:inline-block;background:#16815e;color:white;text-decoration:none;padding:12px 16px;border-radius:10px;font-weight:700}}table{{width:100%;border-collapse:collapse;font-size:12px;overflow-wrap:anywhere}}td,th{{border-bottom:1px solid #314154;padding:9px 5px;text-align:left}}h1{{font-size:25px}}@media(max-width:600px){{main{{margin:12px auto;padding:12px}}.card{{padding:16px}}}}</style></head><body><main>
<h1>☁️ SudarshanCloud Rewards</h1><p class="muted">Secure claim evidence · generated {made}</p>
<section class="card"><span class="pill">Claim status: {status}</span><h2 class="green">{title}</h2><h3>{ram} for {days} days</h3><p class="muted">{desc}</p><p><b>{ads} / {ads}</b> rewarded-ad completions reserved for this offer</p><p class="muted">This claim page is proof for your support ticket. Rewards are temporary, capacity-dependent, and tied to the matching customer account; they cannot be transferred.</p></section>
<section class="card"><h2>Verified ad proof</h2><p class="muted">These records were created by this service only after a valid Google AdMob server-side verification callback. Transaction references are shortened on this public page.</p><table><thead><tr><th>Transaction</th><th>Verified at</th><th>Reward event</th></tr></thead><tbody>{proof_rows}</tbody></table></section>
<section class="card"><h2>What to do next</h2><p>Open a support ticket in the SudarshanCloud Discord and send this claim link. Staff can check the recorded proof and update the claim status.</p><p><a class="btn" href="{discord}" rel="noopener noreferrer">Open Discord support</a></p><p class="muted">Keep this link private except when sending it to the support team. The link is an unguessable claim reference, not an admin password.</p></section>
</main></body></html>"""
    return HTMLResponse(page)


@app.get("/api/admin/claims/{token}")
def admin_claim_details(token: str, x_admin_key: Optional[str] = Header(default=None)):
    require_admin(x_admin_key)
    with connect_db() as con:
        claim = con.execute("SELECT * FROM claims WHERE token=?", (token,)).fetchone()
        if claim is None:
            raise HTTPException(404, "Claim not found.")
        proof = con.execute(
            "SELECT e.transaction_id,e.rewarded_at,e.ad_unit,e.reward_item,e.reward_amount FROM reserved_ads r JOIN ad_events e ON e.transaction_id=r.transaction_id WHERE r.claim_token=? ORDER BY e.rewarded_at",
            (token,),
        ).fetchall()
    return {"claim": dict(claim), "offer": OFFERS.get(claim["offer_id"]), "proof": [dict(row) for row in proof]}


def require_admin(provided_key: Optional[str]) -> None:
    if not ADMIN_API_KEY:
        raise HTTPException(503, "Admin status updates are disabled until ADMIN_API_KEY is configured.")
    if not provided_key or not secrets.compare_digest(provided_key, ADMIN_API_KEY):
        raise HTTPException(401, "Invalid admin API key.")


@app.post("/api/admin/claims/{token}/status")
def set_claim_status(token: str, body: StatusRequest, x_admin_key: Optional[str] = Header(default=None)):
    require_admin(x_admin_key)
    new_status = body.status.strip().lower()
    if new_status not in {"pending", "in_review", "approved", "rejected", "redeemed"}:
        raise HTTPException(400, "Status must be pending, in_review, approved, rejected, or redeemed.")
    with connect_db() as con:
        result = con.execute("UPDATE claims SET status=? WHERE token=?", (new_status, token))
        if result.rowcount == 0:
            raise HTTPException(404, "Claim not found.")
    return {"ok": True, "status": new_status}
