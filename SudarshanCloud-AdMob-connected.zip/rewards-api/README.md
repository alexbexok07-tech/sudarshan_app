# SudarshanCloud Rewards API

This companion service keeps the authoritative rewarded-ad records and creates one-time claim links. It is intentionally separate from the Android client so secrets and ad-verification decisions do not live in the APK.

## Important AdMob policy gate

**Do not activate production rewarded ads for hosting offers until AdMob has confirmed this design in writing.** Google's Behavioral Policies say Google ads must not be placed on apps that promise incentives for viewing/clicking ads (https://support.google.com/admob/answer/2753860), while its separate rewarded-ad policy permits some non-monetary, non-transferable in-platform rewards (https://support.google.com/admob/answer/7313578). The published wording does not conclusively settle whether trading rewarded views for a temporary Minecraft server is acceptable here. Keep Google's test rewarded-ad unit for development and ask AdMob support to review the exact product flow before going live. If not approved, do not offer server hosting in exchange for Google ad views.

## What it does

- Creates a one-use ad session before each rewarded video.
- Accepts AdMob rewarded server-side verification (SSV) callbacks at `/api/admob/ssv` and verifies the callback signature against Google's rotating public keys.
- Records unique AdMob transaction IDs and applies the daily limit using `REWARD_TIME_ZONE` (defaults to `Asia/Kolkata`).
- Allows each verified ad transaction to be reserved for only one offer.
- Generates unguessable claim URLs at `/claim/<token>`. The public claim page shows the offer, status, verified count, timestamped ad proof, and Discord support link.
- Provides admin-only status updates protected by `ADMIN_API_KEY`.

## Deploy on Render

1. Create a new Web Service from this `rewards-api` folder/repository directory. Use Python 3.11+.
2. Build command: `pip install -r requirements.txt`.
3. Start command: `uvicorn app:app --host 0.0.0.0 --port $PORT`.
4. Set `PUBLIC_BASE_URL` to the exact HTTPS URL Render assigns to the service (no trailing slash).
5. Set `ADMIN_API_KEY` to a long random secret. Do not put it in Android code, Discord messages, or public client settings.
6. Set `ADMOB_REWARDED_AD_UNIT_ID` to the rewarded ad unit's ID from the real production AdMob ad unit. Set `REWARD_TIME_ZONE=Asia/Kolkata` and `DAILY_AD_LIMIT=10`.
7. **Configure persistent storage before using real rewards.** SQLite is stored under `DATA_DIR`; a filesystem that resets on deploy/restart will lose proof and claims. Set `DATA_DIR` to a persistent volume, or migrate the database to a managed persistent database before production use. Do not assume a free host's local disk is persistent.
8. Confirm `https://YOUR-SERVICE/health` returns `{"ok":true,...}`.

## Configure AdMob SSV

In the rewarded ad unit's server-side verification settings, set the callback URL to:

`https://YOUR-SERVICE/api/admob/ssv`

The Android app must use the same production rewarded ad unit ID as configured on the server. The bundled Android code uses Google's official **test** rewarded unit ID by default and will not yield real hosting claim proof. Keep test IDs while developing. Configure your own AdMob app ID and set `ADMOB_REWARDED_AD_UNIT_ID` as a Gradle project property (or `gradle.properties` entry) only when the app and backend are ready. The callback must be publicly reachable over HTTPS.

## Configure the Android build

From the Android project root, add this to `gradle.properties` (or pass it as a Gradle project property):

`REWARDS_API_BASE_URL=https://YOUR-SERVICE`

Builds default to the placeholder `https://YOUR-REWARDS-SERVICE.onrender.com`. In placeholder mode the Rewards screen still previews local test-ad progress, but verified claim creation is disabled. Do not ship placeholder configuration.

## Staff: inspect and update a claim

A claim link is a bearer token. Ask the customer to share it in their support ticket and do not repost it publicly.

Inspect its verified records:

```bash
curl -H "X-Admin-Key: $ADMIN_API_KEY" \
  "https://YOUR-SERVICE/api/admin/claims/CLAIM_TOKEN"
```

Mark the claim in review, approved, rejected, or redeemed:

```bash
curl -X POST -H "X-Admin-Key: $ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"status":"approved"}' \
  "https://YOUR-SERVICE/api/admin/claims/CLAIM_TOKEN/status"
```

Allowed status values: `pending`, `in_review`, `approved`, `rejected`, `redeemed`.

## Offer values

The current offers are configured in `app.py` and mirrored in the Android UI:

- 3 verified ads → 1 GB RAM for 3 days
- 5 verified ads → 2 GB RAM for 3 days
- 8 verified ads → 4 GB RAM for 3 days
- 10 verified ads → 4 GB RAM for 7 days

These are suggested starter values, not guaranteed capacity. Keep rewards non-transferable and bound to the same customer account. Review AdMob's current rewarded-ad policies before production launch. Users must opt in to every rewarded ad, and the disclosure must clearly state the reward and number of ads required.

## Security notes

- There is no hard-coded `admin@sudarshan01` password. A secret embedded in an APK or static web page can be extracted; it would not secure claims.
- The public claim token is generated with a cryptographically secure random generator. Anyone with the token can view that claim, so users should only share it with support staff.
- SSV callbacks are signature-verified using Google public keys fetched from Google's key server and cached for one hour. Transaction IDs and ad-session tokens are unique to prevent simple replay/reuse.
- The current `user_id` is an app-install identifier, not a fully authenticated customer identity. Before issuing real hosting, staff must bind the claim to the customer's existing SudarshanCloud account and verify it is not transferred. For stronger automated binding, connect this API to your authenticated portal identity rather than trusting a client-supplied install ID.
- AdMob server-side verification can be delayed. If the claim says there are not enough verified ads immediately after a video, refresh stats after a short wait.
- This project has not been production-deployed or audited. Test it with AdMob's SSV test tool and a test database before granting real resources.
