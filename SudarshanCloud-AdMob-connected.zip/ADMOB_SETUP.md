# Google AdMob integration (SudarshanCloud Android app)

The app now has an anchored banner-ad slot above the bottom navigation bar and initializes the Google Mobile Ads SDK.

## Important: this build uses Google's TEST IDs
The sample AdMob App ID and banner ad unit ID are for development only:
- App ID: `ca-app-pub-3940256099942544~3347511713`
- Banner unit ID: `ca-app-pub-3940256099942544/6300978111`

They will show test ads, not earn revenue. Never click your own ads or use live ads while testing.

## To start earning with AdMob
1. Create/sign in to an AdMob account at https://admob.google.com/ and add the Android app. The app may need to be published/verified before serving production ads.
2. In AdMob, copy your app's **AdMob App ID** (format like `ca-app-pub-...~...`) and create a **Banner** ad unit (format like `ca-app-pub-.../...`).
3. Replace the `com.google.android.gms.ads.APPLICATION_ID` value in `app/src/main/AndroidManifest.xml` with your real App ID.
4. Replace `TEST_BANNER_AD_UNIT_ID` in `app/src/main/java/com/sudarshancloud/app/AdMobBanner.kt` with your real banner unit ID only when ready for production.
5. Build and install a debug version with test IDs first. Check that the banner loads without covering app controls.
6. Before release, review Google's current AdMob policies and consent requirements. If your users may be in the EEA/UK/Switzerland, integrate Google's User Messaging Platform (UMP) consent flow where required; consider privacy/consent requirements for all regions and target audiences.
7. Add the required privacy policy and complete AdMob app-setup steps accurately. Revenue is not guaranteed; it depends on eligible impressions, user geography, ad demand, and policy compliance.

## Placement and behavior
- The banner is placed above the app's bottom navigation bar.
- The banner uses a fixed standard banner size. For responsive adaptive banners, the layout should be updated to use an anchored adaptive `AdSize`.
- Do not place ads where they can be mistaken for buttons or where they obstruct server-management actions.


## Policy gate — do not switch rewarded offers to live ads yet

**Keep the rewarded ad unit on Google's test ID until AdMob confirms this exact design in writing.** Google's current Behavioral Policies say Google ads must not be placed on apps that promise incentives for viewing or clicking ads: https://support.google.com/admob/answer/2753860. Separately, its rewarded-ad policy allows certain non-monetary, non-transferable in-platform rewards: https://support.google.com/admob/answer/7313578. Those rules do not unambiguously confirm that exchanging rewarded views for temporary game-server hosting is permitted in this app. Ask AdMob support to review the exact flow before enabling production ads; do not rely on this code or the test ads as policy approval. If AdMob says the design is not eligible, keep the hosting offers but remove the Google-ad-for-hosting exchange (or use a provider that explicitly permits this model).

## Rewarded hosting offers

The sidebar now includes **Rewards & Offers** with these starter tiers:

- 3 rewarded videos → 1 GB RAM server for 3 days
- 5 rewarded videos → 2 GB RAM server for 3 days
- 8 rewarded videos → 4 GB RAM server for 3 days
- 10 rewarded videos → 4 GB RAM server for 7 days

The screen uses Google's official rewarded-video **test** ad unit by default. The counter increments after the SDK's earned-reward callback, but the app clearly labels this as local preview progress. Claim links remain disabled until the companion `rewards-api` service is deployed and configured. In production, claims are based on the backend's signature-verified AdMob SSV events, not on the local count.

### Production rewarded setup

1. Deploy the `rewards-api` folder using its `README.md` and configure persistent storage before using real claims.
2. Configure the rewarded ad unit's SSV callback URL to `https://YOUR-SERVICE/api/admob/ssv`.
3. In Android project `gradle.properties`, set `REWARDS_API_BASE_URL=https://YOUR-SERVICE` and `ADMOB_REWARDED_AD_UNIT_ID=ca-app-pub-.../...` when the backend and production ad unit are ready. The GitHub Actions workflow also accepts these as repository **variables** named `REWARDS_API_BASE_URL` and `ADMOB_REWARDED_AD_UNIT_ID`.
4. Replace the sample App ID in `app/src/main/AndroidManifest.xml` and the banner unit ID in `AdMobBanner.kt` with your own values before release.
5. Test the SSV callback with AdMob's test tool. Wait for the server-verified counter to update before creating a claim.

Each ad requires an explicit user tap and can only count toward one claim. Offers should remain temporary, account-bound, and non-transferable. See `rewards-api/README.md` for current claim statuses, staff verification and AdMob policy notes.
