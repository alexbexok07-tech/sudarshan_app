# SudarshanCloud AdMob connection

The Android source has been configured with the IDs provided for this project:

- **AdMob App ID**: `ca-app-pub-8833727195294347~8714613783`
- **Banner ad unit ID**: `ca-app-pub-8833727195294347/8345938964`

The Rewarded ad unit remains on Google’s test ID unless you separately set the `ADMOB_REWARDED_AD_UNIT_ID` GitHub Actions repository variable. Do not change that variable to a production ID until AdMob has confirmed in writing that the app’s hosting-for-ad-views offer design is compliant.

## Important policy check

Google’s AdMob policy on apps that offer compensation programs says ads may not be placed in apps that promise incentives for viewing or clicking ads. A separate rewarded-ad policy permits certain non-transferable non-monetary rewards within the publisher’s platform. Since this app offers temporary Minecraft hosting for watching ads, ask AdMob support to confirm the exact model in writing before enabling production ad serving.

## Build

1. Upload the entire project contents to the root of the GitHub repository (including `.github/workflows/`).
2. Open **Actions → Build SudarshanCloud APK → Run workflow**.
3. Download the APK from the workflow Artifacts when the workflow succeeds.
4. Test with test ads during development. Never click your own production ads.

The App ID and banner ID are IDs, not secret credentials. Do not put admin API keys or other secrets in the Android app.
