package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PteroStatsAttributes
import com.example.data.model.Server
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusStarting
import com.example.ui.theme.StatusStopping
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ServerViewModel
import java.util.Locale

/**
 * ServerListScreen composable displaying the list of servers fetched from [ServerViewModel],
 * presenting each server's name and status inside Material3 Cards.
 */
@Composable
fun ServerListScreen(
    viewModel: ServerViewModel,
    modifier: Modifier = Modifier,
    onServerClick: (Server) -> Unit = {}
) {
    val servers by viewModel.servers.collectAsStateWithLifecycle()
    val realtimeStats by viewModel.realtimeStats.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf<String?>(null) }

    val filteredServers = remember(servers, realtimeStats, searchQuery, selectedStatusFilter) {
        servers.filter { server ->
            val effectiveStatus = (realtimeStats[server.id]?.currentState ?: server.effectiveStatus).lowercase()
            
            val matchesStatus = when (selectedStatusFilter?.lowercase()) {
                null -> true
                "online", "running" -> effectiveStatus == "running"
                "offline" -> effectiveStatus == "offline"
                "starting" -> effectiveStatus == "starting"
                "stopping" -> effectiveStatus == "stopping"
                else -> effectiveStatus.contains(selectedStatusFilter!!.lowercase())
            }

            val matchesSearch = if (searchQuery.isBlank()) {
                true
            } else {
                val q = searchQuery.trim().lowercase()
                server.name.lowercase().contains(q) ||
                effectiveStatus.contains(q) ||
                server.nodeName.lowercase().contains(q) ||
                server.primaryAddress.lowercase().contains(q) ||
                server.id.lowercase().contains(q)
            }

            matchesStatus && matchesSearch
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header Section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Servers (${filteredServers.size}${if (filteredServers.size != servers.size) " of ${servers.size}" else ""})",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "portal.sudarshancloud.com",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                IconButton(
                    onClick = { viewModel.refreshServers() },
                    modifier = Modifier.testTag("server_list_refresh_btn")
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color(0xFFEAB308),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = Color(0xFFEAB308)
                        )
                    }
                }
            }

            // Local Search Bar (filter by server name or status)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name, status (e.g. running, offline)...", color = TextMuted, fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear search",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("server_list_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFEAB308),
                    unfocusedBorderColor = DarkBorder,
                    focusedContainerColor = DarkSurfaceElevated,
                    unfocusedContainerColor = DarkSurfaceElevated
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Status Filter Chips
            val statusFilters = listOf(
                null to "All Statuses",
                "running" to "Running",
                "offline" to "Offline",
                "starting" to "Starting",
                "stopping" to "Stopping"
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                statusFilters.forEach { (filterKey, label) ->
                    val isSelected = selectedStatusFilter == filterKey
                    val count = if (filterKey == null) {
                        servers.size
                    } else {
                        servers.count { s ->
                            val st = (realtimeStats[s.id]?.currentState ?: s.effectiveStatus).lowercase()
                            st == filterKey
                        }
                    }

                    val activeColor = when (filterKey) {
                        "running" -> StatusOnline
                        "offline" -> Color(0xFFEF4444)
                        "starting" -> StatusStarting
                        "stopping" -> StatusStopping
                        else -> Color(0xFF38BDF8)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Color(0xFF283852) else DarkSurfaceElevated)
                            .border(1.dp, if (isSelected) activeColor else DarkBorder, RoundedCornerShape(10.dp))
                            .clickable {
                                selectedStatusFilter = if (isSelected && filterKey != null) null else filterKey
                            }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                            .testTag("filter_status_${filterKey ?: "all"}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (filterKey != null) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(RoundedCornerShape(3.5.dp))
                                        .background(activeColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = "$label ($count)",
                                color = if (isSelected) TextPrimary else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Error notice banner if any
            if (!errorMessage.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF3B1E1E))
                        .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = errorMessage ?: "",
                        color = Color(0xFFFCA5A5),
                        fontSize = 12.5.sp
                    )
                }
            }

            // Server Cards List
            if (filteredServers.isEmpty() && !isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Dns,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (servers.isEmpty()) "No servers found" else "No servers match search or filter",
                            color = TextSecondary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (servers.isEmpty()) {
                            OutlinedButton(
                                onClick = { viewModel.refreshServers() },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Retry Connection", color = Color(0xFFEAB308))
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    searchQuery = ""
                                    selectedStatusFilter = null
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Clear Filters", color = Color(0xFFEAB308))
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredServers, key = { it.id }) { server ->
                        ServerCardItem(
                            server = server,
                            liveStats = realtimeStats[server.id],
                            onClick = { onServerClick(server) },
                            onPowerAction = { signal -> viewModel.sendPowerAction(server.id, signal) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Material 3 Card representing an individual server.
 */
@Composable
fun ServerCardItem(
    server: Server,
    liveStats: PteroStatsAttributes?,
    onClick: () -> Unit,
    onPowerAction: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val effectiveStatus = liveStats?.currentState ?: server.effectiveStatus

    // Calculate resource values
    val cpuUsage = liveStats?.resources?.cpuAbsolute ?: 0.0
    val cpuLimit = server.limits?.cpuLimit ?: 0.0
    val cpuStr = String.format(Locale.US, "%.2f%%", cpuUsage)
    val cpuLimitStr = if (cpuLimit > 0.0) "${cpuLimit.toInt()}%" else "Unlimited"

    val memBytes = liveStats?.resources?.memoryBytes ?: 0L
    val memLimitMb = server.limits?.memoryMb ?: 0L
    val memGiB = memBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
    val memLimitGiB = memLimitMb.toDouble() / 1024.0
    val memStr = String.format(Locale.US, "%.2f GiB", memGiB)
    val memLimitStr = if (memLimitGiB > 0) String.format(Locale.US, "%.0f GiB", memLimitGiB) else "Unlimited"

    val address = server.primaryAddress

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("server_card_${server.id}")
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = DarkSurfaceElevated
        ),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkBorder))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Top Row: Server Name & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = server.name,
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Node: ${server.nodeName}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                // Material Status Badge
                StatusBadge(status = effectiveStatus)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // IP Address Row with click-to-copy
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Server IP", address))
                        Toast.makeText(context, "Copied IP: $address", Toast.LENGTH_SHORT).show()
                    }
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "IP: ",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = address,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy IP",
                    tint = TextMuted,
                    modifier = Modifier.size(13.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Resource summaries
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "CPU: $cpuStr / $cpuLimitStr",
                    color = TextSecondary,
                    fontSize = 12.5.sp
                )
                Text(
                    text = "RAM: $memStr / $memLimitStr",
                    color = TextSecondary,
                    fontSize = 12.5.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Actions: Quick Power buttons & Manage Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick Power Controls
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { onPowerAction("start") },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF14532D))
                            .testTag("server_card_start_${server.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Start",
                            tint = StatusOnline,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onPowerAction("restart") },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF713F12))
                            .testTag("server_card_restart_${server.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restart",
                            tint = StatusStarting,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { onPowerAction("stop") },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF7F1D1D))
                            .testTag("server_card_stop_${server.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop",
                            tint = StatusStopping,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Primary Manage Server Button (styled consistent with SudarshanCloud theme)
                Button(
                    onClick = onClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("server_card_manage_${server.id}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFA2A039),
                        contentColor = Color(0xFF0F1726)
                    )
                ) {
                    Text(
                        text = "Manage server",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
