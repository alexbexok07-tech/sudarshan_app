package com.sudarshancloud.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.model.CreateScheduleRequest
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroScheduleAttributes
import com.sudarshancloud.app.data.model.PteroStartupVariable
import com.sudarshancloud.app.ui.theme.DarkBorder
import com.sudarshancloud.app.ui.theme.DarkSurface
import com.sudarshancloud.app.ui.theme.DarkSurfaceElevated
import com.sudarshancloud.app.ui.theme.TextMuted
import com.sudarshancloud.app.ui.theme.TextPrimary
import com.sudarshancloud.app.ui.theme.TextSecondary

@Composable
fun WorldManagerScreen(
    server: CachedServerEntity?,
    files: List<PteroFileAttributes>,
    onOpenWorld: (String) -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val worlds = files.filter { !it.isFile && (it.name.equals("world", true) || it.name.startsWith("world-", true)) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("World Manager", color = TextPrimary, fontSize = 22.sp)
                Text("Manage Minecraft world folders from the server filesystem.", color = TextSecondary, fontSize = 12.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = TextPrimary) }
        }
        Spacer(Modifier.height(12.dp))
        if (server == null) Text("No server selected", color = TextSecondary)
        else if (worlds.isEmpty()) Text("No world folders were found in /.", color = TextMuted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(worlds, key = { it.name }) { world ->
                Row(
                    Modifier.fillMaxWidth().border(1.dp, DarkBorder, RoundedCornerShape(12.dp)).background(DarkSurfaceElevated, RoundedCornerShape(12.dp)).clickable { onOpenWorld("/${world.name}") }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Folder, null, tint = Color(0xFFEAB308), modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(world.name, color = TextPrimary, fontSize = 15.sp)
                        Text("Open world files", color = TextSecondary, fontSize = 11.sp)
                    }
                    Text("OPEN", color = Color(0xFF38BDF8), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun StartupManagerScreen(
    server: CachedServerEntity?,
    variables: List<PteroStartupVariable>,
    onRefresh: () -> Unit,
    onUpdate: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var editing by remember { mutableStateOf<PteroStartupVariable?>(null) }
    var value by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("Startup & Version", color = TextPrimary, fontSize = 22.sp)
                Text("Edit only variables that your Pterodactyl account marks as editable.", color = TextSecondary, fontSize = 12.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = TextPrimary) }
        }
        Spacer(Modifier.height(12.dp))
        if (server == null) Text("No server selected", color = TextSecondary)
        else if (variables.isEmpty()) Text("No startup variables are available for this server.", color = TextMuted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(variables, key = { it.envVariable }) { variable ->
                val current = variable.serverValue ?: variable.defaultValue.orEmpty()
                Row(Modifier.fillMaxWidth().border(1.dp, DarkBorder, RoundedCornerShape(12.dp)).background(DarkSurfaceElevated, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(variable.name.ifBlank { variable.envVariable }, color = TextPrimary, fontSize = 14.sp)
                        Text(variable.envVariable, color = Color(0xFF38BDF8), fontSize = 11.sp)
                        Text(current.ifBlank { "Not set" }, color = TextSecondary, fontSize = 12.sp)
                        if (!variable.description.isNullOrBlank()) Text(variable.description!!, color = TextMuted, fontSize = 10.sp)
                    }
                    IconButton(enabled = variable.isEditable, onClick = { editing = variable; value = current }) {
                        Icon(Icons.Default.Edit, "Edit", tint = if (variable.isEditable) Color(0xFFEAB308) else TextMuted)
                    }
                }
            }
        }
    }
    editing?.let { variable ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Edit ${variable.name}") },
            text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(variable.envVariable) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { onUpdate(variable.envVariable, value); editing = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun SchedulesScreen(
    server: CachedServerEntity?,
    schedules: List<PteroScheduleAttributes>,
    onRefresh: () -> Unit,
    onCreate: (CreateScheduleRequest) -> Unit,
    onExecute: (Int) -> Unit,
    onDelete: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreate by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("Daily Restart") }
    var minute by remember { mutableStateOf("0") }
    var hour by remember { mutableStateOf("3") }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("Schedules", color = TextPrimary, fontSize = 22.sp)
                Text("Create, run, and delete scheduled tasks using the Client API.", color = TextSecondary, fontSize = 12.sp)
            }
            Row { IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = TextPrimary) }; Button(onClick = { showCreate = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEAB308), contentColor = Color(0xFF111827))) { Text("Add") } }
        }
        Spacer(Modifier.height(12.dp))
        if (server == null) Text("No server selected", color = TextSecondary)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(schedules, key = { it.id }) { schedule ->
                Row(Modifier.fillMaxWidth().border(1.dp, DarkBorder, RoundedCornerShape(12.dp)).background(DarkSurfaceElevated, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(schedule.name, color = TextPrimary, fontSize = 14.sp)
                        Text("${schedule.minute} ${schedule.hour} ${schedule.dayOfMonth} ${schedule.month} ${schedule.dayOfWeek}", color = Color(0xFF38BDF8), fontSize = 12.sp)
                        Text(if (schedule.isActive) "Active" else "Disabled", color = if (schedule.isActive) Color(0xFF10B981) else TextMuted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { onExecute(schedule.id) }) { Icon(Icons.Default.PlayArrow, "Execute", tint = Color(0xFF10B981)) }
                    IconButton(onClick = { onDelete(schedule.id) }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFEF4444)) }
                }
            }
        }
    }
    if (showCreate) AlertDialog(
        onDismissRequest = { showCreate = false },
        title = { Text("Create Schedule") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
            OutlinedTextField(minute, { minute = it }, label = { Text("Minute (0-59 or *)") }, singleLine = true)
            OutlinedTextField(hour, { hour = it }, label = { Text("Hour (0-23 or *)") }, singleLine = true)
            Text("Every day by default: day/month/week are *", color = TextMuted, fontSize = 11.sp)
        } },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onCreate(CreateScheduleRequest(name.trim(), minute.trim(), hour.trim())); showCreate = false }) { Text("Create") } },
        dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
    )
}
