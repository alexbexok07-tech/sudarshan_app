package com.sudarshancloud.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sudarshancloud.app.data.api.ConsoleLogEntry
import com.sudarshancloud.app.data.api.LogLevel
import com.sudarshancloud.app.data.db.CachedServerEntity
import com.sudarshancloud.app.data.db.PanelConfigEntity
import com.sudarshancloud.app.data.model.PteroBackupAttributes
import com.sudarshancloud.app.data.model.PteroDatabaseAttributes
import com.sudarshancloud.app.data.model.PteroStartupVariable
import com.sudarshancloud.app.data.model.PteroScheduleAttributes
import com.sudarshancloud.app.data.model.CreateScheduleRequest
import com.sudarshancloud.app.data.model.PteroFileAttributes
import com.sudarshancloud.app.data.model.PteroStatsAttributes
import com.sudarshancloud.app.data.repository.ServerRepository
import com.sudarshancloud.app.ui.components.NavDestination
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class FileEditorState(
    val filePath: String,
    val content: String,
    val isSaving: Boolean = false,
    val hasUnsavedChanges: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val repository = ServerRepository(application)

    val configState: StateFlow<PanelConfigEntity?> = repository.configFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val serversState: StateFlow<List<CachedServerEntity>> = repository.cachedServersFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val realtimeStats: StateFlow<Map<String, PteroStatsAttributes>> = repository.realtimeStatsMap

    private val _selectedServer = MutableStateFlow<CachedServerEntity?>(null)
    val selectedServer: StateFlow<CachedServerEntity?> = _selectedServer.asStateFlow()

    private val _currentDestination = MutableStateFlow(NavDestination.SERVERS)
    val currentDestination: StateFlow<NavDestination> = _currentDestination.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _userFeedback = MutableStateFlow<String?>(null)
    val userFeedback: StateFlow<String?> = _userFeedback.asStateFlow()

    // Remote Console
    private val _consoleLogs = MutableStateFlow<List<ConsoleLogEntry>>(emptyList())
    val consoleLogs: StateFlow<List<ConsoleLogEntry>> = _consoleLogs.asStateFlow()

    // File Manager
    private val _currentDirectory = MutableStateFlow("/")
    val currentDirectory: StateFlow<String> = _currentDirectory.asStateFlow()

    private val _filesList = MutableStateFlow<List<PteroFileAttributes>>(emptyList())
    val filesList: StateFlow<List<PteroFileAttributes>> = _filesList.asStateFlow()

    private val _isLoadingFiles = MutableStateFlow(false)
    val isLoadingFiles: StateFlow<Boolean> = _isLoadingFiles.asStateFlow()

    private val _fileEditorState = MutableStateFlow<FileEditorState?>(null)
    val fileEditorState: StateFlow<FileEditorState?> = _fileEditorState.asStateFlow()

    // Backups & Databases
    private val _backupsList = MutableStateFlow<List<PteroBackupAttributes>>(emptyList())
    val backupsList: StateFlow<List<PteroBackupAttributes>> = _backupsList.asStateFlow()

    private val _databasesList = MutableStateFlow<List<PteroDatabaseAttributes>>(emptyList())
    val databasesList: StateFlow<List<PteroDatabaseAttributes>> = _databasesList.asStateFlow()

    private val _startupVariables = MutableStateFlow<List<PteroStartupVariable>>(emptyList())
    val startupVariables: StateFlow<List<PteroStartupVariable>> = _startupVariables.asStateFlow()

    private val _schedulesList = MutableStateFlow<List<PteroScheduleAttributes>>(emptyList())
    val schedulesList: StateFlow<List<PteroScheduleAttributes>> = _schedulesList.asStateFlow()

    private var pollingJob: Job? = null

    init {
        viewModelScope.launch {
            repository.initialize()
            val result = repository.fetchServersFromPanel()
            if (result.isSuccess) {
                _userFeedback.value = "Connected to SudarshanCloud"
                refreshAllTelemetry(result.getOrNull()?.map { it.identifier }.orEmpty())
            }
            // Apply the saved panel configuration before recurring telemetry starts.
            startTelemetryLoop()
        }

        viewModelScope.launch {
            repository.webSocketManager.logsFlow.collect { entry ->
                _consoleLogs.value = (_consoleLogs.value + entry).takeLast(300)
            }
        }

        viewModelScope.launch {
            serversState.collectLatest { list ->
                val selected = _selectedServer.value
                if (selected == null || list.none { it.identifier == selected.identifier }) {
                    _selectedServer.value = list.firstOrNull()
                }
            }
        }

    }

    fun selectDestination(dest: NavDestination) {
        _currentDestination.value = dest
        val server = _selectedServer.value
        if (server != null) {
            when (dest) {
                NavDestination.CONSOLE -> {
                    viewModelScope.launch { repository.connectServerConsole(server.identifier) }
                }
                NavDestination.FILES -> {
                    loadFiles(server.identifier, _currentDirectory.value)
                }
                NavDestination.BACKUPS -> {
                    loadBackups(server.identifier)
                }
                NavDestination.DATABASES -> {
                    loadDatabases(server.identifier)
                }
                NavDestination.WORLDS -> {
                    loadFiles(server.identifier, "/")
                }
                NavDestination.STARTUP -> {
                    loadStartup(server.identifier)
                }
                NavDestination.SCHEDULES -> {
                    loadSchedules(server.identifier)
                }
                else -> {}
            }
        }
    }

    fun selectServer(server: CachedServerEntity) {
        _selectedServer.value = server
        _currentDirectory.value = "/"
        _filesList.value = emptyList()
        _fileEditorState.value = null
        viewModelScope.launch { repository.connectServerConsole(server.identifier) }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun refreshAll() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val res = repository.fetchServersFromPanel()
            if (res.isSuccess) {
                _userFeedback.value = "Synced with SudarshanCloud panel"
                refreshAllTelemetry(res.getOrNull()?.map { it.identifier }.orEmpty())
            } else {
                _userFeedback.value = repository.lastError.value ?: "Panel sync failed"
            }
            _isRefreshing.value = false
        }
    }

    fun sendPowerAction(serverIdentifier: String, signal: String) {
        viewModelScope.launch {
            val result = repository.sendPowerAction(serverIdentifier, signal)
            if (result.isSuccess) {
                _userFeedback.value = "Power signal '$signal' sent"
                delay(750)
                repository.fetchServerResources(serverIdentifier)
            } else {
                _userFeedback.value = repository.lastError.value
                    ?: result.exceptionOrNull()?.localizedMessage
                    ?: "Power action '$signal' failed"
            }
        }
    }

    fun sendConsoleCommand(command: String) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            repository.sendConsoleCommand(server.identifier, command)
        }
    }

    fun clearConsoleLogs() {
        _consoleLogs.value = emptyList()
        _userFeedback.value = "Console terminal cleared"
    }

    fun saveApiConfig(panelUrl: String, apiKey: String, applicationApiKey: String, userEmail: String, showOtherServers: Boolean) {
        viewModelScope.launch {
            repository.savePanelConfig(panelUrl, apiKey, applicationApiKey, showOtherServers, userEmail)
            _userFeedback.value = "API settings saved. Connecting to SudarshanCloud..."
            val result = repository.fetchServersFromPanel()
            if (result.isSuccess) {
                _userFeedback.value = "Connected to SudarshanCloud! Loaded ${result.getOrNull()?.size ?: 0} servers."
            } else {
                _userFeedback.value = "Saved! ${repository.lastError.value ?: "Connection failed"}"
            }
        }
    }

    fun loadFiles(serverIdentifier: String, directory: String) {
        viewModelScope.launch {
            _isLoadingFiles.value = true
            _currentDirectory.value = directory
            val res = repository.listFiles(serverIdentifier, directory)
            if (res.isSuccess) {
                _filesList.value = res.getOrDefault(emptyList())
            } else {
                _filesList.value = emptyList()
                _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to load files"
            }
            _isLoadingFiles.value = false
        }
    }

    fun openFile(filePath: String) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.getFileContent(server.identifier, filePath)
            if (res.isSuccess) {
                _fileEditorState.value = FileEditorState(
                    filePath = filePath,
                    content = res.getOrDefault("")
                )
            }
        }
    }

    fun updateEditorContent(newContent: String) {
        _fileEditorState.value = _fileEditorState.value?.copy(
            content = newContent,
            hasUnsavedChanges = true
        )
    }

    fun saveFileEditorContent() {
        val current = _fileEditorState.value ?: return
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            _fileEditorState.value = current.copy(isSaving = true)
            val res = repository.saveFileContent(server.identifier, current.filePath, current.content)
            if (res.isSuccess) {
                _fileEditorState.value = current.copy(isSaving = false, hasUnsavedChanges = false)
                _userFeedback.value = "File saved successfully"
            } else {
                _fileEditorState.value = current.copy(isSaving = false)
                _userFeedback.value = "Failed to save file: ${res.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun closeFileEditor() {
        _fileEditorState.value = null
    }

    fun createFolder(name: String) {
        val server = _selectedServer.value ?: return
        val dir = _currentDirectory.value
        viewModelScope.launch {
            val res = repository.createFolder(server.identifier, dir, name)
            if (res.isSuccess) {
                _userFeedback.value = "Folder created: $name"
                loadFiles(server.identifier, dir)
            }
        }
    }

    fun createFile(name: String) {
        val server = _selectedServer.value ?: return
        val dir = _currentDirectory.value
        viewModelScope.launch {
            val res = repository.createFile(server.identifier, dir, name)
            if (res.isSuccess) {
                _userFeedback.value = "File created: $name"
                loadFiles(server.identifier, dir)
            } else {
                _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to create file"
            }
        }
    }

    fun deleteFile(fileName: String) {
        val server = _selectedServer.value ?: return
        val dir = _currentDirectory.value
        viewModelScope.launch {
            val res = repository.deleteFiles(server.identifier, dir, listOf(fileName))
            if (res.isSuccess) {
                _userFeedback.value = "Deleted $fileName"
                loadFiles(server.identifier, dir)
            }
        }
    }

    fun loadBackups(serverIdentifier: String) {
        viewModelScope.launch {
            val res = repository.listBackups(serverIdentifier)
            if (res.isSuccess) {
                _backupsList.value = res.getOrDefault(emptyList())
            }
        }
    }

    fun createBackup(name: String?) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.createBackup(server.identifier, name)
            if (res.isSuccess) {
                _userFeedback.value = "Backup started: ${name ?: "Snapshot"}"
                loadBackups(server.identifier)
            } else {
                _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Backup failed"
            }
        }
    }

    fun deleteBackup(backupUuid: String) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.deleteBackup(server.identifier, backupUuid)
            if (res.isSuccess) {
                _userFeedback.value = "Backup deleted"
                loadBackups(server.identifier)
            } else {
                _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Backup deletion failed"
            }
        }
    }

    fun loadDatabases(serverIdentifier: String) {
        viewModelScope.launch {
            val res = repository.listDatabases(serverIdentifier)
            if (res.isSuccess) {
                _databasesList.value = res.getOrDefault(emptyList())
            }
        }
    }

    fun createDatabase(databaseName: String, remote: String, databaseHostId: Int) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.createDatabase(server.identifier, databaseName, remote, databaseHostId)
            if (res.isSuccess) {
                _userFeedback.value = "Database created"
                loadDatabases(server.identifier)
            } else {
                _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Database creation failed"
            }
        }
    }

    fun loadStartup(serverIdentifier: String) {
        viewModelScope.launch {
            val res = repository.getStartup(serverIdentifier)
            if (res.isSuccess) _startupVariables.value = res.getOrDefault(emptyList())
            else _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to load startup settings"
        }
    }

    fun updateStartupVariable(key: String, value: String) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.updateStartupVariable(server.identifier, key, value)
            if (res.isSuccess) {
                _userFeedback.value = "Startup setting updated"
                loadStartup(server.identifier)
            } else _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Startup update failed"
        }
    }

    fun loadSchedules(serverIdentifier: String) {
        viewModelScope.launch {
            val res = repository.listSchedules(serverIdentifier)
            if (res.isSuccess) _schedulesList.value = res.getOrDefault(emptyList())
            else _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to load schedules"
        }
    }

    fun createSchedule(request: CreateScheduleRequest) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.createSchedule(server.identifier, request)
            if (res.isSuccess) { _userFeedback.value = "Schedule created"; loadSchedules(server.identifier) }
            else _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Schedule creation failed"
        }
    }

    fun executeSchedule(scheduleId: Int) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.executeSchedule(server.identifier, scheduleId)
            _userFeedback.value = if (res.isSuccess) "Schedule executed" else res.exceptionOrNull()?.localizedMessage ?: "Schedule execution failed"
        }
    }

    fun deleteSchedule(scheduleId: Int) {
        val server = _selectedServer.value ?: return
        viewModelScope.launch {
            val res = repository.deleteSchedule(server.identifier, scheduleId)
            if (res.isSuccess) { _userFeedback.value = "Schedule deleted"; loadSchedules(server.identifier) }
            else _userFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Schedule deletion failed"
        }
    }

    fun clearFeedback() {
        _userFeedback.value = null
    }

    private fun refreshAllTelemetry(serverIdentifiers: List<String> = serversState.value.map { it.identifier }) {
        viewModelScope.launch {
            val ids = serverIdentifiers.distinct()
            coroutineScope {
                ids.map { id -> async { repository.fetchServerResources(id) } }.awaitAll()
            }
        }
    }

    private fun startTelemetryLoop() {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            while (isActive) {
                val snapshot = serversState.value
                    .map { it.identifier }
                    .distinct()
                if (snapshot.isNotEmpty()) {
                    coroutineScope {
                        snapshot.map { id ->
                            async { repository.fetchServerResources(id) }
                        }.awaitAll()
                    }
                }
                delay(3000)
            }
        }
    }
}
