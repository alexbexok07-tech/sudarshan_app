package com.sudarshancloud.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions
import com.sudarshancloud.app.BuildConfig
import com.sudarshancloud.app.data.api.RewardsApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

private data class HostingOffer(
    val id: String,
    val title: String,
    val ram: String,
    val days: Int,
    val adsRequired: Int,
    val description: String
)

private data class LocalMissionProgress(
    val watched: Int = 0,
    val startedAtMillis: Long = 0L,
    val claimed: Boolean = false
)

private val hostingOffers = listOf(
    HostingOffer("ram1_3d", "Starter Boost", "1 GB RAM", 3, 3, "Try a small server for a few days"),
    HostingOffer("ram2_3d", "Survival Trial", "2 GB RAM", 3, 5, "A little more room for a small SMP"),
    HostingOffer("ram4_3d", "Community Trial", "4 GB RAM", 3, 8, "Test a bigger world with friends"),
    HostingOffer("ram4_7d", "Weekender", "4 GB RAM", 7, 10, "A longer trial for your community")
)

private val RewardGreen = Color(0xFF34D399)
private val RewardBackground = Color(0xFF101722)
private val RewardCard = Color(0xFF192536)
private val RewardMuted = Color(0xFF9AAAC0)
private const val DAILY_REWARDED_AD_LIMIT = 10
private const val MISSION_CYCLE_MILLIS = 4L * 24 * 60 * 60 * 1000
private const val SUPPORT_DISCORD_URL = "https://discord.gg/3bHSDR524H"

private fun loadLocalMissionProgress(prefs: android.content.SharedPreferences): Map<String, LocalMissionProgress> {
    val now = System.currentTimeMillis()
    val loaded = mutableMapOf<String, LocalMissionProgress>()
    hostingOffers.forEach { offer ->
        var start = prefs.getLong("mission_started_${offer.id}", 0L)
        var watched = prefs.getInt("mission_watched_${offer.id}", 0)
        var claimed = prefs.getBoolean("mission_claimed_${offer.id}", false)
        if (start > 0L && now - start >= MISSION_CYCLE_MILLIS) {
            start = 0L
            watched = 0
            claimed = false
            prefs.edit()
                .putLong("mission_started_${offer.id}", 0L)
                .putInt("mission_watched_${offer.id}", 0)
                .putBoolean("mission_claimed_${offer.id}", false)
                .apply()
        }
        loaded[offer.id] = LocalMissionProgress(watched, start, claimed)
    }
    return loaded
}

private fun formatResetTime(startedAtMillis: Long): String {
    if (startedAtMillis <= 0L) return "Starts with your first video"
    val remaining = (MISSION_CYCLE_MILLIS - (System.currentTimeMillis() - startedAtMillis)).coerceAtLeast(0L)
    val days = remaining / (24L * 60 * 60 * 1000)
    val hours = (remaining / (60L * 60 * 1000)) % 24
    return if (days > 0) "Refreshes in ${days}d ${hours}h" else "Refreshes in ${hours}h"
}

private fun serverResetLabel(isoDate: String?): String {
    if (isoDate.isNullOrBlank()) return "Starts with your first video"
    return try {
        val resetAt = java.time.OffsetDateTime.parse(isoDate).toInstant().toEpochMilli()
        val remaining = (resetAt - System.currentTimeMillis()).coerceAtLeast(0L)
        val days = remaining / (24L * 60 * 60 * 1000)
        val hours = (remaining / (60L * 60 * 1000)) % 24
        if (days > 0) "Refreshes in ${days}d ${hours}h" else "Refreshes in ${hours}h"
    } catch (_: Exception) { "Refreshes 4 days after the first video" }
}

@Composable
fun RewardsScreen() {
    val context = LocalContext.current
    val activity = context.findActivity()
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("sudarshan_rewards", 0) }
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Kolkata") }.format(Date())
    val installId = remember {
        prefs.getString("install_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("install_id", it).apply()
        }
    }

    var localDay by remember { mutableStateOf(prefs.getString("local_day", today) ?: today) }
    var localWatched by remember { mutableIntStateOf(if (localDay == today) prefs.getInt("watched_$today", 0) else 0) }
    var verifiedToday by remember { mutableIntStateOf(0) }
    var availableToday by remember { mutableIntStateOf(0) }
    var dailyLimit by remember { mutableIntStateOf(DAILY_REWARDED_AD_LIMIT) }
    var serverMissions by remember { mutableStateOf<Map<String, RewardsApi.MissionProgress>>(emptyMap()) }
    var localMissions by remember { mutableStateOf(loadLocalMissionProgress(prefs)) }
    var refreshClock by remember { mutableIntStateOf(0) }
    var isRefreshing by remember { mutableStateOf(false) }
    var isShowingAd by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var claimUrl by remember { mutableStateOf<String?>(null) }
    var claimingOffer by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            refreshClock++
            localMissions = loadLocalMissionProgress(prefs)
        }
    }

    if (localDay != today) {
        localDay = today
        localWatched = 0
        prefs.edit().putString("local_day", today).putInt("watched_$today", 0).apply()
    }

    val refreshServerStats: suspend () -> Unit = {
        if (RewardsApi.isConfigured) {
            isRefreshing = true
            try {
                val stats = RewardsApi.getStats(installId)
                verifiedToday = stats.verifiedToday
                availableToday = stats.availableToday
                dailyLimit = stats.dailyLimit
                serverMissions = stats.missions
                message = null
            } catch (e: Exception) {
                message = "Server verification unavailable: ${e.message ?: "please try again"}"
            } finally {
                isRefreshing = false
            }
        }
    }

    LaunchedEffect(installId) { refreshServerStats() }

    val watchedToday = maxOf(localWatched, verifiedToday)

    fun watchVideo(offer: HostingOffer) {
        if (isShowingAd) return
        val mission = if (RewardsApi.isConfigured) serverMissions[offer.id] else null
        val localMission = localMissions[offer.id] ?: LocalMissionProgress()
        if (mission?.claimed == true || (!RewardsApi.isConfigured && localMission.claimed)) {
            message = "${offer.title} is complete for this 4-day cycle. It will refresh when the cycle ends."
            return
        }
        val progress = if (RewardsApi.isConfigured) mission?.verified ?: 0 else localMission.watched
        if (progress >= offer.adsRequired) {
            message = "You've finished the videos for ${offer.title}. Claim it when server verification is ready."
            return
        }
        if (watchedToday >= dailyLimit) {
            message = "You have reached today's ${dailyLimit}-ad safety limit. Mission progress is preserved for 4 days."
            return
        }
        if (activity == null) {
            message = "Could not open the video ad from this screen."
            return
        }
        isShowingAd = true
        message = if (RewardsApi.isConfigured) "Preparing a rewarded video for ${offer.title}…" else "Loading a Google test rewarded video for ${offer.title}…"
        scope.launch {
            val customData = if (RewardsApi.isConfigured) {
                try { RewardsApi.createAdSession(installId, offer.id) } catch (e: Exception) {
                    isShowingAd = false
                    message = e.message ?: "Could not start a verified ad session."
                    return@launch
                }
            } else ""

            RewardedAd.load(
                context,
                BuildConfig.ADMOB_REWARDED_AD_UNIT_ID,
                AdRequest.Builder().build(),
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        val verificationBuilder = ServerSideVerificationOptions.Builder().setUserId(installId)
                        if (customData.isNotBlank()) verificationBuilder.setCustomData(customData)
                        ad.setServerSideVerificationOptions(verificationBuilder.build())
                        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                isShowingAd = false
                                scope.launch {
                                    delay(1800)
                                    refreshServerStats()
                                }
                            }
                            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                                isShowingAd = false
                                message = "Video could not be shown. Please try again later."
                            }
                        }
                        ad.show(activity, OnUserEarnedRewardListener {
                            val newCount = (prefs.getInt("watched_$today", 0) + 1).coerceAtMost(DAILY_REWARDED_AD_LIMIT)
                            prefs.edit().putString("local_day", today).putInt("watched_$today", newCount).apply()
                            localDay = today
                            localWatched = newCount
                            if (!RewardsApi.isConfigured) {
                                val now = System.currentTimeMillis()
                                val old = loadLocalMissionProgress(prefs)[offer.id] ?: LocalMissionProgress()
                                val cycleStart = if (old.startedAtMillis <= 0L || now - old.startedAtMillis >= MISSION_CYCLE_MILLIS) now else old.startedAtMillis
                                val next = old.copy(
                                    watched = (if (cycleStart == old.startedAtMillis) old.watched else 0).plus(1).coerceAtMost(offer.adsRequired),
                                    startedAtMillis = cycleStart,
                                    claimed = false
                                )
                                prefs.edit()
                                    .putLong("mission_started_${offer.id}", next.startedAtMillis)
                                    .putInt("mission_watched_${offer.id}", next.watched)
                                    .putBoolean("mission_claimed_${offer.id}", false)
                                    .apply()
                                localMissions = loadLocalMissionProgress(prefs)
                                message = "Test progress saved for ${offer.title} only. Test ads cannot create a verified hosting claim."
                            } else {
                                message = "Video finished for ${offer.title}. Waiting for Google's server verification; refresh if progress does not update shortly."
                            }
                        })
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        isShowingAd = false
                        message = "No video is available right now (code ${error.code}). Please try again later."
                    }
                }
            )
        }
    }

    fun claimOffer(offer: HostingOffer) {
        if (!RewardsApi.isConfigured) {
            message = "Claims are preview-only until the Rewards API is deployed and configured."
            return
        }
        claimingOffer = offer.id
        scope.launch {
            try {
                val claim = RewardsApi.createClaim(installId, offer.id)
                claimUrl = claim.url
                message = "Claim created with ${claim.verifiedAds} server-verified ads for ${offer.title}."
                refreshServerStats()
            } catch (e: Exception) {
                message = e.message ?: "Not enough server-verified ads for this mission yet. Refresh and try again."
            } finally {
                claimingOffer = null
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(RewardBackground).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF173D35), modifier = Modifier.size(48.dp)) {
                    Box(contentAlignment = Alignment.Center) { androidx.compose.material3.Icon(Icons.Default.EmojiEvents, null, tint = RewardGreen, modifier = Modifier.size(27.dp)) }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Rewards Center", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 23.sp)
                    Text("Track each hosting mission independently.", color = RewardMuted, fontSize = 12.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = RewardCard), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Today's ad safety limit", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Text("Only the daily cap resets at India midnight; mission progress lasts 4 days.", color = RewardMuted, fontSize = 12.sp)
                        }
                        Text("$watchedToday / $dailyLimit", color = RewardGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = (watchedToday.toFloat() / dailyLimit.coerceAtLeast(1)).coerceIn(0f, 1f),
                        modifier = Modifier.fillMaxWidth().height(7.dp),
                        color = RewardGreen,
                        trackColor = Color(0xFF314154)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Icon(Icons.Default.Verified, null, tint = Color(0xFF60A5FA), modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Server-verified today: $verifiedToday • available today: $availableToday", color = RewardMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { scope.launch { refreshServerStats() } }, enabled = RewardsApi.isConfigured && !isRefreshing, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp, vertical = 4.dp)) {
                            if (isRefreshing) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp) else androidx.compose.material3.Icon(Icons.Default.Refresh, null, modifier = Modifier.size(15.dp))
                        }
                    }
                    if (!RewardsApi.isConfigured) {
                        Row(verticalAlignment = Alignment.Top) {
                            androidx.compose.material3.Icon(Icons.Default.Info, null, tint = Color(0xFFFBBF24), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Preview mode: Google test ads update separate on-device counters for each mission. Claims stay disabled until the Rewards API is configured.", color = Color(0xFFFDE68A), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item {
            Text("CURRENT MISSIONS", color = RewardMuted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text("Every video counts only toward the mission whose Watch Video button you tap. Each mission has its own 4-day cycle; one mission's progress never fills another mission's bar.", color = RewardMuted, fontSize = 12.sp)
        }
        items(hostingOffers, key = { it.id }) { offer ->
            val serverMission = serverMissions[offer.id]
            val localMission = localMissions[offer.id] ?: LocalMissionProgress()
            val progressCount = if (RewardsApi.isConfigured) serverMission?.verified ?: 0 else localMission.watched
            val availableCount = if (RewardsApi.isConfigured) serverMission?.available ?: 0 else localMission.watched
            val claimed = if (RewardsApi.isConfigured) serverMission?.claimed == true else localMission.claimed
            val progress = (progressCount.toFloat() / offer.adsRequired).coerceIn(0f, 1f)
            val enough = availableCount >= offer.adsRequired && !claimed
            val resetLabel = if (RewardsApi.isConfigured) serverResetLabel(serverMission?.resetsAt) else formatResetTime(localMission.startedAtMillis)
            Card(colors = CardDefaults.cardColors(containerColor = RewardCard), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFF24394C), modifier = Modifier.size(43.dp)) {
                            Box(contentAlignment = Alignment.Center) { androidx.compose.material3.Icon(Icons.Default.Memory, null, tint = Color(0xFF93C5FD), modifier = Modifier.size(24.dp)) }
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(offer.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("${offer.ram} server for ${offer.days} days", color = RewardGreen, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(offer.description, color = RewardMuted, fontSize = 12.sp)
                        }
                        Surface(color = Color(0xFF26394B), shape = RoundedCornerShape(8.dp)) {
                            Text("${offer.adsRequired} ads", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
                        }
                    }
                    LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth().height(6.dp), color = if (enough || claimed) RewardGreen else Color(0xFF60A5FA), trackColor = Color(0xFF314154))
                    Text("${progressCount.coerceAtMost(offer.adsRequired)} / ${offer.adsRequired} ads  •  $resetLabel", color = RewardMuted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { watchVideo(offer) },
                            enabled = !isShowingAd && watchedToday < dailyLimit && !claimed && progressCount < offer.adsRequired,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF176B52), contentColor = Color.White),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            if (isShowingAd) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp, color = Color.White)
                            else androidx.compose.material3.Icon(Icons.Default.PlayCircle, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Watch Video", fontSize = 12.sp)
                        }
                        Spacer(Modifier.width(7.dp))
                        Button(
                            onClick = { claimOffer(offer) },
                            enabled = RewardsApi.isConfigured && enough && claimingOffer == null && !claimed,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155), contentColor = Color.White, disabledContainerColor = Color(0xFF222D3B), disabledContentColor = Color(0xFF64748B)),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 7.dp)
                        ) {
                            if (claimingOffer == offer.id) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = Color.White)
                            else androidx.compose.material3.Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (claimed) "Claimed" else "Claim", fontSize = 12.sp)
                        }
                    }
                    if (claimed) Text("This mission has been claimed for the current cycle.", color = RewardGreen, fontSize = 11.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF182B3A)), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Contribute", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Text("Support SudarshanCloud by sharing feedback, reporting bugs, or inviting other server owners. Ads will never auto-play; each permitted ad opportunity must be chosen by you.", color = RewardMuted, fontSize = 12.sp)
                    Button(
                        onClick = {
                            try { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(SUPPORT_DISCORD_URL))) }
                            catch (_: Exception) { Toast.makeText(context, "Could not open the SudarshanCloud Discord link", Toast.LENGTH_SHORT).show() }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF176B52), contentColor = Color.White)
                    ) { Text("Open SudarshanCloud Discord") }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF182B3A)), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("How claiming works", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("1. Choose a mission. 2. Tap its Watch Video button and opt in. 3. Wait for server verification. 4. Claim that same mission when enough unused, verified ads are available. 5. Share the generated claim link in a SudarshanCloud Discord support ticket.", color = RewardMuted, fontSize = 12.sp)
                    Text("Progress is independent per mission. A mission cycle lasts 4 days from the first video attempt; expired progress starts fresh. A claim uses only the ads recorded for that mission cycle.", color = RewardMuted, fontSize = 11.sp)
                }
            }
        }
        if (message != null) {
            item {
                Text(message!!, color = if (message!!.contains("could not", true) || message!!.contains("unavailable", true) || message!!.contains("disabled", true) || message!!.contains("not enough", true) || message!!.contains("failed", true)) Color(0xFFFBBF24) else Color(0xFF93C5FD), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp))
            }
        }
        val generatedClaimUrl = claimUrl
        if (generatedClaimUrl != null) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF173D35)), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Claim link ready", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("Open this page, then include its link in a ticket. The page shows the offer, verified-ad proof, and whether staff marked it pending, approved, or rejected.", color = Color(0xFFD1FAE5), fontSize = 12.sp)
                        Text(generatedClaimUrl, color = Color(0xFF93C5FD), fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                try { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(generatedClaimUrl))) }
                                catch (_: Exception) { Toast.makeText(context, "Could not open claim URL", Toast.LENGTH_SHORT).show() }
                            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF176B52))) { Text("Open claim") }
                            OutlinedButton(onClick = {
                                val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "SudarshanCloud rewards claim: $generatedClaimUrl\nPlease verify this claim in my support ticket.") }
                                context.startActivity(Intent.createChooser(share, "Share claim link"))
                            }) { Text("Share link") }
                        }
                        Text("Support Discord: $SUPPORT_DISCORD_URL", color = Color(0xFFD1FAE5), fontSize = 11.sp)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

private fun Context.findActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}
