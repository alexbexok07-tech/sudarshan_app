# SudarshanCloud AdMob connection

The Android source uses the project App ID for application identification and defaults both ad formats to Google test units for safe development. Configure production IDs only after the app and its ad/reward model are cleared by AdMob.

The rewarded ad unit remains on Google’s test ID unless you separately set the `ADMOB_REWARDED_AD_UNIT_ID` GitHub Actions repository variable. The banner uses Google’s adaptive-banner test unit unless you set `ADMOB_BANNER_AD_UNIT_ID`. Do not change that variable to a production ID until AdMob has confirmed in writing that the app’s hosting-for-ad-views offer design is compliant.

## Important policy check

Google’s AdMob policy on apps that offer compensation programs says ads may not be placed in apps that promise incentives for viewing or clicking ads. A separate rewarded-ad policy permits certain non-transferable non-monetary rewards within the publisher’s platform. Since this app offers temporary Minecraft hosting for watching ads, ask AdMob support to confirm the exact model in writing before enabling production ad serving.

## Build

1. Upload the entire project contents to the root of the GitHub repository (including `.github/workflows/`).
2. Open **Actions → Build SudarshanCloud APK → Run workflow**.
3. Download the APK from the workflow Artifacts when the workflow succeeds.
4. Test with test ads during development. Never click your own production ads.

The App ID and banner ID are IDs, not secret credentials. Do not put admin API keys or other secrets in the Android app.


## Mission progress update

Each hosting offer is now tracked independently. The Android client sends the selected offer ID with each ad session, and the backend counts only verified AdMob SSV events attached to that offer and its four-day cycle. Claiming one mission reserves only its own events and locks that mission until its cycle expires. Existing SQLite installations are migrated in place by adding the new columns; keep Render's persistent disk mounted so the database survives deploys.

The Rewards screen's **Contribute** card links to Discord for feedback and bug reports. It deliberately does not auto-play or chain ads, and it does not say that users should watch ads to support the business.

## Build variables

For the signed release workflow, GitHub repository **Variables** may include:

- `REWARDS_API_BASE_URL` — HTTPS base URL of the deployed rewards API.
- `ADMOB_BANNER_AD_UNIT_ID` — your approved production banner unit when ready; unset defaults to Google's test banner.
- `ADMOB_REWARDED_AD_UNIT_ID` — keep unset (test unit) unless AdMob confirms the hosting reward design is allowed in writing.

The debug workflow does not take production ad IDs; it continues to use test ads.
