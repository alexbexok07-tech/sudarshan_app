# SudarshanCloud AdMob integration

The app has an adaptive anchored banner slot above the bottom navigation bar and uses Google Mobile Ads. For safe development, both ad formats default to Google's official test ad units:

- Rewarded video: `ca-app-pub-3940256099942544/5224354917`
- Adaptive banner: `ca-app-pub-3940256099942544/9214589741`

Test ad views/rewards do not count as publisher revenue. Never click your own live ads or repeatedly test against production units.

## Before production

1. In AdMob, verify the app and create the ad units required for it. Keep the AdMob App ID in `app/src/main/AndroidManifest.xml`.
2. For a signed release, the GitHub repository variable `ADMOB_BANNER_AD_UNIT_ID` can supply the approved banner unit. If unset, the project uses Google's test banner unit.
3. Keep `ADMOB_REWARDED_AD_UNIT_ID` unset (test rewarded unit) unless AdMob confirms in writing that offering temporary hosting trials in exchange for rewarded ad views is allowed for this app. The general AdMob behavioral policy and its rewarded-ad policy should be reviewed together; the code itself does not constitute policy approval.
4. Configure the deployed Rewards API URL as `REWARDS_API_BASE_URL` in GitHub repository variables. Configure AdMob Server-side Verification (SSV) to call `https://YOUR-REWARDS-SERVICE/api/admob/ssv`.
5. Configure Render persistent storage for `rewards-api` so the SQLite database survives deployments.
6. Test the rewarded callback and ensure only server-verified SSV events unlock claims. Test IDs can exercise local UI flow but cannot prove production reporting or production claim delivery.

## Mission progress

Every mission has a separate backend-tracked four-day cycle. A rewarded ad session is tied to the offer selected by the user; only an SSV event associated with that offer increments its verified count. Claiming one offer reserves only events from that offer and cycle. The backend schema migrates existing SQLite files in place, but backups should still be kept before deploying the update.

The Contribute card links to Discord for support/feedback. It does not automatically loop ads or tell users to watch ads to support the business. Rewarded ads must be shown only after clear opt-in and the offered reward must be disclosed; see Google's current policy before enabling live rewarded ads.

## Diagnostics

The adaptive banner logs SDK load failures to Logcat with the tag `SudarshanCloudAds`. The log includes the Google SDK error code and message, which helps distinguish no-fill or approval/configuration issues. A banner request by itself does not guarantee an impression or revenue.
