# SudarshanCloud Android App

Android client for a Pterodactyl panel.

## Live server synchronization

The home server cards are populated from the configured Pterodactyl API; there are no hard-coded demo server cards.

In **Settings → Panel & API Configuration**:

- Enter the panel URL.
- Enter a **Client API Key (`ptlc_...`)** for client-level server operations.
- If you administer the panel and want the app to display **all servers**, also enter an **Application API Key (`ptla_...`)**. The app uses the Application API `/api/application/servers` endpoint, follows pagination, and replaces the local server cache with the live server inventory.

Keep API keys private.


## Rewarded hosting offers / AdMob

The sidebar includes **Rewards & Offers**. The screen contains four temporary hosting trials, a daily video counter, per-offer progress, optional rewarded-video ads, and claim-link generation. The app uses Google's official **test** ad IDs by default. In test mode, local progress is only a preview; no claims are created until the companion API is configured.

Read [`ADMOB_SETUP.md`](ADMOB_SETUP.md) for Android setup and [`rewards-api/README.md`](rewards-api/README.md) for deploying the verification/claim service. The API must have persistent storage before it is used for real claims. The Android project build has not been compiled successfully in this environment because downloading the Gradle distribution failed, so run the GitHub Actions build and resolve any compile errors before releasing it.

**Production warning:** The rewarded-hosting exchange is still test-only. Before switching to live AdMob rewarded ads, obtain written confirmation from AdMob that this exact incentive model is allowed. See the policy warning in [`ADMOB_SETUP.md`](ADMOB_SETUP.md).
